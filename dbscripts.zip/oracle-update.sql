-- SchemaVersion1010
-- START OF AccessMatrix Server Schema Update 5.0.4/5.0.5 to 5.0.6/5.0.7 (1010)

    create table am_pinmailer (
        pm_uuid varchar2(64 char) not null,
        pm_version number(19,0) not null,
        pm_id varchar2(64 char) not null unique,
        pm_entry_uid varchar2(32 char),
        pm_template_id varchar2(64 char),
        pm_module_id varchar2(64 char),
        pm_content_type varchar2(32 char),
        pm_content_action varchar2(32 char),
        pm_status varchar2(32 char),
        pm_content_uuid varchar2(64 char),
        pm_content_summary varchar2(256 char),
        pm_template_uuid varchar2(64 char),
        pm_channel_uuid varchar2(64 char),
        pm_delivery_summary varchar2(256 char),
        pm_maker varchar2(64 char),
        pm_made_time timestamp,
        pm_checker varchar2(64 char),
        pm_checked_time timestamp,
        pm_creator varchar2(64 char),
        pm_created_time timestamp,
        pm_modifier varchar2(64 char),
        pm_modified_time timestamp,
        pm_ended number(1,0),
        pm_attr1_char16 varchar2(16 char),
        pm_attr2_char16 varchar2(16 char),
        pm_attr3_char32 varchar2(32 char),
        pm_attr4_char32 varchar2(32 char),
        pm_attr5_char64 varchar2(64 char),
        pm_attr6_char64 varchar2(64 char),
        pm_attr7_char128 varchar2(128 char),
        pm_attr8_char256 varchar2(256 char),
        pm_flag1 number(1,0),
        pm_flag2 number(1,0),
        pm_number1 number(19,0),
        pm_number2 number(19,0),
        pm_time1 timestamp,
        pm_time2 timestamp,
        primary key (pm_uuid)
    );

    create table am_pinmailer_attr (
        pa_uuid varchar2(64 char) not null,
        pa_name varchar2(64 char) not null,
        pa_part number(10,0) not null,
        pa_name_upper varchar2(64 char) not null,
        pa_datatype varchar2(16 char) not null,
        pa_enctype char(1 char) not null,
        pa_value varchar2(3072 char),
        primary key (pa_uuid, pa_name, pa_part)
    );

    create table am_vars (
        va_name varchar2(64 char) not null,
        va_version number(19,0) not null,
        va_value varchar2(256 char),
        primary key (va_name)
    );

    create sequence am_wfentry_seq;

    create sequence am_wfother_seq;

    drop sequence hibernate_sequence;

    create index idx_pa_name_uuid on am_pinmailer_attr(pa_name, pa_uuid);

    create index idx_pa_nameu_uuid on am_pinmailer_attr(pa_name_upper, pa_uuid);

    insert into am_vars (va_name, va_version, va_value) values ('SchemaVersion', 1, '1010');

-- END OF AccessMatrix Server Schema Update 5.0.4/5.0.5 to 5.0.6/5.0.7 (1010)
-- EndOfSchemaVersion1010

-- SchemaVersion1011
-- START OF AccessMatrix Server Schema Update 5.0.6/5.0.7 (1010) to 5.0.8 (1011)

    create table am_tokenauthstate (
        tst_token_uuid varchar2(64 char) not null,
        tst_func_id varchar2(32 char) not null,
        tst_auth_mode varchar2(8 char) not null,
        tst_version number(19,0) not null,
        tst_partition number(10,0),
        tst_status varchar2(20 char),
        tst_success_cnt number(10,0),
        tst_fail_cnt number(10,0),
        tst_last_stat_chg_date timestamp,
        tst_sec_hash varchar2(128 char),
        tst_sec_data varchar2(2048 char),
        tst_other_attrs varchar2(1024 char),
        tst_last_modified_date timestamp,
        primary key (tst_token_uuid, tst_func_id, tst_auth_mode)
    );

    create table am_userauthstate (
        ust_user_uuid varchar2(64 char) not null,
        ust_type varchar2(3 char) not null,
        ust_auth_uuid varchar2(64 char) not null,
        ust_version number(19,0) not null,
        ust_partition number(10,0),
        ust_status varchar2(20 char),
        ust_control_flag varchar2(3 char),
        ust_start_date timestamp,
        ust_end_date timestamp,
        ust_success_cnt number(10,0),
        ust_fail_cnt number(10,0),
        ust_last_login_date timestamp,
        ust_last_logout_date timestamp,
        ust_last_pwd_chg_date timestamp,
        ust_last_stat_chg_date timestamp,
        ust_sec_hash varchar2(128 char),
        ust_other_attrs varchar2(2048 char),
        ust_last_modified_date timestamp,
        primary key (ust_user_uuid, ust_type, ust_auth_uuid)
    );

    update am_vars set va_value='1011', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.0.6/5.0.7 (1010) to 5.0.8 (1011)
-- EndOfSchemaVersion1011

-- SchemaVersion1012
-- START OF AccessMatrix Server Schema Update 5.0.8 (1011) to 5.0.9 (1012)

    drop table am_session;

    create table am_ucmattr (
        at_objclass varchar2(32 char) not null,
        at_uuid varchar2(64 char) not null,
        at_name varchar2(64 char) not null,
        at_sequence number(10,0) not null,
        at_version number(19,0) not null,
        at_type number(10,0),
        at_intvalue number(10,0),
        at_stringvalue varchar2(256 char),
        at_timestampvalue timestamp,
        at_booleanvalue number(1,0),
        primary key (at_objclass, at_uuid, at_name, at_sequence)
    );

    create table am_ucmchkout (
        cko_cruuid varchar2(64 char) not null,
        cko_rquuid varchar2(64 char) not null,
        cko_crversion number(19,0) not null,
        cko_lockreq varchar2(64 char) not null,
        cko_outtime timestamp,
        cko_intime timestamp,
        cko_exptime timestamp,
        cko_remark varchar2(512 char),
        cko_attr1_int number(10,0),
        cko_attr1_str32 varchar2(32 char),
        cko_attr_json varchar2(1024 char),
        primary key (cko_cruuid, cko_rquuid, cko_crversion, cko_lockreq)
    );

    create table am_ucmcred (
        cr_uuid varchar2(64 char) not null,
        cr_object_class varchar2(32 char) not null,
        cr_version number(19,0) not null,
        cr_id varchar2(64 char) not null,
        cr_id_upper varchar2(64 char) not null,
        cr_description varchar2(256 char),
        cr_status varchar2(255 char),
        cr_workflow_state number(10,0),
        cr_usagemode number(10,0),
        cr_reqapplvl number(10,0),
        cr_curapplvl number(10,0),
        cr_force_chkin number(1,0),
        cr_auto_password_update number(1,0),
        cr_lastpwdupd_result number(10,0),
        cr_lastpwdupd_msg varchar2(256 char),
        cr_lastpwdupd_time timestamp,
        cr_lasttestlogin_msg varchar2(256 char),
        cr_lasttestlogin_time timestamp,
        cr_lasttestlogin_result number(10,0),
        cr_targetrsc_uuid varchar2(64 char),
        cr_safe_uuid varchar2(64 char),
        cr_userid varchar2(64 char),
        cr_lockreq_uuid varchar2(64 char),
        cr_value varchar2(1024 char),
        cr_numofparts number(10,0),
        cr_parentcred_uuid varchar2(64 char),
        cr_partindex number(10,0),
        primary key (cr_uuid)
    );

    create table am_ucmrel (
        re_uuid1 varchar2(64 char) not null,
        re_relation number(10,0) not null,
        re_uuid2 varchar2(64 char) not null,
        re_sequence number(19,0) not null,
        re_objclass1 varchar2(32 char),
        re_objclass2 varchar2(32 char),
        re_created_time timestamp,
        re_creator_uuid varchar2(64 char),
        re_lastmodified_time timestamp,
        re_lastmodifier_uuid varchar2(64 char),
        re_attr1char16 varchar2(16 char),
        re_attr2char32 varchar2(32 char),
        re_attr3char64 varchar2(64 char),
        re_attr4char128 varchar2(128 char),
        re_attr4char1024 varchar2(1024 char),
        re_attr1int number(10,0),
        re_attr2int number(10,0),
        re_attr1time timestamp,
        re_attr2time timestamp,
        primary key (re_uuid1, re_relation, re_uuid2, re_sequence)
    );

    create table am_ucmreq (
        req_uuid varchar2(64 char) not null,
        req_version number(19,0) not null,
        req_title varchar2(256 char),
        req_workflow_name varchar2(64 char),
        req_workflow_id number(19,0),
        req_workflow_state number(10,0),
        req_reqapplvl number(10,0),
        req_curapplvl number(10,0),
        req_creator_uuid varchar2(64 char),
        req_created_time timestamp,
        req_lastmodifier_uuid varchar2(64 char),
        req_lastmodified_time timestamp,
        req_chkout_starttime timestamp,
        req_chkout_endtime timestamp,
        primary key (req_uuid)
    );

    create table am_ucmtagdesc (
        cr_uuid varchar2(64 char) not null,
        tag_id varchar2(64 char) not null,
        tag_value varchar2(64 char) not null,
        primary key (cr_uuid, tag_id, tag_value)
    );

    create index idx_ucmcr_idu on am_ucmcred (cr_id_upper);

    create index idx_ucmcr_sf on am_ucmcred (cr_safe_uuid);

    create index idx_ucmcr_tr on am_ucmcred (cr_targetrsc_uuid);

    create index idx_ucmcr_id on am_ucmcred (cr_id);

    create index idx_ucmcr_01 on am_ucmcred(cr_object_class,cr_id);

    create index idx_ucmcr_02 on am_ucmcred(cr_object_class,cr_id_upper);

    create index idx_ucmcko_01 on am_ucmchkout(cko_rquuid, cko_lockreq, cko_cruuid);

    create index idx_ucmcko_02 on am_ucmchkout(cko_lockreq, cko_cruuid, cko_rquuid);

    create index idx_ust_type_auth_user on am_userauthstate(ust_type,ust_auth_uuid,ust_user_uuid);

    update am_vars set va_value='1012', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.0.8 (1011) to 5.0.9 (1012)
-- EndOfSchemaVersion1012

-- SchemaVersion1013
-- START OF AccessMatrix Server Schema Update 5.0.9 (1012) to 5.1.2 (1013)

--    alter table am_attribute add at_modified_time timestamp;

    create table am_biometric (
        bm_usr_uuid varchar2(64 char) not null,
        bm_vendor number(10,0) not null,
        bm_type number(10,0) not null,
        bm_label varchar2(8 char) not null,
        bm_version number(19,0) not null,
        bm_refer_tplt blob not null,
        bm_status number(10,0),
        bm_partition number(10,0),
        bm_last_verified_time timestamp,
        bm_creation_time timestamp,
        bm_modified_time timestamp,
        bm_sec_hash varchar2(128 char),
        primary key (bm_usr_uuid, bm_vendor, bm_type, bm_label)
    );

    create table am_impersonation (
        imp_impersonated_uuid varchar2(64 char) not null,
        imp_impersonator_uuid varchar2(64 char) not null,
        imp_impersonator_oc varchar2(32 char) not null,
        imp_sequence number(10,0) not null,
        imp_start_time timestamp,
        imp_end_time timestamp,
        imp_last_modified_time timestamp,
        imp_last_modifier_uuid varchar2(64 char),
        primary key (imp_impersonated_uuid, imp_impersonator_uuid, imp_impersonator_oc, imp_sequence)
    );

    create table am_impersonation_obj (
        impobj_impersonated_uuid varchar2(64 char) not null,
        impobj_impersonator_uuid varchar2(64 char) not null,
        impobj_impersonator_oc varchar2(32 char) not null,
        imp_sequence number(10,0) not null,
        impobj_obj_uuid varchar2(64 char) not null,
        impobj_obj_oc varchar2(32 char) not null,
        impobj_other_attrs varchar2(2048 char),
        primary key (impobj_impersonated_uuid, impobj_impersonator_uuid, impobj_impersonator_oc, imp_sequence, impobj_obj_uuid, impobj_obj_oc)
    );

    create sequence log_command_sequence;

    create index idx_pm_maker on am_pinmailer (pm_maker);

    create index idx_pm_status on am_pinmailer (pm_status);

    create index idx_pm_content on am_pinmailer (pm_content_uuid);

    create index idx_pm_end_modtime on am_pinmailer(pm_ended,pm_modified_time);

    create index idx_pm_entryuid_modtime on am_pinmailer(pm_entry_uid,pm_modified_time);

    create index idx_bm_uuid_vendor_label_type on am_biometric(bm_usr_uuid,bm_vendor,bm_label,bm_type);

    create index idx_imp_impersonator on am_impersonation(imp_impersonator_uuid,imp_impersonator_oc,imp_sequence,imp_impersonated_uuid);
    
    update am_vars set va_value='1013', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.0.9 (1012) to 5.1.2 (1013)
-- EndOfSchemaVersion1013

-- SchemaVersion1014
-- START OF AccessMatrix Server Schema Update 5.1.2 (1013) to 5.1.2 (1014)

    alter table am_audit modify (au_actor_ip_addr varchar2(45));
    
    alter table am_audit modify (au_client_id varchar2(45));

    update am_vars set va_value='1014', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.1.2 (1013) to 5.1.2 (1014)
-- EndOfSchemaVersion1014

-- SchemaVersion1015
-- START OF AccessMatrix Server Schema Update 5.1.2 (1014) to 5.1.2 (1015)

-- Only for migrating 5.1.2.1200-5.1.2.1214 to 5.1.2.1215
/*  drop table am_biometric;
    create table am_biometric (
        bm_usr_uuid varchar2(64 char) not null,
        bm_vendor number(10,0) not null,
        bm_type number(10,0) not null,
        bm_label varchar2(8 char) not null,
        bm_version number(19,0) not null,
        bm_refer_tplt blob not null,
        bm_status number(10,0),
        bm_partition number(10,0),
        bm_last_verified_time timestamp,
        bm_creation_time timestamp,
        bm_modified_time timestamp,
        bm_sec_hash varchar2(128 char),
        primary key (bm_usr_uuid, bm_vendor, bm_type, bm_label)
    );
*/
    update am_vars set va_value='1015', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.1.2 (1014) to 5.1.2 (1015)
-- EndOfSchemaVersion1015

-- SchemaVersion1016
-- START OF AccessMatrix Server Schema Update 5.1.2 SP1 (1015) to 5.1.2 SP2 (1016)

    create table am_esso_entitlement (
        si_useruuid varchar2(64 char) not null,
        si_appid varchar2(64 char) not null,
        si_pid number(10,0) not null,
        si_entitlement_prn varchar2(64 char) not null,
        si_userid varchar2(64 char),
        si_app_userid varchar2(64 char),
        si_share_prn varchar2(64 char),
        si_share_res varchar2(64 char),
        si_pwd_modified_time varchar2(64 char),
        si_created_time timestamp,
        primary key (si_useruuid, si_appid, si_pid, si_entitlement_prn)
    );

    create index idx_esso_si_appuid on am_esso_entitlement(si_app_userid, si_appid);

    update am_vars set va_value='1016', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.1.2 SP1 (1015) to 5.1.2 SP2 (1016)
-- EndOfSchemaVersion1016

-- SchemaVersion1020
-- START OF AccessMatrix Server Schema Update 5.1.2 (1016) to 5.2.0 (1020)

    create table am_ucmaccdiscovery (
        acc_user_id varchar2(64 char) not null,
        acc_targetrsc_id varchar2(64 char) not null,
        acc_targetrsc_type varchar2(64 char),
        acc_host varchar2(64 char),
        acc_userrole varchar2(64 char),
        acc_primarygrp varchar2(64 char),
        acc_ucm_only number(1,0),
        acc_targetrsc_only number(1,0),
        primary key (acc_user_id, acc_targetrsc_id)
    );

    create table am_ucmgwsession (
        gs_short_session_id varchar2(32 char) not null,
        gs_requester_id varchar2(50 char),
        gs_windows_account varchar2(50 char),
        gs_gateway_ip varchar2(40 char),
        gs_remote_desktop_ip varchar2(40 char),
        gs_start_time timestamp,
        gs_end_time timestamp,
        gs_last_heart_beat timestamp,
        gs_has_finish_recording number(1,0),
        gs_is_converting number(1,0),
        gs_video blob,
        primary key (gs_short_session_id)
    );

    create table am_ucmrecordedapp (
        ra_short_session_id varchar2(32 char) not null,
        ra_pid number(10,0) not null,
        ra_app_path varchar2(255 char),
        ra_title varchar2(255 char),
        ra_start_time timestamp,
        ra_end_time timestamp,
        ra_target_resource_id varchar2(64 char),
        ra_target_resource_ip varchar2(45 char),
        ra_target_resource_port number(10,0),
        ra_sso_protocol varchar2(20 char),
        ra_credential_id varchar2(64 char),
        primary key (ra_short_session_id, ra_pid)
    );

    create table am_ucmrecordedcommand (
        rc_short_session_id varchar2(32 char) not null,
        rc_pid number(10,0) not null,
        rc_command_time timestamp not null,
        rc_command varchar2(700 char),
        primary key (rc_short_session_id, rc_pid, rc_command_time)
    );

    create table am_ucmtmpvideo (
        tv_short_session_id varchar2(32 char) not null,
        tv_israw number(1,0) not null,
        tv_sequence number(10,0) not null,
        tv_video_chunk blob,
        tv_isbeing_processed number(1,0),
        primary key (tv_short_session_id, tv_israw, tv_sequence)
    );

    create index idx_ucmgwsession_01 on am_ucmgwsession(gs_has_finish_recording, gs_short_session_id);
    create index idx_ucmrecordedapp_01 on am_ucmrecordedapp(ra_app_path);
    create index idx_ucmrecordedapp_02 on am_ucmrecordedapp(ra_title);
    create index idx_ucmrecordedcommand_01 on am_ucmrecordedcommand(rc_command);
    
    update am_vars set va_value='1020', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.1.2 (1016) to 5.2.0 (1020)
-- EndOfSchemaVersion1020

-- SchemaVersion1026
-- START OF AccessMatrix Server Schema Update 5.2.0 (1020) to 5.2.0 (1026)

    alter table am_attribute add at_search_value varchar(96);
    
    create index idx_at_name_searchvalue on am_attribute(at_name,at_search_value);

    UPDATE am_attribute SET at_search_value=UPPER(at_string_value) WHERE at_name = 'mobile' and at_class ='User' and at_enctype='N';

    update am_vars set va_value='1026', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.2.0 (1020) to 5.2.0 (1026)
-- EndOfSchemaVersion1026

-- SchemaVersion1027
-- START OF AccessMatrix Server Schema Update 5.2.0 (1026) to 5.2.0 SP1 (1027)

    alter table am_ucmgwsession add gs_hash varchar2(64);

    update am_vars set va_value='1027', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.2.0 (1026) to 5.2.0 SP1 (1027)
-- EndOfSchemaVersion1027

-- SchemaVersion1032
-- START OF AccessMatrix Server Schema Update 5.2.0.SP1 (1027) to 5.2.2 (1032)

    alter table am_ucmgwsession add gs_reviewed_by varchar2(64 char);

    alter table am_ucmgwsession add gs_review_time timestamp;
	
    update am_vars set va_value='1032', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.2.0.SP1 (1027) to 5.2.2 (1032)
-- EndOfSchemaVersion1032

-- SchemaVersion1037
-- START OF AccessMatrix Server Schema Update 5.2.2 (1032) to 5.3 (1037)

    create table am_ucmcredusage (
        cu_cred_uuid varchar2(64 char) not null,
        cu_user_uuid varchar2(64 char) not null,
        cu_counter number(10,0),
        cu_last_chkout_time timestamp,
        primary key (cu_cred_uuid, cu_user_uuid)
    );

    create index idx_ucmcredusage_01 on am_ucmcredusage(cu_user_uuid, cu_counter);

    create index idx_ucmcredusage_02 on am_ucmcredusage(cu_user_uuid, cu_last_chkout_time);

    alter table am_ucmgwsession add gs_has_failed number(1,0);

    update am_vars set va_value='1037', va_version = va_version + 1 where va_name='SchemaVersion';
    
-- END OF AccessMatrix Server Schema Update 5.2.2 (1032) to 5.3 (1037)
-- EndOfSchemaVersion1037

-- SchemaVersion1042
-- START OF AccessMatrix Server Schema Update 5.3.0 (1037) to 5.3.2 (1042)

    create table am_contextualauthnhistory (
        ctx_uuid varchar2(64 char) not null,
        ctx_date timestamp,
        ctx_user_uuid varchar2(64 char),
        ctx_user_id varchar2(64 char),
        ctx_authn_res varchar2(1024 char),
        ctx_ip varchar2(64 char),
        ctx_country varchar2(64 char),
        ctx_countryisocode varchar2(2 char),
        ctx_subdivision varchar2(64 char),
        ctx_subdivisionisocode varchar2(3 char),
        ctx_city varchar2(64 char),
        ctx_latitude varchar2(64 char),
        ctx_longitude varchar2(64 char),
        ctx_geo_timezone varchar2(64 char),
        ctx_module varchar2(64 char),
        ctx_is_rooted varchar2(8 char),
        primary key (ctx_uuid)
    );
    
-- START OF Quartz

    CREATE TABLE qrtz_job_details (
        SCHED_NAME VARCHAR2(120) NOT NULL,
        JOB_NAME VARCHAR2(200) NOT NULL,
        JOB_GROUP VARCHAR2(200) NOT NULL,
        DESCRIPTION VARCHAR2(250) NULL,
        JOB_CLASS_NAME VARCHAR2(250) NOT NULL,
        IS_DURABLE VARCHAR2(1) NOT NULL,
        IS_NONCONCURRENT VARCHAR2(1) NOT NULL,
        IS_UPDATE_DATA VARCHAR2(1) NOT NULL,
        REQUESTS_RECOVERY VARCHAR2(1) NOT NULL,
        JOB_DATA BLOB NULL,
        CONSTRAINT QRTZ_JOB_DETAILS_PK PRIMARY KEY (
            SCHED_NAME,
            JOB_NAME,
            JOB_GROUP
            )
        );

    CREATE TABLE qrtz_triggers (
        SCHED_NAME VARCHAR2(120) NOT NULL,
        TRIGGER_NAME VARCHAR2(200) NOT NULL,
        TRIGGER_GROUP VARCHAR2(200) NOT NULL,
        JOB_NAME VARCHAR2(200) NOT NULL,
        JOB_GROUP VARCHAR2(200) NOT NULL,
        DESCRIPTION VARCHAR2(250) NULL,
        NEXT_FIRE_TIME NUMBER(13) NULL,
        PREV_FIRE_TIME NUMBER(13) NULL,
        PRIORITY NUMBER(13) NULL,
        TRIGGER_STATE VARCHAR2(16) NOT NULL,
        TRIGGER_TYPE VARCHAR2(8) NOT NULL,
        START_TIME NUMBER(13) NOT NULL,
        END_TIME NUMBER(13) NULL,
        CALENDAR_NAME VARCHAR2(200) NULL,
        MISFIRE_INSTR NUMBER(2) NULL,
        JOB_DATA BLOB NULL,
        CONSTRAINT QRTZ_TRIGGERS_PK PRIMARY KEY (
            SCHED_NAME,
            TRIGGER_NAME,
            TRIGGER_GROUP
            ),
        CONSTRAINT QRTZ_TRIGGER_TO_JOBS_FK FOREIGN KEY (
            SCHED_NAME,
            JOB_NAME,
            JOB_GROUP
            ) REFERENCES QRTZ_JOB_DETAILS(SCHED_NAME, JOB_NAME, JOB_GROUP)
        );

    CREATE TABLE qrtz_simple_triggers (
        SCHED_NAME VARCHAR2(120) NOT NULL,
        TRIGGER_NAME VARCHAR2(200) NOT NULL,
        TRIGGER_GROUP VARCHAR2(200) NOT NULL,
        REPEAT_COUNT NUMBER(7) NOT NULL,
        REPEAT_INTERVAL NUMBER(12) NOT NULL,
        TIMES_TRIGGERED NUMBER(10) NOT NULL,
        CONSTRAINT QRTZ_SIMPLE_TRIG_PK PRIMARY KEY (
            SCHED_NAME,
            TRIGGER_NAME,
            TRIGGER_GROUP
            ),
        CONSTRAINT QRTZ_SIMPLE_TRIG_TO_TRIG_FK FOREIGN KEY (
            SCHED_NAME,
            TRIGGER_NAME,
            TRIGGER_GROUP
            ) REFERENCES QRTZ_TRIGGERS(SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP)
        );

    CREATE TABLE qrtz_cron_triggers (
        SCHED_NAME VARCHAR2(120) NOT NULL,
        TRIGGER_NAME VARCHAR2(200) NOT NULL,
        TRIGGER_GROUP VARCHAR2(200) NOT NULL,
        CRON_EXPRESSION VARCHAR2(120) NOT NULL,
        TIME_ZONE_ID VARCHAR2(80),
        CONSTRAINT QRTZ_CRON_TRIG_PK PRIMARY KEY (
            SCHED_NAME,
            TRIGGER_NAME,
            TRIGGER_GROUP
            ),
        CONSTRAINT QRTZ_CRON_TRIG_TO_TRIG_FK FOREIGN KEY (
            SCHED_NAME,
            TRIGGER_NAME,
            TRIGGER_GROUP
            ) REFERENCES QRTZ_TRIGGERS(SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP)
        );

    CREATE TABLE qrtz_simprop_triggers (
        SCHED_NAME VARCHAR2(120) NOT NULL,
        TRIGGER_NAME VARCHAR2(200) NOT NULL,
        TRIGGER_GROUP VARCHAR2(200) NOT NULL,
        STR_PROP_1 VARCHAR2(512) NULL,
        STR_PROP_2 VARCHAR2(512) NULL,
        STR_PROP_3 VARCHAR2(512) NULL,
        INT_PROP_1 NUMBER(10) NULL,
        INT_PROP_2 NUMBER(10) NULL,
        LONG_PROP_1 NUMBER(13) NULL,
        LONG_PROP_2 NUMBER(13) NULL,
        DEC_PROP_1 NUMERIC(13, 4) NULL,
        DEC_PROP_2 NUMERIC(13, 4) NULL,
        BOOL_PROP_1 VARCHAR2(1) NULL,
        BOOL_PROP_2 VARCHAR2(1) NULL,
        CONSTRAINT QRTZ_SIMPROP_TRIG_PK PRIMARY KEY (
            SCHED_NAME,
            TRIGGER_NAME,
            TRIGGER_GROUP
            ),
        CONSTRAINT QRTZ_SIMPROP_TRIG_TO_TRIG_FK FOREIGN KEY (
            SCHED_NAME,
            TRIGGER_NAME,
            TRIGGER_GROUP
            ) REFERENCES QRTZ_TRIGGERS(SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP)
        );

    CREATE TABLE qrtz_blob_triggers (
        SCHED_NAME VARCHAR2(120) NOT NULL,
        TRIGGER_NAME VARCHAR2(200) NOT NULL,
        TRIGGER_GROUP VARCHAR2(200) NOT NULL,
        BLOB_DATA BLOB NULL,
        CONSTRAINT QRTZ_BLOB_TRIG_PK PRIMARY KEY (
            SCHED_NAME,
            TRIGGER_NAME,
            TRIGGER_GROUP
            ),
        CONSTRAINT QRTZ_BLOB_TRIG_TO_TRIG_FK FOREIGN KEY (
            SCHED_NAME,
            TRIGGER_NAME,
            TRIGGER_GROUP
            ) REFERENCES QRTZ_TRIGGERS(SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP)
        );

    CREATE TABLE qrtz_calendars (
        SCHED_NAME VARCHAR2(120) NOT NULL,
        CALENDAR_NAME VARCHAR2(200) NOT NULL,
        CALENDAR BLOB NOT NULL,
        CONSTRAINT QRTZ_CALENDARS_PK PRIMARY KEY (
            SCHED_NAME,
            CALENDAR_NAME
            )
        );

    CREATE TABLE qrtz_paused_trigger_grps (
        SCHED_NAME VARCHAR2(120) NOT NULL,
        TRIGGER_GROUP VARCHAR2(200) NOT NULL,
        CONSTRAINT QRTZ_PAUSED_TRIG_GRPS_PK PRIMARY KEY (
            SCHED_NAME,
            TRIGGER_GROUP
            )
        );

    CREATE TABLE qrtz_fired_triggers (
        SCHED_NAME VARCHAR2(120) NOT NULL,
        ENTRY_ID VARCHAR2(95) NOT NULL,
        TRIGGER_NAME VARCHAR2(200) NOT NULL,
        TRIGGER_GROUP VARCHAR2(200) NOT NULL,
        INSTANCE_NAME VARCHAR2(200) NOT NULL,
        FIRED_TIME NUMBER(13) NOT NULL,
        SCHED_TIME NUMBER(13) NOT NULL,
        PRIORITY NUMBER(13) NOT NULL,
        STATE VARCHAR2(16) NOT NULL,
        JOB_NAME VARCHAR2(200) NULL,
        JOB_GROUP VARCHAR2(200) NULL,
        IS_NONCONCURRENT VARCHAR2(1) NULL,
        REQUESTS_RECOVERY VARCHAR2(1) NULL,
        CONSTRAINT QRTZ_FIRED_TRIGGER_PK PRIMARY KEY (
            SCHED_NAME,
            ENTRY_ID
            )
        );

    CREATE TABLE qrtz_scheduler_state (
        SCHED_NAME VARCHAR2(120) NOT NULL,
        INSTANCE_NAME VARCHAR2(200) NOT NULL,
        LAST_CHECKIN_TIME NUMBER(13) NOT NULL,
        CHECKIN_INTERVAL NUMBER(13) NOT NULL,
        CONSTRAINT QRTZ_SCHEDULER_STATE_PK PRIMARY KEY (
            SCHED_NAME,
            INSTANCE_NAME
            )
        );

    CREATE TABLE qrtz_locks (
        SCHED_NAME VARCHAR2(120) NOT NULL,
        LOCK_NAME VARCHAR2(40) NOT NULL,
        CONSTRAINT QRTZ_LOCKS_PK PRIMARY KEY (
            SCHED_NAME,
            LOCK_NAME
            )
        );

    CREATE INDEX idx_qrtz_j_req_recovery ON qrtz_job_details (SCHED_NAME, REQUESTS_RECOVERY);

    CREATE INDEX idx_qrtz_j_grp ON qrtz_job_details (SCHED_NAME, JOB_GROUP);

    CREATE INDEX idx_qrtz_t_j ON qrtz_triggers (SCHED_NAME, JOB_NAME, JOB_GROUP);

    CREATE INDEX idx_qrtz_t_jg ON qrtz_triggers (SCHED_NAME, JOB_GROUP);

    CREATE INDEX idx_qrtz_t_c ON qrtz_triggers (SCHED_NAME, CALENDAR_NAME);

    CREATE INDEX idx_qrtz_t_g ON qrtz_triggers (SCHED_NAME, TRIGGER_GROUP);

    CREATE INDEX idx_qrtz_t_state ON qrtz_triggers (SCHED_NAME, TRIGGER_STATE);

    CREATE INDEX idx_qrtz_t_n_state ON qrtz_triggers (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP, TRIGGER_STATE);

    CREATE INDEX idx_qrtz_t_n_g_state ON qrtz_triggers (SCHED_NAME, TRIGGER_GROUP, TRIGGER_STATE);

    CREATE INDEX idx_qrtz_t_next_fire_time ON qrtz_triggers (SCHED_NAME, NEXT_FIRE_TIME);

    CREATE INDEX idx_qrtz_t_nft_st ON qrtz_triggers (SCHED_NAME, TRIGGER_STATE, NEXT_FIRE_TIME);

    CREATE INDEX idx_qrtz_t_nft_misfire ON qrtz_triggers (SCHED_NAME, MISFIRE_INSTR, NEXT_FIRE_TIME);

    CREATE INDEX idx_qrtz_t_nft_st_misfire ON qrtz_triggers (SCHED_NAME, MISFIRE_INSTR, NEXT_FIRE_TIME, TRIGGER_STATE);

    CREATE INDEX idx_qrtz_t_nft_st_misfire_grp ON qrtz_triggers (SCHED_NAME, MISFIRE_INSTR, NEXT_FIRE_TIME, TRIGGER_GROUP, TRIGGER_STATE);

    CREATE INDEX idx_qrtz_ft_trig_inst_name ON qrtz_fired_triggers (SCHED_NAME, INSTANCE_NAME);

    CREATE INDEX idx_qrtz_ft_inst_job_req_rcvry ON qrtz_fired_triggers (SCHED_NAME, INSTANCE_NAME, REQUESTS_RECOVERY);

    CREATE INDEX idx_qrtz_ft_j_g ON qrtz_fired_triggers (SCHED_NAME, JOB_NAME, JOB_GROUP);

    CREATE INDEX idx_qrtz_ft_jg ON qrtz_fired_triggers (SCHED_NAME, JOB_GROUP);

    CREATE INDEX idx_qrtz_ft_t_g ON qrtz_fired_triggers (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP);

    CREATE INDEX idx_qrtz_ft_tg ON qrtz_fired_triggers (SCHED_NAME, TRIGGER_GROUP);

-- END OF Quartz

    alter table am_ucmgwsession add gs_processed_by varchar2(64 char);

    update am_vars set va_value='1042', va_version = va_version + 1 where va_name='SchemaVersion';
    
-- END OF AccessMatrix Server Schema Update 5.3.0 (1037) to 5.3.2 (1042)
-- EndOfSchemaVersion1042

-- SchemaVersion1047
-- START OF AccessMatrix Server Schema Update 5.3.2 (1042) to 5.3.3 (1047)

    alter table am_ucmrecordedapp add ra_app_gtw number(10,0);

    update am_vars set va_value='1047', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.3.2 (1042) to 5.3.3 (1047)
-- EndOfSchemaVersion1047
    
-- SchemaVersion1052
-- START OF AccessMatrix Server Schema Update 5.3.3 (1047) to 5.4.0 (1052)

    alter table am_ucmgwsession add gs_remote_session_id varchar2(32 char);

    alter table am_ucmrecordedcommand add rc_outcome varchar2(64 char);

    update am_vars set va_value='1052', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.3.3 (1047) to 5.4.0 (1052)
-- EndOfSchemaVersion1052
    
-- SchemaVersion1057
-- START OF AccessMatrix Server Schema Update 5.4.0 (1052) to 5.4.1 (1057)

    alter table am_contextualauthnhistory add ctx_authn_res_sts char(1 char);
    
    create index idx_ctx_useruuid_res_sts on am_contextualauthnhistory (ctx_user_uuid, ctx_authn_res_sts); 
	
    create index idx_ctx_date_user_uuid on am_contextualauthnhistory (ctx_date, ctx_user_uuid);
    
    alter table am_ucmgwsession add gs_sequence number(10,0);

    create table am_ucmgwcpuusage (
        gs_gateway_ip varchar2(40 char) not null,
        gs_collect_time timestamp not null,
        gs_cpu_usage number(10,0),
        primary key (gs_gateway_ip, gs_collect_time)
    );

    update am_vars set va_value='1057', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.4.0 (1052) to 5.4.1 (1057)
-- EndOfSchemaVersion1057


-- SchemaVersion1062
-- START OF AccessMatrix Server Schema Update 5.4.1 (1057) to 5.4.2 (1062)

    create table am_ucmtransportstream (
        ts_short_session_id varchar2(32 char) not null,
        ts_sequence number(10,0) not null,
        ts_duration number(10,0),
        ts_flag number(10,0),
        ts_length number(10,0),
        primary key (ts_short_session_id, ts_sequence)
    );
    
    update am_attribute SET at_search_value=UPPER(at_string_value) WHERE at_name = 'email' and at_class ='User' and at_enctype='N';
    
    update am_vars set va_value='1062', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.4.1 (1057) to 5.4.2 (1062)
-- EndOfSchemaVersion1062


-- SchemaVersion1067
-- START OF AccessMatrix Server Schema Update 5.4.2 (1062) to 5.5.0 (1067)
    
    create table am_ucmrtmsession (
        gs_short_session_id varchar2(32 char) not null,
        gs_review_time timestamp,
        primary key (gs_short_session_id)
    );
    
    alter table am_ucmgwsession modify (gs_gateway_ip varchar2(256));
    
    alter table am_ucmgwsession add gs_last_chunk_time number(19,0);
    
    alter table am_ucmgwsession add gs_has_finish_converting number(1,0);
    
    -- Note for UCM customers: If you have existing video audit data, you need to run a migration tool before starting AM server and before dropping the following columns
    
    -- alter table am_ucmgwsession drop column gs_is_converting;
    
    -- alter table am_ucmgwsession drop column gs_video;
    
    alter table am_audit modify (au_signature varchar2(256));
    
    create table am_fidotokenrecord (
        ftr_token_uuid varchar2(64 char) not null,
        ftr_aaid_key_id_hash varchar2(88 char) not null,
        ftr_key_id varchar2(512 char) not null,
        ftr_app_id varchar2(128 char) not null,
        ftr_facet_id varchar2(128 char) not null,
        ftr_device_id varchar2(64 char),
        ftr_authnr_version varchar2(16 char),
        ftr_att_cert_sign blob,
        ftr_frndly_name varchar2(64 char),
        ftr_pub_key varchar2(1024 char) not null,
        ftr_pub_key_alg_encoding number(10,0) not null,
        ftr_reg_counter number(19,0),
        ftr_tcDisplayPNGChar varchar2(1024 char),
        ftr_created_date timestamp,
        ftr_last_modified_date timestamp,
        primary key (ftr_token_uuid)
    );
	
    create index idx_ftr_aaid_key_id_hash on am_fidotokenrecord (ftr_aaid_key_id_hash);
    
    create unique index idx_ftr_aaidkeyidhash_keyid on am_fidotokenrecord(ftr_aaid_key_id_hash,ftr_key_id);
    
    create table am_ucmgwsession_archived (
        gs_short_session_id varchar2(32 char) not null,
        gs_requester_id varchar2(50 char),
        gs_windows_account varchar2(50 char),
        gs_gateway_ip varchar2(256 char),
        gs_remote_desktop_ip varchar2(40 char),
        gs_start_time timestamp,
        gs_end_time timestamp,
        gs_last_heart_beat timestamp,
        gs_has_finish_recording number(1,0),
        gs_has_finish_converting number(1,0),
        gs_hash varchar2(64 char),
        gs_reviewed_by varchar2(64 char),
        gs_review_time timestamp,
        gs_has_failed number(1,0),
        gs_processed_by varchar2(64 char),
        gs_remote_session_id varchar2(32 char),
        gs_sequence number(10,0),
        gs_last_chunk_time number(19,0),
        gs_cleanup_date number(19,0),
        primary key (gs_short_session_id)
    );
    
    create table am_ucmrecordedapp_archived (
        ra_short_session_id varchar2(32 char) not null,
        ra_pid number(10,0) not null,
        ra_app_path varchar2(255 char),
        ra_title varchar2(255 char),
        ra_start_time timestamp,
        ra_end_time timestamp,
        ra_target_resource_id varchar2(64 char),
        ra_target_resource_ip varchar2(45 char),
        ra_target_resource_port number(10,0),
        ra_sso_protocol varchar2(20 char),
        ra_credential_id varchar2(64 char),
        ra_app_gtw number(10,0),
        gs_cleanup_date number(19,0),
        primary key (ra_short_session_id, ra_pid)
    );
    
    create table am_ucmrecordedcommand_archived (
        rc_short_session_id varchar2(32 char) not null,
        rc_pid number(10,0) not null,
        rc_command_time timestamp not null,
        rc_command varchar2(700 char),
        rc_outcome varchar2(64 char),
        gs_cleanup_date number(19,0),
        primary key (rc_short_session_id, rc_pid, rc_command_time)
    );
    
    create table am_ucmtransportstream_archived (
        ts_short_session_id varchar2(32 char) not null,
        ts_sequence number(10,0) not null,
        ts_duration number(10,0),
        ts_flag number(10,0),
        ts_length number(10,0),
        gs_cleanup_date number(19,0),
        primary key (ts_short_session_id, ts_sequence)
    );
    
    update am_vars set va_value='1067', va_version = va_version + 1 where va_name='SchemaVersion';
 	
-- END OF AccessMatrix Server Schema Update 5.4.2 (1062) to 5.5.0 (1067)
-- EndOfSchemaVersion1067

    
-- SchemaVersion1072
-- START OF AccessMatrix Server Schema Update 5.5.0 (1067) to 5.5.2 (1072)    

    create index idx_tst_status_date_uuid on am_tokenauthstate(tst_status, tst_last_modified_date, tst_token_uuid);

    drop index idx_ftr_aaid_key_id_hash;

    drop index idx_ftr_aaidkeyidhash_keyid;

    create unique index idx_ftr_aaidkeyidhash on am_fidotokenrecord(ftr_aaid_key_id_hash);

  
   create table am_idmapping (
        im_user_uuid varchar2(64 char) not null,
        im_ext_app_uuid varchar2(64 char) not null,
        im_ext_id varchar2(64 char) not null,
        im_partition number(10,0),
        im_ext_id_upper varchar2(64 char) not null,
        im_unique_id_app varchar2(8 char) not null,
        im_ext_id_type varchar2(16 char) not null,
        im_other_attr1 varchar2(2048 char),
        im_other_attr2 varchar2(2048 char),
        im_profile_name varchar2(16 char) not null,
        im_created_time timestamp not null,
        primary key (im_user_uuid, im_ext_app_uuid, im_ext_id)
    );

      create unique index idx_im_app_id_unique on am_idmapping(im_ext_app_uuid,im_ext_id,im_unique_id_app);

    create unique index idx_im_user_app_profile on am_idmapping(im_user_uuid, im_ext_app_uuid, im_profile_name);

    create index idx_im_app_id on am_idmapping(im_ext_app_uuid,im_ext_id);

    create index idx_im_app_idu on am_idmapping(im_ext_app_uuid,im_ext_id_upper);

    create index idx_im_user_app_idu on am_idmapping(im_user_uuid, im_ext_app_uuid,im_ext_id_upper);
	
	alter table am_ucmgwsession add gs_closed_by varchar(64);

    alter table am_ucmgwsession add gs_session_status number(10,0);
	
	alter table am_ucmgwsession_archived add gs_closed_by varchar(64);

    alter table am_ucmgwsession_archived add gs_session_status number(10,0);
    
    update am_vars set va_value='1072', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.5.0 (1067) to 5.5.2 (1072) 
-- EndOfSchemaVersion1072    
    
-- SchemaVersion1077
-- START OF AccessMatrix Server Schema Update 5.5.2 (1072) to 5.6.0 (1077) 

    alter table am_audit modify (au_attr2_char16 varchar2(32));
    
    update am_vars set va_value='1077', va_version = va_version + 1 where va_name='SchemaVersion';
    
-- END OF AccessMatrix Server Schema Update 5.5.2 (1072) to 5.6.0 (1077)   
-- EndOfSchemaVersion1077

-- SchemaVersion1082
-- START OF AccessMatrix Server Schema Update 5.6.0 (1077) to 5.6.1 (1082)  
    
	alter table am_fidotokenrecord add ftr_device_type varchar(10);
   
	create table am_oauthtoken (
        ot_iid varchar2(22 char) not null,
        ot_user_uuid varchar2(64 char),
        ot_type varchar2(3 char),
        ot_client_uuid varchar2(64 char),
        ot_expiry_time number(19,0),
        ot_created_time number(19,0),
        primary key (ot_iid)
    );
    
    create index idx_ot_expiryTime on am_oauthtoken (ot_expiry_time);
    
    create index idx_ot_usruuid_exp on am_oauthtoken(ot_user_uuid,ot_expiry_time);
    
    create index idx_ot_usruuid_typ_exp on am_oauthtoken(ot_user_uuid,ot_type,ot_expiry_time);


    update am_vars set va_value='1082', va_version = va_version + 1 where va_name='SchemaVersion';
    
-- END OF AccessMatrix Server Schema Update 5.6.0 (1077) to 5.6.1 (1082)   
-- EndOfSchemaVersion1082

-- SchemaVersion1087
-- START OF AccessMatrix Server Schema Update 5.6.1 (1082) to 5.6.2 (1087)
    
    create table am_user_key (
        ky_uuid varchar2(16 char) not null,
        ky_user_uuid varchar2(64 char),
        ky_key_id varchar2(64 char),
        ky_status varchar2(16 char),
        ky_cryptoapp_uuid varchar2(64 char),
        ky_key_provider_uuid varchar2(64 char),
        ky_key_algo varchar2(64 char),
        ky_private_key varchar2(1800 char),
        ky_public_key varchar2(1024 char),
        ky_key_usage varchar2(64 char),
        ky_created_time number(19,0),
        ky_modified_time number(19,0),
        ky_last_status_change_time number(19,0),
        primary key (ky_uuid)
    );
    
    create index idx_ky_user_uuid on am_user_key(ky_user_uuid);
    
    create unique index idx_ky_user_uuid_key_id on am_user_key(ky_user_uuid,ky_key_id);
    
    create index idx_ky_cryptoapp_user_uuid on am_user_key(ky_cryptoapp_uuid, ky_user_uuid);
    
    update am_vars set va_value='1087', va_version = va_version + 1 where va_name='SchemaVersion';
    
-- END OF AccessMatrix Server Schema Update 5.6.1 (1082) to 5.6.2 (1087)
-- EndOfSchemaVersion1087

-- SchemaVersion1092
-- START OF AccessMatrix Server Schema Update 5.6.2 (1087) to 5.6.3 (1092)
    create table am_user_device (
        de_uuid varchar2(16 char) not null,
        de_status varchar2(16 char),
        de_type varchar2(16 char),
        de_id varchar2(64 char),
        de_agent varchar2(64 char),
        de_desc varchar2(64 char),
        de_created_time number(19,0),
        de_admin_modifier varchar2(64 char),
        de_admin_modified_time number(19,0),
        de_last_status_change number(19,0),
        de_last_used_time number(19,0),
        primary key (de_uuid)
    );
    
    create table am_relation_device_token (
        rdt_device_uuid varchar2(64 char) not null,
        rdt_token_uuid varchar2(64 char) not null,
        rdt_token_instance varchar2(64 char) not null,
        rdt_created_time number(19,0),
        primary key (rdt_device_uuid, rdt_token_uuid, rdt_token_instance)
    );
    
    create table am_relation_device_user (
        rdu_device_uuid varchar2(64 char) not null,
        rdu_user_uuid varchar2(64 char) not null,
        rdu_created_time number(19,0),
        primary key (rdu_device_uuid, rdu_user_uuid)
    );
    
    create unique index idx_de_type_id on am_user_device(de_type,de_id);
    
    create index idx_rdu_user_uuid on am_relation_device_user(rdu_user_uuid);
    
    create index idx_rdt_token_uuid_instance on am_relation_device_token(rdt_token_uuid, rdt_token_instance);
    
-- Secondary Account migration script (from am_object table to am_idmapping table)
    insert into am_idmapping (im_user_uuid, im_ext_app_uuid, im_ext_id, im_ext_id_upper, im_unique_id_app, im_ext_id_type, im_profile_name, im_created_time)
    select ob_parent_uuid, ob_id, ob_discriminator1, upper(ob_discriminator1), ob_uuid, 'SecondaryAccount', 'profile1', ob_created_time from am_object where ob_object_class='SecondaryAccount';

-- This deletion query does not have to be done immediately, it can be done much later--
-- delete from am_object where ob_uuid in (select im_unique_id_app from am_idmapping) and ob_object_class='SecondaryAccount';

    create table am_usersession (
        usn_uuid varchar2(64 char) not null,
        usn_version number(19,0) not null,
        usn_count number(10,0),
        usn_earliest_expy number(19,0),
        usn_latest_expy number(19,0),
        usn_last_update number(19,0),
        usn_sec_hash varchar2(128 char),
        usn_sessions varchar2(3072 char),
        primary key (usn_uuid)
    );
    
    update am_vars set va_value='1092', va_version = va_version + 1 where va_name='SchemaVersion';
    
-- END OF AccessMatrix Server Schema Update 5.6.2 (1087) to 5.6.3 (1092)
-- EndOfSchemaVersion1092

-- SchemaVersion1097
-- START OF AccessMatrix Server Schema Update 5.6.3 (1092) to 5.6.4 (1097)

    create table am_audit_a (
        au_server_id number(10,0) not null,
        au_id number(19,0) not null,
        au_reported_time timestamp not null,
        au_module_name varchar2(12 char),
        au_category varchar2(32 char) not null,
        au_type varchar2(32 char) not null,
        au_result varchar2(20 char),
        au_result_code varchar2(16 char),
        au_ext_result_code varchar2(16 char),
        au_message varchar2(256 char),
        au_tx_id varchar2(32 char),
        au_signature varchar2(96 char),
        au_actor_class varchar2(32 char),
        au_actor_uuid varchar2(64 char),
        au_actor_id varchar2(64 char),
        au_actor_user_store varchar2(64 char),
        au_actor_ses_id varchar2(64 char),
        au_actor_seg_uuid varchar2(64 char),
        au_actor_ip_addr varchar2(45 char),
        au_real_actor_id varchar2(64 char),
        au_real_actor_user_store varchar2(64 char),
        au_real_actor_ses_id varchar2(64 char),
        au_real_actor_seg_uuid varchar2(64 char),
        au_client_id varchar2(45 char),
        au_client_type number(10,0),
        au_target_class varchar2(32 char),
        au_target_uuid varchar2(64 char),
        au_target_id varchar2(64 char),
        au_target_user_store varchar2(64 char),
        au_target_seg_uuid varchar2(64 char),
        au_custom_desc varchar2(256 char),
        au_attr1_char16 varchar2(16 char),
        au_attr2_char16 varchar2(32 char),
        au_attr3_char32 varchar2(32 char),
        au_attr4_char32 varchar2(32 char),
        au_attr5_char64 varchar2(64 char),
        au_attr6_char64 varchar2(64 char),
        au_attr7_char64 varchar2(64 char),
        au_attr8_char128 varchar2(128 char),
        au_flag1 number(1,0),
        au_flag2 number(1,0),
        au_flag3 number(1,0),
        au_flag4 number(1,0),
        au_attr1_num number(19,0),
        au_attr2_num number(19,0),
        au_attr3_num number(19,0),
        au_attr4_num number(19,0),
        au_time1 timestamp,
        au_time2 timestamp,
        au_time3 timestamp,
        au_time4 timestamp,
        primary key (au_server_id, au_id)
    );

    create table am_audit_attr_a (
        aa_server_id number(10,0) not null,
        aa_id number(19,0) not null,
        aa_name varchar2(64 char) not null,
        aa_part number(10,0) not null,
        aa_name_upper varchar2(64 char) not null,
        aa_datatype varchar2(16 char) not null,
        aa_value varchar2(3072 char),
        primary key (aa_server_id, aa_id, aa_name, aa_part)
    );

    create table am_audit_b (
        au_server_id number(10,0) not null,
        au_id number(19,0) not null,
        au_reported_time timestamp not null,
        au_module_name varchar2(12 char),
        au_category varchar2(32 char) not null,
        au_type varchar2(32 char) not null,
        au_result varchar2(20 char),
        au_result_code varchar2(16 char),
        au_ext_result_code varchar2(16 char),
        au_message varchar2(256 char),
        au_tx_id varchar2(32 char),
        au_signature varchar2(96 char),
        au_actor_class varchar2(32 char),
        au_actor_uuid varchar2(64 char),
        au_actor_id varchar2(64 char),
        au_actor_user_store varchar2(64 char),
        au_actor_ses_id varchar2(64 char),
        au_actor_seg_uuid varchar2(64 char),
        au_actor_ip_addr varchar2(45 char),
        au_real_actor_id varchar2(64 char),
        au_real_actor_user_store varchar2(64 char),
        au_real_actor_ses_id varchar2(64 char),
        au_real_actor_seg_uuid varchar2(64 char),
        au_client_id varchar2(45 char),
        au_client_type number(10,0),
        au_target_class varchar2(32 char),
        au_target_uuid varchar2(64 char),
        au_target_id varchar2(64 char),
        au_target_user_store varchar2(64 char),
        au_target_seg_uuid varchar2(64 char),
        au_custom_desc varchar2(256 char),
        au_attr1_char16 varchar2(16 char),
        au_attr2_char16 varchar2(32 char),
        au_attr3_char32 varchar2(32 char),
        au_attr4_char32 varchar2(32 char),
        au_attr5_char64 varchar2(64 char),
        au_attr6_char64 varchar2(64 char),
        au_attr7_char64 varchar2(64 char),
        au_attr8_char128 varchar2(128 char),
        au_flag1 number(1,0),
        au_flag2 number(1,0),
        au_flag3 number(1,0),
        au_flag4 number(1,0),
        au_attr1_num number(19,0),
        au_attr2_num number(19,0),
        au_attr3_num number(19,0),
        au_attr4_num number(19,0),
        au_time1 timestamp,
        au_time2 timestamp,
        au_time3 timestamp,
        au_time4 timestamp,
        primary key (au_server_id, au_id)
    );

    create table am_audit_attr_b (
        aa_server_id number(10,0) not null,
        aa_id number(19,0) not null,
        aa_name varchar2(64 char) not null,
        aa_part number(10,0) not null,
        aa_name_upper varchar2(64 char) not null,
        aa_datatype varchar2(16 char) not null,
        aa_value varchar2(3072 char),
        primary key (aa_server_id, aa_id, aa_name, aa_part)
    );
    
    create table am_audit_c (
        au_server_id number(10,0) not null,
        au_id number(19,0) not null,
        au_reported_time timestamp not null,
        au_module_name varchar2(12 char),
        au_category varchar2(32 char) not null,
        au_type varchar2(32 char) not null,
        au_result varchar2(20 char),
        au_result_code varchar2(16 char),
        au_ext_result_code varchar2(16 char),
        au_message varchar2(256 char),
        au_tx_id varchar2(32 char),
        au_signature varchar2(96 char),
        au_actor_class varchar2(32 char),
        au_actor_uuid varchar2(64 char),
        au_actor_id varchar2(64 char),
        au_actor_user_store varchar2(64 char),
        au_actor_ses_id varchar2(64 char),
        au_actor_seg_uuid varchar2(64 char),
        au_actor_ip_addr varchar2(45 char),
        au_real_actor_id varchar2(64 char),
        au_real_actor_user_store varchar2(64 char),
        au_real_actor_ses_id varchar2(64 char),
        au_real_actor_seg_uuid varchar2(64 char),
        au_client_id varchar2(45 char),
        au_client_type number(10,0),
        au_target_class varchar2(32 char),
        au_target_uuid varchar2(64 char),
        au_target_id varchar2(64 char),
        au_target_user_store varchar2(64 char),
        au_target_seg_uuid varchar2(64 char),
        au_custom_desc varchar2(256 char),
        au_attr1_char16 varchar2(16 char),
        au_attr2_char16 varchar2(32 char),
        au_attr3_char32 varchar2(32 char),
        au_attr4_char32 varchar2(32 char),
        au_attr5_char64 varchar2(64 char),
        au_attr6_char64 varchar2(64 char),
        au_attr7_char64 varchar2(64 char),
        au_attr8_char128 varchar2(128 char),
        au_flag1 number(1,0),
        au_flag2 number(1,0),
        au_flag3 number(1,0),
        au_flag4 number(1,0),
        au_attr1_num number(19,0),
        au_attr2_num number(19,0),
        au_attr3_num number(19,0),
        au_attr4_num number(19,0),
        au_time1 timestamp,
        au_time2 timestamp,
        au_time3 timestamp,
        au_time4 timestamp,
        primary key (au_server_id, au_id)
    );

    create table am_audit_attr_c (
        aa_server_id number(10,0) not null,
        aa_id number(19,0) not null,
        aa_name varchar2(64 char) not null,
        aa_part number(10,0) not null,
        aa_name_upper varchar2(64 char) not null,
        aa_datatype varchar2(16 char) not null,
        aa_value varchar2(3072 char),
        primary key (aa_server_id, aa_id, aa_name, aa_part)
    );

    create index idx_au_actor_id_a on am_audit_a (au_actor_id);
    create index idx_au_reported_time_a on am_audit_a (au_reported_time);
    create index idx_au_actor_uuid_a on am_audit_a (au_actor_uuid);
    create index idx_au_taget_id_a on am_audit_a (au_target_id);
    create index idx_au_target_uuid_a on am_audit_a (au_target_uuid);
    create index idx_au_result_code_a on am_audit_a (au_result_code);
    create index idx_au_actor_id_b on am_audit_b (au_actor_id);
    create index idx_au_reported_time_b on am_audit_b (au_reported_time);
    create index idx_au_actor_uuid_b on am_audit_b (au_actor_uuid);
    create index idx_au_taget_id_b on am_audit_b (au_target_id);
    create index idx_au_target_uuid_b on am_audit_b (au_target_uuid);
    create index idx_au_result_code_b on am_audit_b (au_result_code);
    create index idx_au_actor_id_c on am_audit_c (au_actor_id);
    create index idx_au_actor_uuid_c on am_audit_c (au_actor_uuid);
    create index idx_au_reported_time_c on am_audit_c (au_reported_time);
    create index idx_au_taget_id_c on am_audit_c (au_target_id);
    create index idx_au_target_uuid_c on am_audit_c (au_target_uuid);
    create index idx_au_result_code_c on am_audit_c (au_result_code);
    create index idx_au_cat_type_time_a on am_audit_a(au_category,au_type,au_reported_time);
    create index idx_au_cat_type_time_b on am_audit_b(au_category,au_type,au_reported_time);
    create index idx_au_cat_type_time_c on am_audit_c(au_category,au_type,au_reported_time);
    create index idx_aa_name_id_sid_a on am_audit_attr_a(aa_name,aa_id,aa_server_id);
    create index idx_aa_nameu_id_sid_a on am_audit_attr_a(aa_name_upper,aa_id,aa_server_id);
    create index idx_aa_name_id_sid_b on am_audit_attr_b(aa_name,aa_id,aa_server_id);
    create index idx_aa_nameu_id_sid_b on am_audit_attr_b(aa_name_upper,aa_id,aa_server_id);
    create index idx_aa_name_id_sid_c on am_audit_attr_c(aa_name,aa_id,aa_server_id);
    create index idx_aa_nameu_id_sid_c on am_audit_attr_c(aa_name_upper,aa_id,aa_server_id);
    
    create index idx_usn_latest_expy on am_usersession(usn_latest_expy);
    
	create view am_vw_audit_b_a as select * from am_audit_b union all select * from am_audit_a;
	create view am_vw_audit_c_b as select * from am_audit_c union all select * from am_audit_b;
	create view am_vw_audit_a_c as select * from am_audit_a union all select * from am_audit_c;
	
	create view am_vw_audit_attribute_b_a as select * from am_audit_attr_b union all select * from am_audit_attr_a;
	create view am_vw_audit_attribute_c_b as select * from am_audit_attr_c union all select * from am_audit_attr_b;
	create view am_vw_audit_attribute_a_c as select * from am_audit_attr_a union all select * from am_audit_attr_c;

	-- Uncomment and run to move audits to new table
	-- insert into am_audit_c ( au_server_id, au_id, au_reported_time, au_module_name, au_category,
        -- au_type, au_result, au_result_code, au_ext_result_code, au_message,
        -- au_tx_id, au_signature, au_actor_class, au_actor_uuid, au_actor_id,
        -- au_actor_user_store, au_actor_ses_id, au_actor_seg_uuid, au_actor_ip_addr, au_real_actor_id,
        -- au_real_actor_user_store, au_real_actor_ses_id, au_real_actor_seg_uuid, au_client_id, au_client_type,
		-- au_target_class, au_target_uuid, au_target_id, au_target_user_store, au_target_seg_uuid,
        -- au_custom_desc, au_attr1_char16, au_attr2_char16, au_attr3_char32, au_attr4_char32,
        -- au_attr5_char64, au_attr6_char64, au_attr7_char64, au_attr8_char128, au_flag1,
        -- au_flag2, au_flag3, au_flag4, au_attr1_num, au_attr2_num,
        -- au_attr3_num, au_attr4_num, au_time1, au_time2, au_time3, au_time4)
    -- select 
        -- au_server_id, au_id, au_reported_time, au_module_name, au_category,
        -- au_type, au_result, au_result_code, au_ext_result_code, au_message,
        -- au_tx_id, au_signature, au_actor_class, au_actor_uuid, au_actor_id,
        -- au_actor_user_store, au_actor_ses_id, au_actor_seg_uuid, au_actor_ip_addr, au_real_actor_id,
        -- au_real_actor_user_store, au_real_actor_ses_id, au_real_actor_seg_uuid, au_client_id, au_client_type,
		-- au_target_class, au_target_uuid, au_target_id, au_target_user_store, au_target_seg_uuid,
        -- au_custom_desc, au_attr1_char16, au_attr2_char16, au_attr3_char32, au_attr4_char32,
        -- au_attr5_char64, au_attr6_char64, au_attr7_char64, au_attr8_char128, au_flag1,
        -- au_flag2, au_flag3, au_flag4, au_attr1_num, au_attr2_num,
        -- au_attr3_num, au_attr4_num, au_time1, au_time2, au_time3, au_time4
	-- from am_audit;
	-- insert into am_audit_attr_c (aa_server_id, aa_id, aa_name, aa_part, aa_name_upper, aa_datatype, aa_value)
	-- select aa_server_id, aa_id, aa_name, aa_part, aa_name_upper, aa_datatype, aa_value
	-- from am_audit_attr;

    alter table am_user_device add de_rooted number(1,0);
	
    update am_vars set va_value='1097', va_version = va_version + 1 where va_name='SchemaVersion';
    
-- END OF AccessMatrix Server Schema Update 5.6.3 (1092) to 5.6.4 (1097)
-- EndOfSchemaVersion1097

-- SchemaVersion1102
-- START OF AccessMatrix Server Schema Update 5.6.4 (1097) to 5.6.6 (1102)

	alter table am_user_device add de_custom_attr1 varchar2(64 char); 
	alter table am_user_device add de_custom_attr2 varchar2(64 char); 
	alter table am_user_device add de_custom_attr3 varchar2(64 char); 
	alter table am_user_device add de_custom_attr4 varchar2(512 char); 
	alter table am_user_device add de_custom_attr5 varchar2(512 char); 
	
	update am_vars set va_value='1102', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.6.4 (1097) to 5.6.6 (1102)
-- EndOfSchemaVersion1102

-- SchemaVersion1107
-- START OF AccessMatrix Server Schema Update 5.6.6 (1102) to 5.6.7 (1107)

	alter table am_oauthtoken add ot_grant_iid varchar2(22 char);
	
	create index idx_ot_grant_iid on am_oauthtoken(ot_grant_iid);
	
	alter table am_user_device add de_tag varchar2(256 char);
	
	update am_vars set va_value='1107', va_version = va_version +1 where va_name='SchemaVersion';
	
-- END OF AccessMatrix Server Schema Update 5.6.6 (1102) to 5.6.7 (1107)
-- EndOfSchemaVersion1107

-- SchemaVersion1112
-- START OF AccessMatrix Server Schema Update 5.6.7 (1107) to 5.6.8 (1112)

	create or replace procedure sp_truncate_am_audit(suffix in varchar2)
	as
		sql_stmt varchar2(26);
	begin
		sql_stmt := CONCAT('truncate table am_audit_', suffix);
		execute immediate sql_stmt;
	end sp_truncate_am_audit;
	/
	
	create or replace procedure sp_truncate_am_audit_attr(suffix in varchar2)
	as
		sql_stmt varchar2(32);
	begin
		sql_stmt := CONCAT('truncate table am_audit_attr_', suffix);
		execute immediate sql_stmt;
	end sp_truncate_am_audit_attr;
	/
	
	-- Uncomment the following and input the user/role that will be used to connect to AccessMatrix for additional housekeeping privileges. 

	-- grant execute on dbo.sp_truncate_am_audit to User;
	-- grant execute on dbo.sp_truncate_am_audit_attr to User;
	
	update am_vars set va_value='1112', va_version = va_version +1 where va_name='SchemaVersion';
	
-- END OF AccessMatrix Server Schema Update 5.6.7 (1107) to 5.6.8 (1112)
-- EndOfSchemaVersion1112

-- SchemaVersion1117
-- START OF AccessMatrix Server Schema Update 5.6.8 (1112) to 5.7.3 (1117)

    create table am_rp_token (
        rpt_token_uuid varchar2(64 char) not null,
    	rpt_token_hash varchar2(64 char) not null unique,
        rpt_token varchar2(3072 char) not null,
        rpt_user_uuid varchar2(64 char) not null,
        rpt_lookup_module_uuid varchar2(64 char) not null,
        rpt_type varchar2(8 char) not null,
        rpt_at_expiry_time number(19,0),
        rpt_token_expiry_time number(19,0) not null,
        rpt_session_iid varchar2(22 char),
        primary key (rpt_token_uuid)
    );
    
    create index idx_token_expiryTime on am_rp_token (rpt_token_expiry_time);

    create index idx_rpt_lookupmoduleuuid_useruuid_type_exp on am_rp_token(rpt_user_uuid,rpt_lookup_module_uuid,rpt_type);

    create index idx_rpt_sessioniid_type_exp on am_rp_token(rpt_session_iid,rpt_type);
    
    update am_vars set va_value='1117', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.6.8 (1112) to 5.7.3 (1117)
-- EndOfSchemaVersion1117

-- SchemaVersion1122
-- START OF AccessMatrix Server Schema Update 5.7.3 (1117) to 5.7.4 (1122)

    create index idx_im_app_profile on am_idmapping(im_ext_app_uuid,im_profile_name);
    
    update am_vars set va_value='1122', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.7.3 (1117) to 5.7.4 (1122)
-- EndOfSchemaVersion1122
   
-- SchemaVersion1127
-- START OF AccessMatrix Server Schema Update 5.7.4 (1122) to 5.7.5 (1127)
	
    create index idx_ot_client_uuid on am_oauthtoken(ot_client_uuid);
	
    update am_attribute set at_long_value = at_long_value/60 where at_name ='RefreshTokenValidityPeriod'; 

	update am_attribute set at_long_value = at_long_value/60, at_name='RT_ExpiryInMins', at_name_upper='RT_EXPIRYINMINS', at_datatype='LONG' where at_name ='RT_ExpiryInSecs' ;
	
	
	update am_vars set va_value='1127', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.7.4 (1122) to 5.7.5 (1127)
-- EndOfSchemaVersion1127

-- SchemaVersion1132
-- START OF AccessMatrix Server Schema Update 5.7.5 (1127) to 5.7.6 (1132)
	
	update am_attribute set at_datatype = 'MULTISTRING' where at_name ='responseAuthnContextMappings' and at_datatype = 'STRING';
	
	update am_vars set va_value='1132', va_version = va_version +1 where va_name='SchemaVersion';
	
	-- These tables are used by the Privileged Session Management feature
	-- which has been deprecated and is no longer in use.
	-- Uncomment the following DROP statements to remove them from AMDB
	--drop table LOG_COMMAND;
	--drop table LOG_LOGIN;
	--drop table LOG_SESSION;

-- END OF AccessMatrix Server Schema Update 5.7.5 (1127) to 5.7.6 (1132)	
-- EndOfSchemaVersion1132

-- SchemaVersion1137
-- START OF AccessMatrix Server Schema Update 5.7.6 (1132) to 6.0.0 (1137)

   alter table am_tokenauthstate add (
     tst_last_succ_date timestamp,
     tst_last_fail_date timestamp);

   update am_vars set va_value='1137', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.7.6 (1132) to 6.0.0 (1137)
-- EndOfSchemaVersion1137
