-- SchemaVersion1010
-- START OF AccessMatrix Server Schema Update 5.0.4/5.0.5 to 5.0.6/5.0.7 (1010)

    create table am_pinmailer (
        pm_uuid varchar(64) not null,
        pm_version bigint not null,
        pm_id varchar(64) not null unique,
        pm_entry_uid varchar(32),
        pm_template_id varchar(64),
        pm_module_id varchar(64),
        pm_content_type varchar(32),
        pm_content_action varchar(32),
        pm_status varchar(32),
        pm_content_uuid varchar(64),
        pm_content_summary varchar(256),
        pm_template_uuid varchar(64),
        pm_channel_uuid varchar(64),
        pm_delivery_summary varchar(256),
        pm_maker varchar(64),
        pm_made_time timestamp,
        pm_checker varchar(64),
        pm_checked_time timestamp,
        pm_creator varchar(64),
        pm_created_time timestamp,
        pm_modifier varchar(64),
        pm_modified_time timestamp,
        pm_ended smallint,
        pm_attr1_char16 varchar(16),
        pm_attr2_char16 varchar(16),
        pm_attr3_char32 varchar(32),
        pm_attr4_char32 varchar(32),
        pm_attr5_char64 varchar(64),
        pm_attr6_char64 varchar(64),
        pm_attr7_char128 varchar(128),
        pm_attr8_char256 varchar(256),
        pm_flag1 smallint,
        pm_flag2 smallint,
        pm_number1 bigint,
        pm_number2 bigint,
        pm_time1 timestamp,
        pm_time2 timestamp,
        primary key (pm_uuid)
    );

    create table am_pinmailer_attr (
        pa_uuid varchar(64) not null,
        pa_name varchar(64) not null,
        pa_part integer not null,
        pa_name_upper varchar(64) not null,
        pa_datatype varchar(16) not null,
        pa_enctype char(1) not null,
        pa_value varchar(3072),
        primary key (pa_uuid, pa_name, pa_part)
    );

    create table am_vars (
        va_name varchar(64) not null,
        va_version bigint not null,
        va_value varchar(256),
        primary key (va_name)
    );

    create table am_wfentry_hilo (
         next_hi integer
    );

    insert into am_wfentry_hilo values ( 0 );

    create table am_wfother_hilo (
         next_hi integer
    );

    drop table hibernate_unique_key;

    insert into am_wfother_hilo values ( 0 );

    create index idx_pa_name_uuid on am_pinmailer_attr(pa_name, pa_uuid);

    create index idx_pa_nameu_uuid on am_pinmailer_attr(pa_name_upper, pa_uuid);

    insert into am_vars (va_name, va_version, va_value) values ('SchemaVersion', 1, '1010');

-- END OF AccessMatrix Server Schema Update 5.0.4/5.0.5 to 5.0.6/5.0.7 (1010)
-- EndOfSchemaVersion1010

-- SchemaVersion1011
-- START OF AccessMatrix Server Schema Update 5.0.6/5.0.7 (1010) to 5.0.8 (1011)

    create table am_tokenauthstate (
        tst_token_uuid varchar(64) not null,
        tst_func_id varchar(32) not null,
        tst_auth_mode varchar(8) not null,
        tst_version bigint not null,
        tst_partition integer,
        tst_status varchar(20),
        tst_success_cnt integer,
        tst_fail_cnt integer,
        tst_last_stat_chg_date timestamp,
        tst_sec_hash varchar(128),
        tst_sec_data varchar(2048),
        tst_other_attrs varchar(1024),
        tst_last_modified_date timestamp,
        primary key (tst_token_uuid, tst_func_id, tst_auth_mode)
    );

    create table am_userauthstate (
        ust_user_uuid varchar(64) not null,
        ust_type varchar(3) not null,
        ust_auth_uuid varchar(64) not null,
        ust_version bigint not null,
        ust_partition integer,
        ust_status varchar(20),
        ust_control_flag varchar(3),
        ust_start_date timestamp,
        ust_end_date timestamp,
        ust_success_cnt integer,
        ust_fail_cnt integer,
        ust_last_login_date timestamp,
        ust_last_logout_date timestamp,
        ust_last_pwd_chg_date timestamp,
        ust_last_stat_chg_date timestamp,
        ust_sec_hash varchar(128),
        ust_other_attrs varchar(2048),
        ust_last_modified_date timestamp,
        primary key (ust_user_uuid, ust_type, ust_auth_uuid)
    );

    update am_vars set va_value='1011', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.0.6/5.0.7 (1010) to 5.0.8 (1011)
-- EndOfSchemaVersion1011

-- SchemaVersion1012
-- START OF AccessMatrix Server Schema Update 5.0.8 (1011) to 5.0.9 (1012)

    drop table am_session;

    create table am_ucmattr (
        at_objclass varchar(32) not null,
        at_uuid varchar(64) not null,
        at_name varchar(64) not null,
        at_sequence integer not null,
        at_version bigint not null,
        at_type integer,
        at_intvalue integer,
        at_stringvalue varchar(256),
        at_timestampvalue timestamp,
        at_booleanvalue smallint,
        primary key (at_objclass, at_uuid, at_name, at_sequence)
    );

    create table am_ucmchkout (
        cko_cruuid varchar(64) not null,
        cko_rquuid varchar(64) not null,
        cko_crversion bigint not null,
        cko_lockreq varchar(64) not null,
        cko_outtime timestamp,
        cko_intime timestamp,
        cko_exptime timestamp,
        cko_remark varchar(512),
        cko_attr1_int integer,
        cko_attr1_str32 varchar(32),
        cko_attr_json varchar(1024),
        primary key (cko_cruuid, cko_rquuid, cko_crversion, cko_lockreq)
    );

    create table am_ucmcred (
        cr_uuid varchar(64) not null,
        cr_object_class varchar(32) not null,
        cr_version bigint not null,
        cr_id varchar(64) not null,
        cr_id_upper varchar(64) not null,
        cr_description varchar(256),
        cr_status varchar(255),
        cr_workflow_state integer,
        cr_usagemode integer,
        cr_reqapplvl integer,
        cr_curapplvl integer,
        cr_force_chkin smallint,
        cr_auto_password_update smallint,
        cr_lastpwdupd_result integer,
        cr_lastpwdupd_msg varchar(256),
        cr_lastpwdupd_time timestamp,
        cr_lasttestlogin_msg varchar(256),
        cr_lasttestlogin_time timestamp,
        cr_lasttestlogin_result integer,
        cr_targetrsc_uuid varchar(64),
        cr_safe_uuid varchar(64),
        cr_userid varchar(64),
        cr_lockreq_uuid varchar(64),
        cr_value varchar(1024),
        cr_numofparts integer,
        cr_parentcred_uuid varchar(64),
        cr_partindex integer,
        primary key (cr_uuid)
    );

    create table am_ucmrel (
        re_uuid1 varchar(64) not null,
        re_relation integer not null,
        re_uuid2 varchar(64) not null,
        re_sequence bigint not null,
        re_objclass1 varchar(32),
        re_objclass2 varchar(32),
        re_created_time timestamp,
        re_creator_uuid varchar(64),
        re_lastmodified_time timestamp,
        re_lastmodifier_uuid varchar(64),
        re_attr1char16 varchar(16),
        re_attr2char32 varchar(32),
        re_attr3char64 varchar(64),
        re_attr4char128 varchar(128),
        re_attr4char1024 varchar(1024),
        re_attr1int integer,
        re_attr2int integer,
        re_attr1time timestamp,
        re_attr2time timestamp,
        primary key (re_uuid1, re_relation, re_uuid2, re_sequence)
    );

    create table am_ucmreq (
        req_uuid varchar(64) not null,
        req_version bigint not null,
        req_title varchar(256),
        req_workflow_name varchar(64),
        req_workflow_id bigint,
        req_workflow_state integer,
        req_reqapplvl integer,
        req_curapplvl integer,
        req_creator_uuid varchar(64),
        req_created_time timestamp,
        req_lastmodifier_uuid varchar(64),
        req_lastmodified_time timestamp,
        req_chkout_starttime timestamp,
        req_chkout_endtime timestamp,
        primary key (req_uuid)
    );

    create table am_ucmtagdesc (
        cr_uuid varchar(64) not null,
        tag_id varchar(64) not null,
        tag_value varchar(64) not null,
        primary key (cr_uuid, tag_id, tag_value)
    );

    create index idx_ucmcr_idu on am_ucmcred (cr_id_upper);

    create index idx_ucmcr_sf on am_ucmcred (cr_safe_uuid);

    create index idx_ucmcr_tr on am_ucmcred (cr_targetrsc_uuid);

    create index idx_ucmcr_id on am_ucmcred (cr_id);

    create index idx_ucmcr_01 on am_ucmcred(cr_object_class,cr_id);

    create index idx_ucmcr_02 on am_ucmcred(cr_object_class,cr_id_upper);

    create index idx_ucmcko_01 on am_ucmchkout(cko_rquuid, cko_lockreq, cko_cruuid);

    create index idx_ucmcko_02 on am_ucmchkout(cko_lockreq, cko_cruuid, cko_rquuid);

    create index idx_ust_type_auth_user on am_userauthstate(ust_type,ust_auth_uuid,ust_user_uuid);

    update am_vars set va_value='1012', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.0.8 (1011) to 5.0.9 (1012)
-- EndOfSchemaVersion1012

-- SchemaVersion1013
-- START OF AccessMatrix Server Schema Update 5.0.9 (1012) to 5.1.2 (1013)

--    alter table am_attribute add column at_modified_time timestamp;

    create table am_biometric (
        bm_usr_uuid varchar(64) not null,
        bm_vendor integer not null,
        bm_type integer not null,
        bm_label varchar(8) not null,
        bm_version bigint not null,
        bm_refer_tplt blob(5120) not null,
        bm_status integer,
        bm_partition integer,
        bm_last_verified_time timestamp,
        bm_creation_time timestamp,
        bm_modified_time timestamp,
        bm_sec_hash varchar(128),
        primary key (bm_usr_uuid, bm_vendor, bm_type, bm_label)
    );

    create table am_impersonation (
        imp_impersonated_uuid varchar(64) not null,
        imp_impersonator_uuid varchar(64) not null,
        imp_impersonator_oc varchar(32) not null,
        imp_sequence integer not null,
        imp_start_time timestamp,
        imp_end_time timestamp,
        imp_last_modified_time timestamp,
        imp_last_modifier_uuid varchar(64),
        primary key (imp_impersonated_uuid, imp_impersonator_uuid, imp_impersonator_oc, imp_sequence)
    );

    create table am_impersonation_obj (
        impobj_impersonated_uuid varchar(64) not null,
        impobj_impersonator_uuid varchar(64) not null,
        impobj_impersonator_oc varchar(32) not null,
        imp_sequence integer not null,
        impobj_obj_uuid varchar(64) not null,
        impobj_obj_oc varchar(32) not null,
        impobj_other_attrs varchar(2048),
        primary key (impobj_impersonated_uuid, impobj_impersonator_uuid, impobj_impersonator_oc, imp_sequence, impobj_obj_uuid, impobj_obj_oc)
    );

    create table log_command_hilo (
         next_hi integer 
    );

    insert into log_command_hilo values ( 0 );

    create index idx_pm_maker on am_pinmailer (pm_maker);

    create index idx_pm_status on am_pinmailer (pm_status);

    create index idx_pm_content on am_pinmailer (pm_content_uuid);

    create index idx_pm_end_modtime on am_pinmailer(pm_ended,pm_modified_time);

    create index idx_pm_entryuid_modtime on am_pinmailer(pm_entry_uid,pm_modified_time);

    create index idx_bm_uuid_vendor_label_type on am_biometric(bm_usr_uuid,bm_vendor,bm_label,bm_type);

    create index idx_imp_impersonator on am_impersonation(imp_impersonator_uuid,imp_impersonator_oc,imp_sequence,imp_impersonated_uuid);

    update am_vars set va_value='1013', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.0.9 (1012) to 5.1.2 (1013)
-- EndOfSchemaVersion1013

-- SchemaVersion1014
-- START OF AccessMatrix Server Schema Update 5.1.2 (1013) to 5.1.2 (1014)

    alter table am_audit alter au_client_id set data type varchar(45);

    alter table am_audit alter au_actor_ip_addr set data type varchar(45);

    update am_vars set va_value='1014', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.1.2 (1013) to 5.1.2 (1014)
-- EndOfSchemaVersion1014

-- SchemaVersion1015
-- START OF AccessMatrix Server Schema Update 5.1.2 (1014) to 5.1.2 (1015)

-- Only for migrating 5.1.2.1200-5.1.2.1214 to 5.1.2.1215 and biometric was not used
--  drop table am_biometric;
--  create table am_biometric (
--      bm_usr_uuid varchar(64) not null,
--      bm_vendor integer not null,
--      bm_type integer not null,
--      bm_label varchar(8) not null,
--      bm_version bigint not null,
--      bm_refer_tplt blob(5120) not null,
--      bm_status integer,
--      bm_partition integer,
--      bm_last_verified_time timestamp,
--      bm_creation_time timestamp,
--      bm_modified_time timestamp,
--      bm_sec_hash varchar(128),
--      primary key (bm_usr_uuid, bm_vendor, bm_type, bm_label)
--  );

    update am_vars set va_value='1015', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.1.2 (1014) to 5.1.2 (1015)
-- EndOfSchemaVersion1015

-- SchemaVersion1016
-- START OF AccessMatrix Server Schema Update 5.1.2 SP1 (1015) to 5.1.2 SP2 (1016)

    create table am_esso_entitlement (
        si_useruuid varchar(64) not null,
        si_appid varchar(64) not null,
        si_pid integer not null,
        si_entitlement_prn varchar(64) not null,
        si_userid varchar(64),
        si_app_userid varchar(64),
        si_share_prn varchar(64),
        si_share_res varchar(64),
        si_pwd_modified_time varchar(64),
        si_created_time timestamp,
        primary key (si_useruuid, si_appid, si_pid, si_entitlement_prn)
    );

    create index idx_esso_si_appuid on am_esso_entitlement(si_app_userid, si_appid);

    update am_vars set va_value='1016', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.1.2 SP1 (1015) to 5.1.2 SP2 (1016)
-- EndOfSchemaVersion1016

-- SchemaVersion1020
-- START OF AccessMatrix Server Schema Update 5.1.2 (1016) to 5.2.0 (1020)

    create table am_ucmaccdiscovery (
        acc_user_id varchar(64) not null,
        acc_targetrsc_id varchar(64) not null,
        acc_targetrsc_type varchar(64),
        acc_host varchar(64),
        acc_userrole varchar(64),
        acc_primarygrp varchar(64),
        acc_ucm_only smallint,
        acc_targetrsc_only smallint,
        primary key (acc_user_id, acc_targetrsc_id)
    );

    create table am_ucmgwsession (
        gs_short_session_id varchar(32) not null,
        gs_requester_id varchar(50),
        gs_windows_account varchar(50),
        gs_gateway_ip varchar(40),
        gs_remote_desktop_ip varchar(40),
        gs_start_time timestamp,
        gs_end_time timestamp,
        gs_last_heart_beat timestamp,
        gs_has_finish_recording smallint,
        gs_is_converting smallint,
        gs_video blob(2000000000),
        primary key (gs_short_session_id)
    );

    create table am_ucmrecordedapp (
        ra_short_session_id varchar(32) not null,
        ra_pid integer not null,
        ra_app_path varchar(255),
        ra_title varchar(255),
        ra_start_time timestamp,
        ra_end_time timestamp,
        ra_target_resource_id varchar(64),
        ra_target_resource_ip varchar(45),
        ra_target_resource_port integer,
        ra_sso_protocol varchar(20),
        ra_credential_id varchar(64),
        primary key (ra_short_session_id, ra_pid)
    );

    create table am_ucmrecordedcommand (
        rc_short_session_id varchar(32) not null,
        rc_pid integer not null,
        rc_command_time timestamp not null,
        rc_command varchar(700),
        primary key (rc_short_session_id, rc_pid, rc_command_time)
    );

    create table am_ucmtmpvideo (
        tv_short_session_id varchar(32) not null,
        tv_israw smallint not null,
        tv_sequence integer not null,
        tv_video_chunk blob(100000000),
        tv_isbeing_processed smallint,
        primary key (tv_short_session_id, tv_israw, tv_sequence)
    );

    create index idx_ucmgwsession_01 on am_ucmgwsession(gs_has_finish_recording, gs_short_session_id);
    create index idx_ucmrecordedapp_01 on am_ucmrecordedapp(ra_app_path);
    create index idx_ucmrecordedapp_02 on am_ucmrecordedapp(ra_title);
    create index idx_ucmrecordedcommand_01 on am_ucmrecordedcommand(rc_command);

    update am_vars set va_value='1020', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.1.2 (1016) to 5.2.0 (1020)
-- EndOfSchemaVersion1020

-- SchemaVersion1026
-- START OF AccessMatrix Server Schema Update 5.2.0 (1020) to 5.2.0 (1026)

    alter table am_attribute add at_search_value varchar(96);

    create index idx_at_name_searchvalue on am_attribute(at_name,at_search_value);

    UPDATE am_attribute SET at_search_value=UPPER(at_string_value) WHERE at_name = 'mobile' and at_class ='User' and at_enctype='N';

    update am_vars set va_value='1026', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.2.0 (1020) to 5.2.0 (1026)
-- EndOfSchemaVersion1026
    
-- SchemaVersion1027
-- START OF AccessMatrix Server Schema Update 5.2.0 (1026) to 5.2.0 SP1 (1027)

    alter table am_ucmgwsession add gs_hash varchar(64);

    update am_vars set va_value='1027', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.2.0 (1026) to 5.2.0 SP1 (1027)
-- EndOfSchemaVersion1027

-- SchemaVersion1032
-- START OF AccessMatrix Server Schema Update 5.2.0.SP1 (1027) to 5.2.2 (1032)

    alter table am_ucmgwsession add gs_reviewed_by varchar(64);

    alter table am_ucmgwsession add gs_review_time timestamp;
	
    update am_vars set va_value='1032', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.2.0.SP1 (1027) to 5.2.2 (1032)
-- EndOfSchemaVersion1032

-- SchemaVersion1037
-- START OF AccessMatrix Server Schema Update 5.2.2 (1032) to 5.3 (1037)

    create table am_ucmcredusage (
        cu_cred_uuid varchar(64) not null,
        cu_user_uuid varchar(64) not null,
        cu_counter integer,
        cu_last_chkout_time timestamp,
        primary key (cu_cred_uuid, cu_user_uuid)
    );

    create index idx_ucmcredusage_01 on am_ucmcredusage(cu_user_uuid, cu_counter);

    create index idx_ucmcredusage_02 on am_ucmcredusage(cu_user_uuid, cu_last_chkout_time);

    alter table am_ucmgwsession add gs_has_failed smallint;
    
    update am_vars set va_value='1037', va_version = va_version + 1 where va_name='SchemaVersion';
    
-- END OF AccessMatrix Server Schema Update 5.2.2 (1032) to 5.3 (1037)
-- EndOfSchemaVersion1037

-- SchemaVersion1042
-- START OF AccessMatrix Server Schema Update 5.3.0 (1037) to 5.3.2 (1042)

    create table am_contextualauthnhistory (
        ctx_uuid varchar(64) not null,
        ctx_date timestamp,
        ctx_user_uuid varchar(64),
        ctx_user_id varchar(64),
        ctx_authn_res varchar(1024),
        ctx_ip varchar(64),
        ctx_country varchar(64),
        ctx_countryisocode varchar(2),
        ctx_subdivision varchar(64),
        ctx_subdivisionisocode varchar(3),
        ctx_city varchar(64),
        ctx_latitude varchar(64),
        ctx_longitude varchar(64),
        ctx_geo_timezone varchar(64),
        ctx_module varchar(64),
        ctx_is_rooted varchar(8),
        primary key (ctx_uuid)
    );
    
-- START OF Quartz

    CREATE TABLE qrtz_job_details (
        sched_name VARCHAR(120) NOT NULL,
        job_name VARCHAR(200) NOT NULL,
        job_group VARCHAR(200) NOT NULL,
        description VARCHAR(250),
        job_class_name VARCHAR(250) NOT NULL,
        is_durable VARCHAR(5) NOT NULL,
        is_nonconcurrent VARCHAR(5) NOT NULL,
        is_update_data VARCHAR(5) NOT NULL,
        requests_recovery VARCHAR(5) NOT NULL,
        job_data blob,
        PRIMARY KEY (
            sched_name,
            job_name,
            job_group
            )
        );

    CREATE TABLE qrtz_triggers (
        sched_name VARCHAR(120) NOT NULL,
        trigger_name VARCHAR(200) NOT NULL,
        trigger_group VARCHAR(200) NOT NULL,
        job_name VARCHAR(200) NOT NULL,
        job_group VARCHAR(200) NOT NULL,
        description VARCHAR(250),
        next_fire_time BIGINT,
        prev_fire_time BIGINT,
        priority INTEGER,
        trigger_state VARCHAR(16) NOT NULL,
        trigger_type VARCHAR(8) NOT NULL,
        start_time BIGINT NOT NULL,
        end_time BIGINT,
        calendar_name VARCHAR(200),
        misfire_instr SMALLINT,
        job_data blob,
        PRIMARY KEY (
            sched_name,
            trigger_name,
            trigger_group
            ),
        FOREIGN KEY (
            sched_name,
            job_name,
            job_group
            ) REFERENCES qrtz_job_details(sched_name, job_name, job_group)
        );

    CREATE TABLE qrtz_simple_triggers (
        sched_name VARCHAR(120) NOT NULL,
        trigger_name VARCHAR(200) NOT NULL,
        trigger_group VARCHAR(200) NOT NULL,
        repeat_count BIGINT NOT NULL,
        repeat_interval BIGINT NOT NULL,
        times_triggered BIGINT NOT NULL,
        PRIMARY KEY (
            sched_name,
            trigger_name,
            trigger_group
            ),
        FOREIGN KEY (
            sched_name,
            trigger_name,
            trigger_group
            ) REFERENCES qrtz_triggers(sched_name, trigger_name, trigger_group)
        );

    CREATE TABLE qrtz_cron_triggers (
        sched_name VARCHAR(120) NOT NULL,
        trigger_name VARCHAR(200) NOT NULL,
        trigger_group VARCHAR(200) NOT NULL,
        cron_expression VARCHAR(120) NOT NULL,
        time_zone_id VARCHAR(80),
        PRIMARY KEY (
            sched_name,
            trigger_name,
            trigger_group
            ),
        FOREIGN KEY (
            sched_name,
            trigger_name,
            trigger_group
            ) REFERENCES qrtz_triggers(sched_name, trigger_name, trigger_group)
        );

    CREATE TABLE qrtz_simprop_triggers (
        sched_name VARCHAR(120) NOT NULL,
        trigger_name VARCHAR(200) NOT NULL,
        trigger_group VARCHAR(200) NOT NULL,
        str_prop_1 VARCHAR(512),
        str_prop_2 VARCHAR(512),
        str_prop_3 VARCHAR(512),
        int_prop_1 INT,
        int_prop_2 INT,
        long_prop_1 BIGINT,
        long_prop_2 BIGINT,
        dec_prop_1 NUMERIC(13, 4),
        dec_prop_2 NUMERIC(13, 4),
        bool_prop_1 VARCHAR(5),
        bool_prop_2 VARCHAR(5),
        PRIMARY KEY (
            sched_name,
            trigger_name,
            trigger_group
            ),
        FOREIGN KEY (
            sched_name,
            trigger_name,
            trigger_group
            ) REFERENCES qrtz_triggers(sched_name, trigger_name, trigger_group)
        );

    CREATE TABLE qrtz_blob_triggers (
        sched_name VARCHAR(120) NOT NULL,
        trigger_name VARCHAR(200) NOT NULL,
        trigger_group VARCHAR(200) NOT NULL,
        blob_data blob,
        PRIMARY KEY (
            sched_name,
            trigger_name,
            trigger_group
            ),
        FOREIGN KEY (
            sched_name,
            trigger_name,
            trigger_group
            ) REFERENCES qrtz_triggers(sched_name, trigger_name, trigger_group)
        );

    CREATE TABLE qrtz_calendars (
        sched_name VARCHAR(120) NOT NULL,
        calendar_name VARCHAR(200) NOT NULL,
        calendar blob NOT NULL,
        PRIMARY KEY (
            sched_name,
            calendar_name
            )
        );

    CREATE TABLE qrtz_paused_trigger_grps (
        sched_name VARCHAR(120) NOT NULL,
        trigger_group VARCHAR(200) NOT NULL,
        PRIMARY KEY (
            sched_name,
            trigger_group
            )
        );

    CREATE TABLE qrtz_fired_triggers (
        sched_name VARCHAR(120) NOT NULL,
        entry_id VARCHAR(95) NOT NULL,
        trigger_name VARCHAR(200) NOT NULL,
        trigger_group VARCHAR(200) NOT NULL,
        instance_name VARCHAR(200) NOT NULL,
        fired_time BIGINT NOT NULL,
        sched_time BIGINT NOT NULL,
        priority INTEGER NOT NULL,
        STATE VARCHAR(16) NOT NULL,
        job_name VARCHAR(200),
        job_group VARCHAR(200),
        is_nonconcurrent VARCHAR(5),
        requests_recovery VARCHAR(5),
        PRIMARY KEY (
            sched_name,
            entry_id
            )
        );

    CREATE TABLE qrtz_scheduler_state (
        sched_name VARCHAR(120) NOT NULL,
        instance_name VARCHAR(200) NOT NULL,
        last_checkin_time BIGINT NOT NULL,
        checkin_interval BIGINT NOT NULL,
        PRIMARY KEY (
            sched_name,
            instance_name
            )
        );

    CREATE TABLE qrtz_locks (
        sched_name VARCHAR(120) NOT NULL,
        lock_name VARCHAR(40) NOT NULL,
        PRIMARY KEY (
            sched_name,
            lock_name
            )
        );

-- END OF Quartz

    alter table am_ucmgwsession add gs_processed_by varchar(64);

    update am_vars set va_value='1042', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.3.0 (1037) to 5.3.2 (1042)
-- EndOfSchemaVersion1042

-- SchemaVersion1047
-- START OF AccessMatrix Server Schema Update 5.3.2 (1042) to 5.3.3 (1047)

    alter table am_ucmrecordedapp add ra_app_gtw integer;

    update am_vars set va_value='1047', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.3.2 (1042) to 5.3.3 (1047)
-- EndOfSchemaVersion1047
    
    
-- SchemaVersion1052
-- START OF AccessMatrix Server Schema Update 5.3.3 (1047) to 5.4.0 (1052)

    alter table am_ucmgwsession add gs_remote_session_id varchar(32);

    alter table am_ucmrecordedcommand add rc_outcome varchar(64);

    update am_vars set va_value='1052', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.3.3 (1047) to 5.4.0 (1052)
-- EndOfSchemaVersion1052
   
-- SchemaVersion1057
-- START OF AccessMatrix Server Schema Update 5.4.0 (1052) to 5.4.1 (1057)

    alter table am_contextualauthnhistory add ctx_authn_res_sts char(1);

    create index idx_ctx_useruuid_res_sts on am_contextualauthnhistory (ctx_user_uuid, ctx_authn_res_sts); 
	
    create index idx_ctx_date_user_uuid on am_contextualauthnhistory (ctx_date, ctx_user_uuid);
    
    alter table am_ucmgwsession add gs_sequence integer;

    create table am_ucmgwcpuusage (
        gs_gateway_ip varchar(40) not null,
        gs_collect_time timestamp not null,
        gs_cpu_usage integer,
        primary key (gs_gateway_ip, gs_collect_time)
    );
    
    update am_vars set va_value='1057', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.4.0 (1052) to 5.4.1 (1057)
-- EndOfSchemaVersion1057

    
-- SchemaVersion1062
-- START OF AccessMatrix Server Schema Update 5.4.1 (1057) to 5.4.2 (1062)

    create table am_ucmtransportstream (
        ts_short_session_id varchar(32) not null,
        ts_sequence integer not null,
        ts_duration integer,
        ts_flag integer,
        ts_length integer,
        primary key (ts_short_session_id, ts_sequence)
    );
    
    update am_attribute SET at_search_value=UPPER(at_string_value) WHERE at_name = 'email' and at_class ='User' and at_enctype='N';
    
    update am_vars set va_value='1062', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.4.1 (1057) to 5.4.2 (1062)
-- EndOfSchemaVersion1062
	
    
-- SchemaVersion1067
-- START OF AccessMatrix Server Schema Update 5.4.2 (1062) to 5.5.0 (1067)
    
    create table am_ucmrtmsession (
        gs_short_session_id varchar(32) not null,
        gs_review_time timestamp,
        primary key (gs_short_session_id)
    );
    
    alter table am_ucmgwsession alter gs_gateway_ip set data type varchar(256);
    
    alter table am_ucmgwsession add gs_last_chunk_time bigint;
    
    alter table am_ucmgwsession add gs_has_finish_converting smallint;
    
    -- Note for UCM customers: If you have existing video audit data, you need to run a migration tool before starting AM server and before dropping the following columns
    
    -- alter table am_ucmgwsession drop column gs_is_converting;
    
    -- alter table am_ucmgwsession drop column gs_video;
    
    alter table am_audit alter column au_signature set data type varchar(96);
    
    create table am_fidotokenrecord (
        ftr_token_uuid varchar(64) not null,
        ftr_aaid_key_id_hash varchar(88) not null,
        ftr_key_id varchar(512) not null,
        ftr_app_id varchar(128) not null,
        ftr_facet_id varchar(128) not null,
        ftr_device_id varchar(64),
        ftr_authnr_version varchar(16),
        ftr_att_cert_sign blob(512),
        ftr_frndly_name varchar(64),
        ftr_pub_key varchar(1024) not null,
        ftr_pub_key_alg_encoding integer not null,
        ftr_reg_counter bigint,
        ftr_tcDisplayPNGChar varchar(1024),
        ftr_created_date timestamp,
        ftr_last_modified_date timestamp,
        primary key (ftr_token_uuid)
    );
    
    create index idx_ftr_aaid_key_id_hash on am_fidotokenrecord (ftr_aaid_key_id_hash);
    
    create unique index idx_ftr_aaidkeyidhash_keyid on am_fidotokenrecord(ftr_aaid_key_id_hash,ftr_key_id);
    
    create table am_ucmgwsession_archived (
        gs_short_session_id varchar(32) not null,
        gs_requester_id varchar(50),
        gs_windows_account varchar(50),
        gs_gateway_ip varchar(256),
        gs_remote_desktop_ip varchar(40),
        gs_start_time timestamp,
        gs_end_time timestamp,
        gs_last_heart_beat timestamp,
        gs_has_finish_recording smallint,
        gs_has_finish_converting smallint,
        gs_hash varchar(64),
        gs_reviewed_by varchar(64),
        gs_review_time timestamp,
        gs_has_failed smallint,
        gs_processed_by varchar(64),
        gs_remote_session_id varchar(32),
        gs_sequence integer,
        gs_last_chunk_time bigint,
        gs_cleanup_date bigint,
        primary key (gs_short_session_id)
    );
    
    create table am_ucmrecordedapp_archived (
        ra_short_session_id varchar(32) not null,
        ra_pid integer not null,
        ra_app_path varchar(255),
        ra_title varchar(255),
        ra_start_time timestamp,
        ra_end_time timestamp,
        ra_target_resource_id varchar(64),
        ra_target_resource_ip varchar(45),
        ra_target_resource_port integer,
        ra_sso_protocol varchar(20),
        ra_credential_id varchar(64),
        ra_app_gtw integer,
        gs_cleanup_date bigint,
        primary key (ra_short_session_id, ra_pid)
    );
    
    create table am_ucmrecordedcommand_archived (
        rc_short_session_id varchar(32) not null,
        rc_pid integer not null,
        rc_command_time timestamp not null,
        rc_command varchar(700),
        rc_outcome varchar(64),
        gs_cleanup_date bigint,
        primary key (rc_short_session_id, rc_pid, rc_command_time)
    );
    
    create table am_ucmtransportstream_archived (
        ts_short_session_id varchar(32) not null,
        ts_sequence integer not null,
        ts_duration integer,
        ts_flag integer,
        ts_length integer,
        gs_cleanup_date bigint,
        primary key (ts_short_session_id, ts_sequence)
    );
    
   	update am_vars set va_value='1067', va_version = va_version + 1 where va_name='SchemaVersion';
    
-- END OF AccessMatrix Server Schema Update 5.4.2 (1062) to 5.5.0 (1067)
-- EndOfSchemaVersion1067

   	
-- SchemaVersion1072
-- START OF AccessMatrix Server Schema Update 5.5.0 (1067) to 5.5.2 (1072)    

    create index idx_tst_status_date_uuid on am_tokenauthstate(tst_status, tst_last_modified_date, tst_token_uuid);

    drop index idx_ftr_aaid_key_id_hash;

    drop index idx_ftr_aaidkeyidhash_keyid;

    create unique index idx_ftr_aaidkeyidhash on am_fidotokenrecord(ftr_aaid_key_id_hash);

   create table am_idmapping (
        im_user_uuid varchar(64) not null,
        im_ext_app_uuid varchar(64) not null,
        im_ext_id varchar(64) not null,
        im_partition integer,
        im_ext_id_upper varchar(64) not null,
        im_unique_id_app varchar(8) not null,
        im_ext_id_type varchar(16) not null,
        im_other_attr1 varchar(2048),
        im_other_attr2 varchar(2048),
        im_profile_name varchar(16) not null,
        im_created_time timestamp not null,
        primary key (im_user_uuid, im_ext_app_uuid, im_ext_id)
    );


    create unique index idx_im_app_id_unique on am_idmapping(im_ext_app_uuid,im_ext_id,im_unique_id_app);

    create unique index idx_im_user_app_profile on am_idmapping(im_user_uuid, im_ext_app_uuid, im_profile_name);

    create index idx_im_app_id on am_idmapping(im_ext_app_uuid,im_ext_id);

    create index idx_im_app_idu on am_idmapping(im_ext_app_uuid,im_ext_id_upper);

    create index idx_im_user_app_idu on am_idmapping(im_user_uuid, im_ext_app_uuid,im_ext_id_upper);
	
	alter table am_ucmgwsession add gs_closed_by varchar(64);

    alter table am_ucmgwsession add gs_session_status integer;
	
	alter table am_ucmgwsession_archived add gs_closed_by varchar(64);

    alter table am_ucmgwsession_archived add gs_session_status integer;

    update am_vars set va_value='1072', va_version = va_version + 1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.5.0 (1067) to 5.5.2 (1072) 
-- EndOfSchemaVersion1072   	

-- SchemaVersion1077
-- START OF AccessMatrix Server Schema Update 5.5.2 (1072) to 5.6.0 (1077)   

    alter table am_audit alter au_attr2_char16 set data type varchar(32);
    
    update am_vars set va_value='1077', va_version = va_version + 1 where va_name='SchemaVersion';
     
-- END OF AccessMatrix Server Schema Update 5.5.2 (1072) to 5.6.0 (1077)   
-- EndOfSchemaVersion1077

-- SchemaVersion1082
-- START OF AccessMatrix Server Schema Update 5.6.0 (1077) to 5.6.1 (1082)  
    
	alter table am_fidotokenrecord add ftr_device_type varchar(10);
	
	create table am_oauthtoken (
        ot_iid varchar(22) not null,
        ot_user_uuid varchar(64),
        ot_type varchar(3),
        ot_client_uuid varchar(64),
        ot_expiry_time bigint,
        ot_created_time bigint,
        primary key (ot_iid)
    );
    
    create index idx_ot_expiryTime on am_oauthtoken (ot_expiry_time);
    
    create index idx_ot_usruuid_exp on am_oauthtoken(ot_user_uuid,ot_expiry_time);
    
    create index idx_ot_usruuid_typ_exp on am_oauthtoken(ot_user_uuid,ot_type,ot_expiry_time);

    update am_vars set va_value='1082', va_version = va_version + 1 where va_name='SchemaVersion';
    
-- END OF AccessMatrix Server Schema Update 5.6.0 (1077) to 5.6.1 (1082)   
-- EndOfSchemaVersion1082

-- SchemaVersion1087
-- START OF AccessMatrix Server Schema Update 5.6.1 (1082) to 5.6.2 (1087)
    
    create table am_user_key (
        ky_uuid varchar(16) not null,
        ky_user_uuid varchar(64),
        ky_key_id varchar(64),
        ky_status varchar(16),
        ky_cryptoapp_uuid varchar(64),
        ky_key_provider_uuid varchar(64),
        ky_key_algo varchar(64),
        ky_private_key varchar(1800),
        ky_public_key varchar(1024),
        ky_key_usage varchar(64),
        ky_created_time bigint,
        ky_modified_time bigint,
        ky_last_status_change_time bigint,
        primary key (ky_uuid)
    );
    
    create index idx_ky_user_uuid on am_user_key(ky_user_uuid);
    
    create unique index idx_ky_user_uuid_key_id on am_user_key(ky_user_uuid,ky_key_id);
    
    create index idx_ky_cryptoapp_user_uuid on am_user_key(ky_cryptoapp_uuid, ky_user_uuid);
    
    update am_vars set va_value='1087', va_version = va_version + 1 where va_name='SchemaVersion';
    
-- END OF AccessMatrix Server Schema Update 5.6.1 (1082) to 5.6.2 (1087)
-- EndOfSchemaVersion1087

-- SchemaVersion1092
-- START OF AccessMatrix Server Schema Update 5.6.2 (1087) to 5.6.3 (1092)
    create table am_user_device (
        de_uuid varchar(16) not null,
        de_status varchar(16),
        de_type varchar(16),
        de_id varchar(64),
        de_agent varchar(64),
        de_desc varchar(64),
        de_created_time bigint,
        de_admin_modifier varchar(64),
        de_admin_modified_time bigint,
        de_last_status_change bigint,
        de_last_used_time bigint,
        primary key (de_uuid)
    );
    
    create table am_relation_device_token (
        rdt_device_uuid varchar(64) not null,
        rdt_token_uuid varchar(64) not null,
        rdt_token_instance varchar(64) not null,
        rdt_created_time bigint,
        primary key (rdt_device_uuid, rdt_token_uuid, rdt_token_instance)
    );
    
    create table am_relation_device_user (
        rdu_device_uuid varchar(64) not null,
        rdu_user_uuid varchar(64) not null,
        rdu_created_time bigint,
        primary key (rdu_device_uuid, rdu_user_uuid)
    );
    
    create unique index idx_de_type_id on am_user_device(de_type,de_id);
    
    create index idx_rdu_user_uuid on am_relation_device_user(rdu_user_uuid);
    
    create index idx_rdt_token_uuid_instance on am_relation_device_token(rdt_token_uuid, rdt_token_instance);
    
-- Secondary Account migration script (from am_object table to am_idmapping table)
    insert into am_idmapping (im_user_uuid, im_ext_app_uuid, im_ext_id, im_ext_id_upper, im_unique_id_app, im_ext_id_type, im_profile_name, im_created_time)
    select ob_parent_uuid, ob_id, ob_discriminator1, upper(ob_discriminator1), ob_uuid, 'SecondaryAccount', 'profile1', ob_created_time from am_object where ob_object_class='SecondaryAccount';

-- This deletion query does not have to be done immediately, it can be done much later--
-- delete from am_object where ob_uuid in (select im_unique_id_app from am_idmapping) and ob_object_class='SecondaryAccount';

    create table am_usersession (
        usn_uuid varchar(64) not null,
        usn_version bigint not null,
        usn_count integer,
        usn_earliest_expy bigint,
        usn_latest_expy bigint,
        usn_last_update bigint,
        usn_sec_hash varchar(128),
        usn_sessions varchar(3072),
        primary key (usn_uuid)
    );
    
    update am_vars set va_value='1092', va_version = va_version + 1 where va_name='SchemaVersion';
    
-- END OF AccessMatrix Server Schema Update 5.6.2 (1087) to 5.6.3 (1092)
-- EndOfSchemaVersion1092

-- SchemaVersion1097
-- START OF AccessMatrix Server Schema Update 5.6.3 (1092) to 5.6.4 (1097)

    create table am_audit_a (
        au_server_id integer not null,
        au_id bigint not null,
        au_reported_time timestamp not null,
        au_module_name varchar(12),
        au_category varchar(32) not null,
        au_type varchar(32) not null,
        au_result varchar(20),
        au_result_code varchar(16),
        au_ext_result_code varchar(16),
        au_message varchar(256),
        au_tx_id varchar(32),
        au_signature varchar(96),
        au_actor_class varchar(32),
        au_actor_uuid varchar(64),
        au_actor_id varchar(64),
        au_actor_user_store varchar(64),
        au_actor_ses_id varchar(64),
        au_actor_seg_uuid varchar(64),
        au_actor_ip_addr varchar(45),
        au_real_actor_id varchar(64),
        au_real_actor_user_store varchar(64),
        au_real_actor_ses_id varchar(64),
        au_real_actor_seg_uuid varchar(64),
        au_client_id varchar(45),
        au_client_type integer,
        au_target_class varchar(32),
        au_target_uuid varchar(64),
        au_target_id varchar(64),
        au_target_user_store varchar(64),
        au_target_seg_uuid varchar(64),
        au_custom_desc varchar(256),
        au_attr1_char16 varchar(16),
        au_attr2_char16 varchar(32),
        au_attr3_char32 varchar(32),
        au_attr4_char32 varchar(32),
        au_attr5_char64 varchar(64),
        au_attr6_char64 varchar(64),
        au_attr7_char64 varchar(64),
        au_attr8_char128 varchar(128),
        au_flag1 smallint,
        au_flag2 smallint,
        au_flag3 smallint,
        au_flag4 smallint,
        au_attr1_num bigint,
        au_attr2_num bigint,
        au_attr3_num bigint,
        au_attr4_num bigint,
        au_time1 timestamp,
        au_time2 timestamp,
        au_time3 timestamp,
        au_time4 timestamp,
        primary key (au_server_id, au_id)
    );

    create table am_audit_attr_a (
        aa_server_id integer not null,
        aa_id bigint not null,
        aa_name varchar(64) not null,
        aa_part integer not null,
        aa_name_upper varchar(64) not null,
        aa_datatype varchar(16) not null,
        aa_value varchar(3072),
        primary key (aa_server_id, aa_id, aa_name, aa_part)
    );
    
    create table am_audit_b (
        au_server_id integer not null,
        au_id bigint not null,
        au_reported_time timestamp not null,
        au_module_name varchar(12),
        au_category varchar(32) not null,
        au_type varchar(32) not null,
        au_result varchar(20),
        au_result_code varchar(16),
        au_ext_result_code varchar(16),
        au_message varchar(256),
        au_tx_id varchar(32),
        au_signature varchar(96),
        au_actor_class varchar(32),
        au_actor_uuid varchar(64),
        au_actor_id varchar(64),
        au_actor_user_store varchar(64),
        au_actor_ses_id varchar(64),
        au_actor_seg_uuid varchar(64),
        au_actor_ip_addr varchar(45),
        au_real_actor_id varchar(64),
        au_real_actor_user_store varchar(64),
        au_real_actor_ses_id varchar(64),
        au_real_actor_seg_uuid varchar(64),
        au_client_id varchar(45),
        au_client_type integer,
        au_target_class varchar(32),
        au_target_uuid varchar(64),
        au_target_id varchar(64),
        au_target_user_store varchar(64),
        au_target_seg_uuid varchar(64),
        au_custom_desc varchar(256),
        au_attr1_char16 varchar(16),
        au_attr2_char16 varchar(32),
        au_attr3_char32 varchar(32),
        au_attr4_char32 varchar(32),
        au_attr5_char64 varchar(64),
        au_attr6_char64 varchar(64),
        au_attr7_char64 varchar(64),
        au_attr8_char128 varchar(128),
        au_flag1 smallint,
        au_flag2 smallint,
        au_flag3 smallint,
        au_flag4 smallint,
        au_attr1_num bigint,
        au_attr2_num bigint,
        au_attr3_num bigint,
        au_attr4_num bigint,
        au_time1 timestamp,
        au_time2 timestamp,
        au_time3 timestamp,
        au_time4 timestamp,
        primary key (au_server_id, au_id)
    );

    create table am_audit_attr_b (
        aa_server_id integer not null,
        aa_id bigint not null,
        aa_name varchar(64) not null,
        aa_part integer not null,
        aa_name_upper varchar(64) not null,
        aa_datatype varchar(16) not null,
        aa_value varchar(3072),
        primary key (aa_server_id, aa_id, aa_name, aa_part)
    );
    
    create table am_audit_c (
        au_server_id integer not null,
        au_id bigint not null,
        au_reported_time timestamp not null,
        au_module_name varchar(12),
        au_category varchar(32) not null,
        au_type varchar(32) not null,
        au_result varchar(20),
        au_result_code varchar(16),
        au_ext_result_code varchar(16),
        au_message varchar(256),
        au_tx_id varchar(32),
        au_signature varchar(96),
        au_actor_class varchar(32),
        au_actor_uuid varchar(64),
        au_actor_id varchar(64),
        au_actor_user_store varchar(64),
        au_actor_ses_id varchar(64),
        au_actor_seg_uuid varchar(64),
        au_actor_ip_addr varchar(45),
        au_real_actor_id varchar(64),
        au_real_actor_user_store varchar(64),
        au_real_actor_ses_id varchar(64),
        au_real_actor_seg_uuid varchar(64),
        au_client_id varchar(45),
        au_client_type integer,
        au_target_class varchar(32),
        au_target_uuid varchar(64),
        au_target_id varchar(64),
        au_target_user_store varchar(64),
        au_target_seg_uuid varchar(64),
        au_custom_desc varchar(256),
        au_attr1_char16 varchar(16),
        au_attr2_char16 varchar(32),
        au_attr3_char32 varchar(32),
        au_attr4_char32 varchar(32),
        au_attr5_char64 varchar(64),
        au_attr6_char64 varchar(64),
        au_attr7_char64 varchar(64),
        au_attr8_char128 varchar(128),
        au_flag1 smallint,
        au_flag2 smallint,
        au_flag3 smallint,
        au_flag4 smallint,
        au_attr1_num bigint,
        au_attr2_num bigint,
        au_attr3_num bigint,
        au_attr4_num bigint,
        au_time1 timestamp,
        au_time2 timestamp,
        au_time3 timestamp,
        au_time4 timestamp,
        primary key (au_server_id, au_id)
    );

    create table am_audit_attr_c (
        aa_server_id integer not null,
        aa_id bigint not null,
        aa_name varchar(64) not null,
        aa_part integer not null,
        aa_name_upper varchar(64) not null,
        aa_datatype varchar(16) not null,
        aa_value varchar(3072),
        primary key (aa_server_id, aa_id, aa_name, aa_part)
    );
    
    create index idx_au_actor_id_a on am_audit_a (au_actor_id);
    create index idx_au_reported_time_a on am_audit_a (au_reported_time);
    create index idx_au_actor_uuid_a on am_audit_a (au_actor_uuid);
    create index idx_au_taget_id_a on am_audit_a (au_target_id);
    create index idx_au_target_uuid_a on am_audit_a (au_target_uuid);
    create index idx_au_result_code_a on am_audit_a (au_result_code);
    create index idx_au_actor_id_b on am_audit_b (au_actor_id);
    create index idx_au_reported_time_b on am_audit_b (au_reported_time);
    create index idx_au_actor_uuid_b on am_audit_b (au_actor_uuid);
    create index idx_au_taget_id_b on am_audit_b (au_target_id);
    create index idx_au_target_uuid_b on am_audit_b (au_target_uuid);
    create index idx_au_result_code_b on am_audit_b (au_result_code);
    create index idx_au_actor_id_c on am_audit_c (au_actor_id);
    create index idx_au_actor_uuid_c on am_audit_c (au_actor_uuid);
    create index idx_au_reported_time_c on am_audit_c (au_reported_time);
    create index idx_au_taget_id_c on am_audit_c (au_target_id);
    create index idx_au_target_uuid_c on am_audit_c (au_target_uuid);
    create index idx_au_result_code_c on am_audit_c (au_result_code);
    create index idx_au_cat_type_time_a on am_audit_a(au_category,au_type,au_reported_time);
    create index idx_au_cat_type_time_b on am_audit_b(au_category,au_type,au_reported_time);
    create index idx_au_cat_type_time_c on am_audit_c(au_category,au_type,au_reported_time);
    create index idx_aa_name_id_sid_a on am_audit_attr_a(aa_name,aa_id,aa_server_id);
    create index idx_aa_nameu_id_sid_a on am_audit_attr_a(aa_name_upper,aa_id,aa_server_id);
    create index idx_aa_name_id_sid_b on am_audit_attr_b(aa_name,aa_id,aa_server_id);
    create index idx_aa_nameu_id_sid_b on am_audit_attr_b(aa_name_upper,aa_id,aa_server_id);
    create index idx_aa_name_id_sid_c on am_audit_attr_c(aa_name,aa_id,aa_server_id);
    create index idx_aa_nameu_id_sid_c on am_audit_attr_c(aa_name_upper,aa_id,aa_server_id);
	
    create index idx_usn_latest_expy on am_usersession(usn_latest_expy);
    
	create view am_vw_audit_b_a as select * from am_audit_b union all select * from am_audit_a;
	create view am_vw_audit_c_b as select * from am_audit_c union all select * from am_audit_b;
	create view am_vw_audit_a_c as select * from am_audit_a union all select * from am_audit_c;
	
	create view am_vw_audit_attribute_b_a as select * from am_audit_attr_b union all select * from am_audit_attr_a;
	create view am_vw_audit_attribute_c_b as select * from am_audit_attr_c union all select * from am_audit_attr_b;
	create view am_vw_audit_attribute_a_c as select * from am_audit_attr_a union all select * from am_audit_attr_c;
	
	-- Uncomment and run to move audits to new table
	-- insert into am_audit_c ( au_server_id, au_id, au_reported_time, au_module_name, au_category,
        -- au_type, au_result, au_result_code, au_ext_result_code, au_message,
        -- au_tx_id, au_signature, au_actor_class, au_actor_uuid, au_actor_id,
        -- au_actor_user_store, au_actor_ses_id, au_actor_seg_uuid, au_actor_ip_addr, au_real_actor_id,
        -- au_real_actor_user_store, au_real_actor_ses_id, au_real_actor_seg_uuid, au_client_id, au_client_type,
		-- au_target_class, au_target_uuid, au_target_id, au_target_user_store, au_target_seg_uuid,
        -- au_custom_desc, au_attr1_char16, au_attr2_char16, au_attr3_char32, au_attr4_char32,
        -- au_attr5_char64, au_attr6_char64, au_attr7_char64, au_attr8_char128, au_flag1,
        -- au_flag2, au_flag3, au_flag4, au_attr1_num, au_attr2_num,
        -- au_attr3_num, au_attr4_num, au_time1, au_time2, au_time3, au_time4)
    -- select 
        -- au_server_id, au_id, au_reported_time, au_module_name, au_category,
        -- au_type, au_result, au_result_code, au_ext_result_code, au_message,
        -- au_tx_id, au_signature, au_actor_class, au_actor_uuid, au_actor_id,
        -- au_actor_user_store, au_actor_ses_id, au_actor_seg_uuid, au_actor_ip_addr, au_real_actor_id,
        -- au_real_actor_user_store, au_real_actor_ses_id, au_real_actor_seg_uuid, au_client_id, au_client_type,
		-- au_target_class, au_target_uuid, au_target_id, au_target_user_store, au_target_seg_uuid,
        -- au_custom_desc, au_attr1_char16, au_attr2_char16, au_attr3_char32, au_attr4_char32,
        -- au_attr5_char64, au_attr6_char64, au_attr7_char64, au_attr8_char128, au_flag1,
        -- au_flag2, au_flag3, au_flag4, au_attr1_num, au_attr2_num,
        -- au_attr3_num, au_attr4_num, au_time1, au_time2, au_time3, au_time4
	-- from am_audit;
	-- insert into am_audit_attr_c (aa_server_id, aa_id, aa_name, aa_part, aa_name_upper, aa_datatype, aa_value)
	-- select aa_server_id, aa_id, aa_name, aa_part, aa_name_upper, aa_datatype, aa_value
	-- from am_audit_attr;

    alter table am_user_device add de_rooted smallint;

    update am_vars set va_value='1097', va_version = va_version + 1 where va_name='SchemaVersion';
    
-- END OF AccessMatrix Server Schema Update 5.6.3 (1092) to 5.6.4 (1097)
-- EndOfSchemaVersion1097

-- SchemaVersion1102
-- START OF AccessMatrix Server Schema Update 5.6.4 (1097) to 5.6.6 (1102)

	alter table am_user_device add de_custom_attr1 varchar(64); 
	alter table am_user_device add de_custom_attr2 varchar(64); 
	alter table am_user_device add de_custom_attr3 varchar(64); 
	alter table am_user_device add de_custom_attr4 varchar(512); 
	alter table am_user_device add de_custom_attr5 varchar(512); 
	
	update am_vars set va_value='1102', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.6.4 (1097) to 5.6.6 (1102)
-- EndOfSchemaVersion1102

-- SchemaVersion1107
-- START OF AccessMatrix Server Schema Update 5.6.6 (1102) to 5.6.7 (1107)

	alter table am_oauthtoken add ot_grant_iid varchar(22);
	
	create index idx_ot_grant_iid on am_oauthtoken(ot_grant_iid);
	
	alter table am_user_device add de_tag varchar(256);
	
	update am_vars set va_value='1107', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.6.6 (1102) to 5.6.7 (1107)
-- EndOfSchemaVersion1107

-- SchemaVersion1112
-- START OF AccessMatrix Server Schema Update 5.6.7 (1107) to 5.6.8 (1112)

	update am_vars set va_value='1112', va_version = va_version +1 where va_name='SchemaVersion';
	
-- END OF AccessMatrix Server Schema Update 5.6.7 (1107) to 5.6.8 (1112)
-- EndOfSchemaVersion1112

-- SchemaVersion1117
-- START OF AccessMatrix Server Schema Update 5.6.8 (1112) to 5.7.3 (1117)

    create table am_rp_token (
    	rpt_token_uuid varchar(64) not null,
    	rpt_token_hash varchar(64) not null unique,
        rpt_token varchar(3072) not null,
        rpt_user_uuid varchar(64) not null,
        rpt_lookup_module_uuid varchar(64) not null,
        rpt_type varchar(8) not null,
        rpt_at_expiry_time bigint,
        rpt_token_expiry_time bigint not null,
        rpt_session_iid varchar(22),
        primary key (rpt_token_uuid)
    );

	create index idx_token_expiryTime on am_rp_token (rpt_token_expiry_time);
	
    create index idx_rpt_lookupmoduleuuid_useruuid_type_exp on am_rp_token(rpt_user_uuid,rpt_lookup_module_uuid,rpt_type);

    create index idx_rpt_sessioniid_type_exp on am_rp_token(rpt_session_iid,rpt_type);
    
    update am_vars set va_value='1117', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.6.8 (1112) to 5.7.3 (1117)
-- EndOfSchemaVersion1117

-- SchemaVersion1122
-- START OF AccessMatrix Server Schema Update 5.7.3 (1117) to 5.7.4 (1122)
    create index idx_im_app_profile on am_idmapping(im_ext_app_uuid,im_profile_name);
    
    update am_vars set va_value='1122', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.7.3 (1117) to 5.7.4 (1122)
-- EndOfSchemaVersion1122

-- SchemaVersion1127
-- START OF AccessMatrix Server Schema Update 5.7.4 (1122) to 5.7.5 (1127) 
    create index idx_ot_client_uuid on am_oauthtoken(ot_client_uuid);
   
    update am_attribute set at_long_value = at_long_value/60 where at_name ='RefreshTokenValidityPeriod'; 

	update am_attribute set at_long_value = at_long_value/60, at_name='RT_ExpiryInMins', at_name_upper='RT_EXPIRYINMINS', at_datatype='LONG' where at_name ='RT_ExpiryInSecs' ;
	
	
	update am_vars set va_value='1127', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.7.4 (1122) to 5.7.5 (1127)
-- EndOfSchemaVersion1127

-- SchemaVersion1132
-- START OF AccessMatrix Server Schema Update 5.7.5 (1127) to 5.7.6 (1132)
	
	update am_attribute set at_datatype = 'MULTISTRING' where at_name ='responseAuthnContextMappings' and at_datatype = 'STRING';
	
	update am_vars set va_value='1132', va_version = va_version +1 where va_name='SchemaVersion';
	
	-- These tables are used by the Privileged Session Management feature
	-- which has been deprecated and is no longer in use.
	-- Uncomment the following DROP statements to remove them from AMDB
	--drop table LOG_COMMAND;
	--drop table LOG_LOGIN;
	--drop table LOG_SESSION;

-- END OF AccessMatrix Server Schema Update 5.7.5 (1127) to 5.7.6 (1132)	
-- EndOfSchemaVersion1132

-- SchemaVersion1137
-- START OF AccessMatrix Server Schema Update 5.7.6 (1132) to 6.0.0 (1137)

   alter table am_tokenauthstate
     add tst_last_succ_date timestamp,
     add tst_last_fail_date timestamp;

   update am_vars set va_value='1137', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.7.6 (1132) to 6.0.0 (1137)
-- EndOfSchemaVersion1137
