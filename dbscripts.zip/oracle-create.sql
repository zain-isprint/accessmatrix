
    create table OS_CURRENTSTEP (
        id number(19,0) not null,
        action_Id number(10,0),
        caller varchar2(64 char),
        finish_Date timestamp,
        start_Date timestamp,
        due_Date timestamp,
        owner varchar2(64 char),
        status varchar2(1024 char),
        step_Id number(10,0),
        entry_Id number(19,0),
        primary key (id)
    );

    create table OS_HISTORYSTEP (
        id number(19,0) not null,
        action_Id number(10,0),
        caller varchar2(1024 char),
        finish_Date timestamp,
        start_Date timestamp,
        due_Date timestamp,
        owner varchar2(64 char),
        status varchar2(1024 char),
        step_Id number(10,0),
        entry_Id number(19,0),
        primary key (id)
    );

    create table OS_WFENTRY (
        id number(19,0) not null,
        version number(10,0) not null,
        name varchar2(128 char),
        state number(10,0),
        primary key (id)
    );

    create table am_ancestry (
        an_descendant varchar2(64 char) not null,
        an_ancestor varchar2(64 char) not null,
        an_type char(1 char) not null,
        an_des_class varchar2(32 char) not null,
        an_anc_class varchar2(32 char) not null,
        an_gap number(10,0) not null,
        primary key (an_descendant, an_ancestor, an_type)
    );

    create table am_attribute (
        at_uuid varchar2(64 char) not null,
        at_name_upper varchar2(64 char) not null,
        at_version number(19,0) not null,
        at_name varchar2(64 char),
        at_class varchar2(32 char),
        at_datatype varchar2(16 char),
        at_date_value timestamp,
        at_long_value number(19,0),
        at_string_value varchar2(3072 char),
        at_baseobject_value varchar2(96 char),
        at_enctype char(1 char),
        at_search_value varchar2(96 char),
        primary key (at_uuid, at_name_upper)
    );

    create table am_audit (
        au_server_id number(10,0) not null,
        au_id number(19,0) not null,
        au_reported_time timestamp not null,
        au_module_name varchar2(12 char),
        au_category varchar2(32 char) not null,
        au_type varchar2(32 char) not null,
        au_result varchar2(20 char),
        au_result_code varchar2(16 char),
        au_ext_result_code varchar2(16 char),
        au_message varchar2(256 char),
        au_tx_id varchar2(32 char),
        au_signature varchar2(96 char),
        au_actor_class varchar2(32 char),
        au_actor_uuid varchar2(64 char),
        au_actor_id varchar2(64 char),
        au_actor_user_store varchar2(64 char),
        au_actor_ses_id varchar2(64 char),
        au_actor_seg_uuid varchar2(64 char),
        au_actor_ip_addr varchar2(45 char),
        au_real_actor_id varchar2(64 char),
        au_real_actor_user_store varchar2(64 char),
        au_real_actor_ses_id varchar2(64 char),
        au_real_actor_seg_uuid varchar2(64 char),
        au_client_id varchar2(45 char),
        au_client_type number(10,0),
        au_target_class varchar2(32 char),
        au_target_uuid varchar2(64 char),
        au_target_id varchar2(64 char),
        au_target_user_store varchar2(64 char),
        au_target_seg_uuid varchar2(64 char),
        au_custom_desc varchar2(256 char),
        au_attr1_char16 varchar2(16 char),
        au_attr2_char16 varchar2(32 char),
        au_attr3_char32 varchar2(32 char),
        au_attr4_char32 varchar2(32 char),
        au_attr5_char64 varchar2(64 char),
        au_attr6_char64 varchar2(64 char),
        au_attr7_char64 varchar2(64 char),
        au_attr8_char128 varchar2(128 char),
        au_flag1 number(1,0),
        au_flag2 number(1,0),
        au_flag3 number(1,0),
        au_flag4 number(1,0),
        au_attr1_num number(19,0),
        au_attr2_num number(19,0),
        au_attr3_num number(19,0),
        au_attr4_num number(19,0),
        au_time1 timestamp,
        au_time2 timestamp,
        au_time3 timestamp,
        au_time4 timestamp,
        primary key (au_server_id, au_id)
    );

    create table am_audit_a (
        au_server_id number(10,0) not null,
        au_id number(19,0) not null,
        au_reported_time timestamp not null,
        au_module_name varchar2(12 char),
        au_category varchar2(32 char) not null,
        au_type varchar2(32 char) not null,
        au_result varchar2(20 char),
        au_result_code varchar2(16 char),
        au_ext_result_code varchar2(16 char),
        au_message varchar2(256 char),
        au_tx_id varchar2(32 char),
        au_signature varchar2(96 char),
        au_actor_class varchar2(32 char),
        au_actor_uuid varchar2(64 char),
        au_actor_id varchar2(64 char),
        au_actor_user_store varchar2(64 char),
        au_actor_ses_id varchar2(64 char),
        au_actor_seg_uuid varchar2(64 char),
        au_actor_ip_addr varchar2(45 char),
        au_real_actor_id varchar2(64 char),
        au_real_actor_user_store varchar2(64 char),
        au_real_actor_ses_id varchar2(64 char),
        au_real_actor_seg_uuid varchar2(64 char),
        au_client_id varchar2(45 char),
        au_client_type number(10,0),
        au_target_class varchar2(32 char),
        au_target_uuid varchar2(64 char),
        au_target_id varchar2(64 char),
        au_target_user_store varchar2(64 char),
        au_target_seg_uuid varchar2(64 char),
        au_custom_desc varchar2(256 char),
        au_attr1_char16 varchar2(16 char),
        au_attr2_char16 varchar2(32 char),
        au_attr3_char32 varchar2(32 char),
        au_attr4_char32 varchar2(32 char),
        au_attr5_char64 varchar2(64 char),
        au_attr6_char64 varchar2(64 char),
        au_attr7_char64 varchar2(64 char),
        au_attr8_char128 varchar2(128 char),
        au_flag1 number(1,0),
        au_flag2 number(1,0),
        au_flag3 number(1,0),
        au_flag4 number(1,0),
        au_attr1_num number(19,0),
        au_attr2_num number(19,0),
        au_attr3_num number(19,0),
        au_attr4_num number(19,0),
        au_time1 timestamp,
        au_time2 timestamp,
        au_time3 timestamp,
        au_time4 timestamp,
        primary key (au_server_id, au_id)
    );

    create table am_audit_attr (
        aa_server_id number(10,0) not null,
        aa_id number(19,0) not null,
        aa_name varchar2(64 char) not null,
        aa_part number(10,0) not null,
        aa_name_upper varchar2(64 char) not null,
        aa_datatype varchar2(16 char) not null,
        aa_value varchar2(3072 char),
        primary key (aa_server_id, aa_id, aa_name, aa_part)
    );

    create table am_audit_attr_a (
        aa_server_id number(10,0) not null,
        aa_id number(19,0) not null,
        aa_name varchar2(64 char) not null,
        aa_part number(10,0) not null,
        aa_name_upper varchar2(64 char) not null,
        aa_datatype varchar2(16 char) not null,
        aa_value varchar2(3072 char),
        primary key (aa_server_id, aa_id, aa_name, aa_part)
    );

    create table am_audit_attr_b (
        aa_server_id number(10,0) not null,
        aa_id number(19,0) not null,
        aa_name varchar2(64 char) not null,
        aa_part number(10,0) not null,
        aa_name_upper varchar2(64 char) not null,
        aa_datatype varchar2(16 char) not null,
        aa_value varchar2(3072 char),
        primary key (aa_server_id, aa_id, aa_name, aa_part)
    );

    create table am_audit_attr_c (
        aa_server_id number(10,0) not null,
        aa_id number(19,0) not null,
        aa_name varchar2(64 char) not null,
        aa_part number(10,0) not null,
        aa_name_upper varchar2(64 char) not null,
        aa_datatype varchar2(16 char) not null,
        aa_value varchar2(3072 char),
        primary key (aa_server_id, aa_id, aa_name, aa_part)
    );

    create table am_audit_b (
        au_server_id number(10,0) not null,
        au_id number(19,0) not null,
        au_reported_time timestamp not null,
        au_module_name varchar2(12 char),
        au_category varchar2(32 char) not null,
        au_type varchar2(32 char) not null,
        au_result varchar2(20 char),
        au_result_code varchar2(16 char),
        au_ext_result_code varchar2(16 char),
        au_message varchar2(256 char),
        au_tx_id varchar2(32 char),
        au_signature varchar2(96 char),
        au_actor_class varchar2(32 char),
        au_actor_uuid varchar2(64 char),
        au_actor_id varchar2(64 char),
        au_actor_user_store varchar2(64 char),
        au_actor_ses_id varchar2(64 char),
        au_actor_seg_uuid varchar2(64 char),
        au_actor_ip_addr varchar2(45 char),
        au_real_actor_id varchar2(64 char),
        au_real_actor_user_store varchar2(64 char),
        au_real_actor_ses_id varchar2(64 char),
        au_real_actor_seg_uuid varchar2(64 char),
        au_client_id varchar2(45 char),
        au_client_type number(10,0),
        au_target_class varchar2(32 char),
        au_target_uuid varchar2(64 char),
        au_target_id varchar2(64 char),
        au_target_user_store varchar2(64 char),
        au_target_seg_uuid varchar2(64 char),
        au_custom_desc varchar2(256 char),
        au_attr1_char16 varchar2(16 char),
        au_attr2_char16 varchar2(32 char),
        au_attr3_char32 varchar2(32 char),
        au_attr4_char32 varchar2(32 char),
        au_attr5_char64 varchar2(64 char),
        au_attr6_char64 varchar2(64 char),
        au_attr7_char64 varchar2(64 char),
        au_attr8_char128 varchar2(128 char),
        au_flag1 number(1,0),
        au_flag2 number(1,0),
        au_flag3 number(1,0),
        au_flag4 number(1,0),
        au_attr1_num number(19,0),
        au_attr2_num number(19,0),
        au_attr3_num number(19,0),
        au_attr4_num number(19,0),
        au_time1 timestamp,
        au_time2 timestamp,
        au_time3 timestamp,
        au_time4 timestamp,
        primary key (au_server_id, au_id)
    );

    create table am_audit_c (
        au_server_id number(10,0) not null,
        au_id number(19,0) not null,
        au_reported_time timestamp not null,
        au_module_name varchar2(12 char),
        au_category varchar2(32 char) not null,
        au_type varchar2(32 char) not null,
        au_result varchar2(20 char),
        au_result_code varchar2(16 char),
        au_ext_result_code varchar2(16 char),
        au_message varchar2(256 char),
        au_tx_id varchar2(32 char),
        au_signature varchar2(96 char),
        au_actor_class varchar2(32 char),
        au_actor_uuid varchar2(64 char),
        au_actor_id varchar2(64 char),
        au_actor_user_store varchar2(64 char),
        au_actor_ses_id varchar2(64 char),
        au_actor_seg_uuid varchar2(64 char),
        au_actor_ip_addr varchar2(45 char),
        au_real_actor_id varchar2(64 char),
        au_real_actor_user_store varchar2(64 char),
        au_real_actor_ses_id varchar2(64 char),
        au_real_actor_seg_uuid varchar2(64 char),
        au_client_id varchar2(45 char),
        au_client_type number(10,0),
        au_target_class varchar2(32 char),
        au_target_uuid varchar2(64 char),
        au_target_id varchar2(64 char),
        au_target_user_store varchar2(64 char),
        au_target_seg_uuid varchar2(64 char),
        au_custom_desc varchar2(256 char),
        au_attr1_char16 varchar2(16 char),
        au_attr2_char16 varchar2(32 char),
        au_attr3_char32 varchar2(32 char),
        au_attr4_char32 varchar2(32 char),
        au_attr5_char64 varchar2(64 char),
        au_attr6_char64 varchar2(64 char),
        au_attr7_char64 varchar2(64 char),
        au_attr8_char128 varchar2(128 char),
        au_flag1 number(1,0),
        au_flag2 number(1,0),
        au_flag3 number(1,0),
        au_flag4 number(1,0),
        au_attr1_num number(19,0),
        au_attr2_num number(19,0),
        au_attr3_num number(19,0),
        au_attr4_num number(19,0),
        au_time1 timestamp,
        au_time2 timestamp,
        au_time3 timestamp,
        au_time4 timestamp,
        primary key (au_server_id, au_id)
    );

    create table am_biometric (
        bm_usr_uuid varchar2(64 char) not null,
        bm_vendor number(10,0) not null,
        bm_type number(10,0) not null,
        bm_label varchar2(8 char) not null,
        bm_version number(19,0) not null,
        bm_refer_tplt blob not null,
        bm_status number(10,0),
        bm_partition number(10,0),
        bm_last_verified_time timestamp,
        bm_creation_time timestamp,
        bm_modified_time timestamp,
        bm_sec_hash varchar2(128 char),
        primary key (bm_usr_uuid, bm_vendor, bm_type, bm_label)
    );

    create table am_change_entry (
        ce_ev_server_id_int number(10,0) not null,
        ce_ev_number number(19,0) not null,
        ce_sequence number(19,0) not null,
        ce_action varchar2(32 char) not null,
        ce_name varchar2(64 char),
        ce_value varchar2(3072 char),
        primary key (ce_ev_server_id_int, ce_ev_number, ce_sequence)
    );

    create table am_contextualauthnhistory (
        ctx_uuid varchar2(64 char) not null,
        ctx_date timestamp,
        ctx_user_uuid varchar2(64 char),
        ctx_user_id varchar2(64 char),
        ctx_authn_res varchar2(1024 char),
        ctx_ip varchar2(64 char),
        ctx_country varchar2(64 char),
        ctx_countryisocode varchar2(2 char),
        ctx_subdivision varchar2(64 char),
        ctx_subdivisionisocode varchar2(3 char),
        ctx_city varchar2(64 char),
        ctx_latitude varchar2(64 char),
        ctx_longitude varchar2(64 char),
        ctx_geo_timezone varchar2(64 char),
        ctx_module varchar2(64 char),
        ctx_is_rooted varchar2(8 char),
        ctx_authn_res_sts char(1 char),
        primary key (ctx_uuid)
    );

    create table am_deleted_object (
        do_uuid varchar2(64 char) not null,
        do_object_class varchar2(32 char),
        do_version number(19,0),
        do_id varchar2(64 char),
        do_id_upper varchar2(64 char),
        do_id_int number(10,0),
        do_name varchar2(64 char),
        do_name_upper varchar2(64 char),
        do_dn varchar2(256 char),
        do_dn_upper varchar2(256 char),
        do_description varchar2(256 char),
        do_discriminator1 varchar2(64 char),
        do_discriminator2 varchar2(64 char),
        do_parent_uuid varchar2(64 char),
        do_parent_class varchar2(32 char),
        do_handler_class varchar2(96 char),
        do_status varchar2(16 char),
        do_creator varchar2(64 char),
        do_created_time timestamp,
        do_modifier varchar2(64 char),
        do_modified_time timestamp,
        do_admin_modifier varchar2(64 char),
        do_admin_modified_time timestamp,
        do_reserved1 varchar2(64 char),
        primary key (do_uuid)
    );

    create table am_esso_entitlement (
        si_useruuid varchar2(64 char) not null,
        si_appid varchar2(64 char) not null,
        si_pid number(10,0) not null,
        si_entitlement_prn varchar2(64 char) not null,
        si_userid varchar2(64 char),
        si_app_userid varchar2(64 char),
        si_share_prn varchar2(64 char),
        si_share_res varchar2(64 char),
        si_pwd_modified_time varchar2(64 char),
        si_created_time timestamp,
        primary key (si_useruuid, si_appid, si_pid, si_entitlement_prn)
    );

    create table am_event (
        ev_server_id_int number(10,0) not null,
        ev_id number(19,0) not null,
        ev_time timestamp not null,
        ev_tx_id varchar2(32 char),
        ev_category varchar2(32 char) not null,
        ev_type varchar2(32 char) not null,
        ev_target_class varchar2(32 char),
        ev_target_uuid varchar2(64 char),
        ev_target_version number(19,0),
        primary key (ev_server_id_int, ev_id)
    );

    create table am_idmapping (
        im_user_uuid varchar2(64 char) not null,
        im_ext_app_uuid varchar2(64 char) not null,
        im_ext_id varchar2(64 char) not null,
        im_partition number(10,0),
        im_ext_id_upper varchar2(64 char) not null,
        im_unique_id_app varchar2(8 char) not null,
        im_ext_id_type varchar2(16 char) not null,
        im_other_attr1 varchar2(2048 char),
        im_other_attr2 varchar2(2048 char),
        im_profile_name varchar2(16 char) not null,
        im_created_time timestamp not null,
        primary key (im_user_uuid, im_ext_app_uuid, im_ext_id)
    );

    create table am_impersonation (
        imp_impersonated_uuid varchar2(64 char) not null,
        imp_impersonator_uuid varchar2(64 char) not null,
        imp_impersonator_oc varchar2(32 char) not null,
        imp_sequence number(10,0) not null,
        imp_start_time timestamp,
        imp_end_time timestamp,
        imp_last_modified_time timestamp,
        imp_last_modifier_uuid varchar2(64 char),
        primary key (imp_impersonated_uuid, imp_impersonator_uuid, imp_impersonator_oc, imp_sequence)
    );

    create table am_impersonation_obj (
        impobj_impersonated_uuid varchar2(64 char) not null,
        impobj_impersonator_uuid varchar2(64 char) not null,
        impobj_impersonator_oc varchar2(32 char) not null,
        imp_sequence number(10,0) not null,
        impobj_obj_uuid varchar2(64 char) not null,
        impobj_obj_oc varchar2(32 char) not null,
        impobj_other_attrs varchar2(2048 char),
        primary key (impobj_impersonated_uuid, impobj_impersonator_uuid, impobj_impersonator_oc, imp_sequence, impobj_obj_uuid, impobj_obj_oc)
    );

    create table am_oauthtoken (
        ot_iid varchar2(22 char) not null,
        ot_user_uuid varchar2(64 char),
        ot_type varchar2(3 char),
        ot_client_uuid varchar2(64 char),
        ot_expiry_time number(19,0),
        ot_created_time number(19,0),
        ot_grant_iid varchar2(22 char),
        primary key (ot_iid)
    );

    create table am_object (
        ob_uuid varchar2(64 char) not null,
        ob_object_class varchar2(32 char) not null,
        ob_version number(19,0) not null,
        ob_id varchar2(64 char) not null,
        ob_id_upper varchar2(64 char) not null,
        ob_id_int number(10,0),
        ob_name varchar2(64 char),
        ob_name_upper varchar2(64 char),
        ob_dn varchar2(250 char),
        ob_dn_upper varchar2(250 char),
        ob_description varchar2(256 char),
        ob_discriminator1 varchar2(64 char),
        ob_discriminator2 varchar2(64 char),
        ob_parent_uuid varchar2(64 char),
        ob_parent_class varchar2(32 char),
        ob_handler_class varchar2(96 char),
        ob_status varchar2(16 char),
        ob_creator varchar2(64 char),
        ob_created_time timestamp,
        ob_modifier varchar2(64 char),
        ob_modified_time timestamp,
        ob_admin_modifier varchar2(64 char),
        ob_admin_modified_time timestamp,
        ob_lock_flag number(1,0),
        ob_lock_by varchar2(64 char),
        ob_reserved1 varchar2(64 char),
        primary key (ob_uuid)
    );

    create table am_pinmailer (
        pm_uuid varchar2(64 char) not null,
        pm_version number(19,0) not null,
        pm_id varchar2(64 char) not null unique,
        pm_entry_uid varchar2(32 char),
        pm_template_id varchar2(64 char),
        pm_module_id varchar2(64 char),
        pm_content_type varchar2(32 char),
        pm_content_action varchar2(32 char),
        pm_status varchar2(32 char),
        pm_content_uuid varchar2(64 char),
        pm_content_summary varchar2(256 char),
        pm_template_uuid varchar2(64 char),
        pm_channel_uuid varchar2(64 char),
        pm_delivery_summary varchar2(256 char),
        pm_maker varchar2(64 char),
        pm_made_time timestamp,
        pm_checker varchar2(64 char),
        pm_checked_time timestamp,
        pm_creator varchar2(64 char),
        pm_created_time timestamp,
        pm_modifier varchar2(64 char),
        pm_modified_time timestamp,
        pm_ended number(1,0),
        pm_attr1_char16 varchar2(16 char),
        pm_attr2_char16 varchar2(16 char),
        pm_attr3_char32 varchar2(32 char),
        pm_attr4_char32 varchar2(32 char),
        pm_attr5_char64 varchar2(64 char),
        pm_attr6_char64 varchar2(64 char),
        pm_attr7_char128 varchar2(128 char),
        pm_attr8_char256 varchar2(256 char),
        pm_flag1 number(1,0),
        pm_flag2 number(1,0),
        pm_number1 number(19,0),
        pm_number2 number(19,0),
        pm_time1 timestamp,
        pm_time2 timestamp,
        primary key (pm_uuid)
    );

    create table am_pinmailer_attr (
        pa_uuid varchar2(64 char) not null,
        pa_name varchar2(64 char) not null,
        pa_part number(10,0) not null,
        pa_name_upper varchar2(64 char) not null,
        pa_datatype varchar2(16 char) not null,
        pa_enctype char(1 char) not null,
        pa_value varchar2(3072 char),
        primary key (pa_uuid, pa_name, pa_part)
    );

    create table am_relation (
        re_uuid varchar2(64 char) not null,
        re_object_class varchar2(32 char) not null,
        re_version number(19,0) not null,
        re_name varchar2(32 char) not null,
        re_id varchar2(64 char),
        re_obj1_uuid varchar2(64 char) not null,
        re_obj2_uuid varchar2(64 char) not null,
        re_obj3_uuid varchar2(64 char),
        re_obj1_class varchar2(32 char),
        re_obj2_class varchar2(32 char),
        re_obj3_class varchar2(32 char),
        re_parameters varchar2(1024 char),
        re_description varchar2(256 char),
        re_parent_uuid varchar2(64 char),
        re_parent_class varchar2(32 char),
        re_creator varchar2(64 char),
        re_created_time timestamp,
        re_modifier varchar2(64 char),
        re_modified_time timestamp,
        re_admin_modifier varchar2(64 char),
        re_admin_modified_time timestamp,
        re_lock_flag number(1,0),
        re_lock_by varchar2(64 char),
        primary key (re_uuid)
    );

    create table am_relation2 (
        r2_obj1_uuid varchar2(64 char) not null,
        r2_name varchar2(32 char) not null,
        r2_obj2_uuid varchar2(64 char) not null,
        r2_obj1_class varchar2(32 char),
        r2_obj2_class varchar2(32 char),
        r2_created_time timestamp,
        primary key (r2_obj1_uuid, r2_name, r2_obj2_uuid)
    );

    create table am_relation_device_token (
        rdt_device_uuid varchar2(64 char) not null,
        rdt_token_uuid varchar2(64 char) not null,
        rdt_token_instance varchar2(64 char) not null,
        rdt_created_time number(19,0),
        primary key (rdt_device_uuid, rdt_token_uuid, rdt_token_instance)
    );

    create table am_relation_device_user (
        rdu_device_uuid varchar2(64 char) not null,
        rdu_user_uuid varchar2(64 char) not null,
        rdu_created_time number(19,0),
        primary key (rdu_device_uuid, rdu_user_uuid)
    );

    create table am_tokenauthstate (
        tst_token_uuid varchar2(64 char) not null,
        tst_func_id varchar2(32 char) not null,
        tst_auth_mode varchar2(8 char) not null,
        tst_version number(19,0) not null,
        tst_partition number(10,0),
        tst_status varchar2(20 char),
        tst_success_cnt number(10,0),
        tst_fail_cnt number(10,0),
        tst_last_stat_chg_date timestamp,
        tst_last_succ_date timestamp,
        tst_last_fail_date timestamp,
        tst_sec_hash varchar2(128 char),
        tst_sec_data varchar2(2048 char),
        tst_other_attrs varchar2(1024 char),
        tst_last_modified_date timestamp,
        primary key (tst_token_uuid, tst_func_id, tst_auth_mode)
    );

    create table am_user_device (
        de_uuid varchar2(16 char) not null,
        de_status varchar2(16 char),
        de_type varchar2(16 char),
        de_id varchar2(64 char),
        de_agent varchar2(64 char),
        de_desc varchar2(64 char),
        de_tag varchar2(256 char),
        de_custom_attr1 varchar2(64 char),
        de_custom_attr2 varchar2(64 char),
        de_custom_attr3 varchar2(64 char),
        de_custom_attr4 varchar2(512 char),
        de_custom_attr5 varchar2(512 char),
        de_rooted number(1,0),
        de_created_time number(19,0),
        de_admin_modifier varchar2(64 char),
        de_admin_modified_time number(19,0),
        de_last_status_change number(19,0),
        de_last_used_time number(19,0),
        primary key (de_uuid)
    );

    create table am_user_key (
        ky_uuid varchar2(16 char) not null,
        ky_user_uuid varchar2(64 char),
        ky_key_id varchar2(64 char),
        ky_status varchar2(16 char),
        ky_cryptoapp_uuid varchar2(64 char),
        ky_key_provider_uuid varchar2(64 char),
        ky_key_algo varchar2(64 char),
        ky_private_key varchar2(1800 char),
        ky_public_key varchar2(1024 char),
        ky_key_usage varchar2(64 char),
        ky_created_time number(19,0),
        ky_modified_time number(19,0),
        ky_last_status_change_time number(19,0),
        primary key (ky_uuid)
    );

    create table am_userauthstate (
        ust_user_uuid varchar2(64 char) not null,
        ust_type varchar2(3 char) not null,
        ust_auth_uuid varchar2(64 char) not null,
        ust_version number(19,0) not null,
        ust_partition number(10,0),
        ust_status varchar2(20 char),
        ust_control_flag varchar2(3 char),
        ust_start_date timestamp,
        ust_end_date timestamp,
        ust_success_cnt number(10,0),
        ust_fail_cnt number(10,0),
        ust_last_login_date timestamp,
        ust_last_logout_date timestamp,
        ust_last_pwd_chg_date timestamp,
        ust_last_stat_chg_date timestamp,
        ust_sec_hash varchar2(128 char),
        ust_other_attrs varchar2(2048 char),
        ust_last_modified_date timestamp,
        primary key (ust_user_uuid, ust_type, ust_auth_uuid)
    );

    create table am_usersession (
        usn_uuid varchar2(64 char) not null,
        usn_version number(19,0) not null,
        usn_count number(10,0),
        usn_earliest_expy number(19,0),
        usn_latest_expy number(19,0),
        usn_last_update number(19,0),
        usn_sec_hash varchar2(128 char),
        usn_sessions varchar2(3072 char),
        primary key (usn_uuid)
    );

    create table am_vars (
        va_name varchar2(64 char) not null,
        va_version number(19,0) not null,
        va_value varchar2(256 char),
        primary key (va_name)
    );

    create table am_workflow (
        wo_uuid varchar2(64 char) not null,
        wo_version number(19,0) not null,
        wo_id varchar2(64 char) not null unique,
        wo_entry_uid varchar2(64 char),
        wo_template_id varchar2(128 char),
        wo_name varchar2(64 char),
        wo_name_upper varchar2(64 char),
        wo_saveable_type varchar2(32 char),
        wo_saveable_action varchar2(32 char),
        wo_status varchar2(32 char),
        wo_content varchar2(256 char),
        wo_target varchar2(64 char),
        wo_target_class varchar2(32 char),
        wo_maker varchar2(64 char),
        wo_made_time timestamp,
        wo_checker varchar2(64 char),
        wo_checked_time timestamp,
        wo_creator varchar2(64 char),
        wo_created_time timestamp,
        wo_modifier varchar2(64 char),
        wo_modified_time timestamp,
        wo_attr1_char16 varchar2(16 char),
        wo_attr2_char16 varchar2(16 char),
        wo_attr3_char32 varchar2(32 char),
        wo_attr4_char32 varchar2(32 char),
        wo_attr5_char64 varchar2(64 char),
        wo_attr6_char64 varchar2(64 char),
        wo_attr7_char128 varchar2(128 char),
        wo_attr8_char256 varchar2(256 char),
        wo_flag1 number(1,0),
        wo_flag2 number(1,0),
        wo_number1 number(19,0),
        wo_number2 number(19,0),
        wo_time1 timestamp,
        wo_time2 timestamp,
        primary key (wo_uuid)
    );
    
    create table am_rp_token (
        rpt_token_uuid varchar2(64 char) not null,
    	rpt_token_hash varchar2(64 char) not null unique,
        rpt_token varchar2(3072 char) not null,
        rpt_user_uuid varchar2(64 char) not null,
        rpt_lookup_module_uuid varchar2(64 char) not null,
        rpt_type varchar2(8 char) not null,
        rpt_at_expiry_time number(19,0),
        rpt_token_expiry_time number(19,0) not null,
        rpt_session_iid varchar2(22 char),
        primary key (rpt_token_uuid)
    );

    alter table OS_CURRENTSTEP 
        add constraint FK8710A5CADD562C9A 
        foreign key (entry_Id) 
        references OS_WFENTRY;

    alter table OS_HISTORYSTEP 
        add constraint FK7835C765DD562C9A 
        foreign key (entry_Id) 
        references OS_WFENTRY;

    create index idx_at_name_bovalue on am_attribute (at_name, at_baseobject_value);

    create index idx_at_name_lvalue on am_attribute (at_name, at_long_value);

    create index idx_at_bovalue on am_attribute (at_baseobject_value);

    create index idx_au_taget_id on am_audit (au_target_id);

    create index idx_au_actor_id on am_audit (au_actor_id);

    create index idx_au_target_uuid on am_audit (au_target_uuid);

    create index idx_au_actor_uuid on am_audit (au_actor_uuid);

    create index idx_au_result_code on am_audit (au_result_code);

    create index idx_au_reported_time on am_audit (au_reported_time);

    create index idx_au_actor_id_a on am_audit_a (au_actor_id);

    create index idx_au_reported_time_a on am_audit_a (au_reported_time);

    create index idx_au_actor_uuid_a on am_audit_a (au_actor_uuid);

    create index idx_au_taget_id_a on am_audit_a (au_target_id);

    create index idx_au_target_uuid_a on am_audit_a (au_target_uuid);

    create index idx_au_result_code_a on am_audit_a (au_result_code);

    create index idx_au_actor_id_b on am_audit_b (au_actor_id);

    create index idx_au_reported_time_b on am_audit_b (au_reported_time);

    create index idx_au_actor_uuid_b on am_audit_b (au_actor_uuid);

    create index idx_au_taget_id_b on am_audit_b (au_target_id);

    create index idx_au_target_uuid_b on am_audit_b (au_target_uuid);

    create index idx_au_result_code_b on am_audit_b (au_result_code);

    create index idx_au_actor_id_c on am_audit_c (au_actor_id);

    create index idx_au_actor_uuid_c on am_audit_c (au_actor_uuid);

    create index idx_au_reported_time_c on am_audit_c (au_reported_time);

    create index idx_au_taget_id_c on am_audit_c (au_target_id);

    create index idx_au_target_uuid_c on am_audit_c (au_target_uuid);

    create index idx_au_result_code_c on am_audit_c (au_result_code);

    create index idx_ot_expiryTime on am_oauthtoken (ot_expiry_time);
	
    create index idx_ot_grant_iid on am_oauthtoken(ot_grant_iid);
	
    create index idx_ot_client_uuid on am_oauthtoken(ot_client_uuid);

    create index idx_ob_idu on am_object (ob_id_upper);

    create index idx_ob_disc1 on am_object (ob_discriminator1);

    create index idx_ob_disc2 on am_object (ob_discriminator2);

    create index idx_ob_idi on am_object (ob_id_int);

    create index idx_ob_id on am_object (ob_id);

    create index idx_ob_dn on am_object (ob_dn);

    create index idx_ob_dnu on am_object (ob_dn_upper);

    create index idx_pm_maker on am_pinmailer (pm_maker);

    create index idx_pm_status on am_pinmailer (pm_status);

    create index idx_pm_content on am_pinmailer (pm_content_uuid);

    create index idx_re_uuid1_uuid2_uuid3 on am_relation (re_obj1_uuid, re_obj2_uuid, re_obj3_uuid);

    create index idx_wo_target on am_workflow (wo_target);

    create index idx_wo_type on am_workflow (wo_saveable_type);

    create index idx_wo_status on am_workflow (wo_status);

    create index idx_wo_template_id on am_workflow (wo_template_id);

    create index idx_wo_entry_uid on am_workflow (wo_entry_uid);

    create index idx_wo_type2 on am_workflow (wo_saveable_action);

    create sequence am_wfentry_seq;

    create sequence am_wfother_seq;

    create sequence log_command_sequence;

    create index idx_at_uuid_name on am_attribute(at_uuid,at_name);

    create index idx_at_nameu_lvalue on am_attribute(at_name_upper,at_long_value);

    create index idx_at_nameu_bovalue on am_attribute(at_name_upper,at_baseobject_value);

    create index idx_at_name_searchvalue on am_attribute(at_name,at_search_value);

    create index idx_ob_oclass_id on am_object(ob_object_class,ob_id);

    create index idx_ob_oclass_idu on am_object(ob_object_class,ob_id_upper);

    create index idx_ob_oclass_idi on am_object(ob_object_class,ob_id_int);

    create unique index idx_ob_idu_oclass_parentuuid on am_object(ob_id_upper,ob_object_class,ob_parent_uuid);

    create index idx_ob_oclass_disc12 on am_object(ob_object_class,ob_discriminator1,ob_discriminator2);

    create index idx_ob_lock_uuid on am_object(ob_lock_by,ob_lock_flag,ob_uuid);

    create index idx_re_oclass_uuid1 on am_relation(re_object_class,re_obj1_uuid);

    create index idx_re_oclass_uuid2 on am_relation(re_object_class,re_obj2_uuid);

    create index idx_re_uuid1_name on am_relation(re_obj1_uuid,re_name);

    create index idx_au_cat_type_time on am_audit(au_category,au_type,au_reported_time);

    create index idx_au_cat_type_time_a on am_audit_a(au_category,au_type,au_reported_time);

    create index idx_au_cat_type_time_b on am_audit_b(au_category,au_type,au_reported_time);

    create index idx_au_cat_type_time_c on am_audit_c(au_category,au_type,au_reported_time);

    create index idx_aa_name_id_sid on am_audit_attr(aa_name,aa_id,aa_server_id);

    create index idx_aa_nameu_id_sid on am_audit_attr(aa_name_upper,aa_id,aa_server_id);

    create index idx_aa_name_id_sid_a on am_audit_attr_a(aa_name,aa_id,aa_server_id);

    create index idx_aa_nameu_id_sid_a on am_audit_attr_a(aa_name_upper,aa_id,aa_server_id);

    create index idx_aa_name_id_sid_b on am_audit_attr_b(aa_name,aa_id,aa_server_id);

    create index idx_aa_nameu_id_sid_b on am_audit_attr_b(aa_name_upper,aa_id,aa_server_id);

    create index idx_aa_name_id_sid_c on am_audit_attr_c(aa_name,aa_id,aa_server_id);

    create index idx_aa_nameu_id_sid_c on am_audit_attr_c(aa_name_upper,aa_id,aa_server_id);

    create index idx_wo_stype_sact_stat on am_workflow(wo_saveable_type,wo_saveable_action,wo_status);

    create index idx_wo_stat_stype_sact on am_workflow(wo_status,wo_saveable_type,wo_saveable_action);

    create index idx_wo_target_tclass on am_workflow(wo_target,wo_target_class);

    create index idx_r2_uuid2_name_uuid1 on am_relation2(r2_obj2_uuid,r2_name,r2_obj1_uuid);

    create index idx_an_anc_des_type on am_ancestry(an_ancestor,an_descendant,an_type);

    create index idx_pm_end_modtime on am_pinmailer(pm_ended,pm_modified_time);

    create index idx_pm_entryuid_modtime on am_pinmailer(pm_entry_uid,pm_modified_time);

    create index idx_pa_name_uuid on am_pinmailer_attr(pa_name, pa_uuid);

    create index idx_pa_nameu_uuid on am_pinmailer_attr(pa_name_upper, pa_uuid);

    create index idx_ust_type_auth_user on am_userauthstate(ust_type,ust_auth_uuid,ust_user_uuid);

    create index idx_tst_status_date_uuid on am_tokenauthstate(tst_status, tst_last_modified_date, tst_token_uuid);

    create index idx_usn_latest_expy on am_usersession(usn_latest_expy);

    create index idx_bm_uuid_vendor_label_type on am_biometric(bm_usr_uuid,bm_vendor,bm_label,bm_type);

    create index idx_imp_impersonator on am_impersonation(imp_impersonator_uuid,imp_impersonator_oc,imp_sequence,imp_impersonated_uuid);

    create index idx_esso_si_appuid on am_esso_entitlement(si_app_userid, si_appid);

    create index idx_ctx_useruuid_res_sts on am_contextualauthnhistory(ctx_user_uuid, ctx_authn_res_sts);

    create index idx_ctx_date_user_uuid on am_contextualauthnhistory(ctx_date, ctx_user_uuid);

    create unique index idx_im_app_id_unique on am_idmapping(im_ext_app_uuid,im_ext_id,im_unique_id_app);

    create unique index idx_im_user_app_profile on am_idmapping(im_user_uuid, im_ext_app_uuid, im_profile_name);

    create index idx_im_app_id on am_idmapping(im_ext_app_uuid,im_ext_id);
    
    create index idx_im_app_profile on am_idmapping(im_ext_app_uuid,im_profile_name);

    create index idx_im_app_idu on am_idmapping(im_ext_app_uuid,im_ext_id_upper);

    create index idx_im_user_app_idu on am_idmapping(im_user_uuid, im_ext_app_uuid,im_ext_id_upper);

    create index idx_ot_usruuid_exp on am_oauthtoken(ot_user_uuid,ot_expiry_time);

    create index idx_ot_usruuid_typ_exp on am_oauthtoken(ot_user_uuid,ot_type,ot_expiry_time);

    create index idx_ky_user_uuid on am_user_key(ky_user_uuid);

    create unique index idx_ky_user_uuid_key_id on am_user_key(ky_user_uuid,ky_key_id);

    create index idx_ky_cryptoapp_user_uuid on am_user_key(ky_cryptoapp_uuid, ky_user_uuid);

    create unique index idx_de_type_id on am_user_device(de_type,de_id);

    create index idx_rdu_user_uuid on am_relation_device_user(rdu_user_uuid);

    create index idx_rdt_token_uuid_instance on am_relation_device_token(rdt_token_uuid, rdt_token_instance);
    
    create index idx_token_expiryTime on am_rp_token (rpt_token_expiry_time);

    create index idx_rpt_lookupmoduleuuid_useruuid_type_exp on am_rp_token(rpt_user_uuid,rpt_lookup_module_uuid,rpt_type);

    create index idx_rpt_sessioniid_type_exp on am_rp_token(rpt_session_iid,rpt_type);
    insert into am_vars (va_name, va_version, va_value) values ('SchemaVersion', 1, '1137');
        
-- START OF Quartz

CREATE TABLE qrtz_job_details (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    JOB_NAME VARCHAR2(200) NOT NULL,
    JOB_GROUP VARCHAR2(200) NOT NULL,
    DESCRIPTION VARCHAR2(250) NULL,
    JOB_CLASS_NAME VARCHAR2(250) NOT NULL,
    IS_DURABLE VARCHAR2(1) NOT NULL,
    IS_NONCONCURRENT VARCHAR2(1) NOT NULL,
    IS_UPDATE_DATA VARCHAR2(1) NOT NULL,
    REQUESTS_RECOVERY VARCHAR2(1) NOT NULL,
    JOB_DATA BLOB NULL,
    CONSTRAINT QRTZ_JOB_DETAILS_PK PRIMARY KEY (
        SCHED_NAME,
        JOB_NAME,
        JOB_GROUP
        )
    );

CREATE TABLE qrtz_triggers (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    TRIGGER_NAME VARCHAR2(200) NOT NULL,
    TRIGGER_GROUP VARCHAR2(200) NOT NULL,
    JOB_NAME VARCHAR2(200) NOT NULL,
    JOB_GROUP VARCHAR2(200) NOT NULL,
    DESCRIPTION VARCHAR2(250) NULL,
    NEXT_FIRE_TIME NUMBER(13) NULL,
    PREV_FIRE_TIME NUMBER(13) NULL,
    PRIORITY NUMBER(13) NULL,
    TRIGGER_STATE VARCHAR2(16) NOT NULL,
    TRIGGER_TYPE VARCHAR2(8) NOT NULL,
    START_TIME NUMBER(13) NOT NULL,
    END_TIME NUMBER(13) NULL,
    CALENDAR_NAME VARCHAR2(200) NULL,
    MISFIRE_INSTR NUMBER(2) NULL,
    JOB_DATA BLOB NULL,
    CONSTRAINT QRTZ_TRIGGERS_PK PRIMARY KEY (
        SCHED_NAME,
        TRIGGER_NAME,
        TRIGGER_GROUP
        ),
    CONSTRAINT QRTZ_TRIGGER_TO_JOBS_FK FOREIGN KEY (
        SCHED_NAME,
        JOB_NAME,
        JOB_GROUP
        ) REFERENCES QRTZ_JOB_DETAILS(SCHED_NAME, JOB_NAME, JOB_GROUP)
    );

CREATE TABLE qrtz_simple_triggers (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    TRIGGER_NAME VARCHAR2(200) NOT NULL,
    TRIGGER_GROUP VARCHAR2(200) NOT NULL,
    REPEAT_COUNT NUMBER(7) NOT NULL,
    REPEAT_INTERVAL NUMBER(12) NOT NULL,
    TIMES_TRIGGERED NUMBER(10) NOT NULL,
    CONSTRAINT QRTZ_SIMPLE_TRIG_PK PRIMARY KEY (
        SCHED_NAME,
        TRIGGER_NAME,
        TRIGGER_GROUP
        ),
    CONSTRAINT QRTZ_SIMPLE_TRIG_TO_TRIG_FK FOREIGN KEY (
        SCHED_NAME,
        TRIGGER_NAME,
        TRIGGER_GROUP
        ) REFERENCES QRTZ_TRIGGERS(SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP)
    );

CREATE TABLE qrtz_cron_triggers (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    TRIGGER_NAME VARCHAR2(200) NOT NULL,
    TRIGGER_GROUP VARCHAR2(200) NOT NULL,
    CRON_EXPRESSION VARCHAR2(120) NOT NULL,
    TIME_ZONE_ID VARCHAR2(80),
    CONSTRAINT QRTZ_CRON_TRIG_PK PRIMARY KEY (
        SCHED_NAME,
        TRIGGER_NAME,
        TRIGGER_GROUP
        ),
    CONSTRAINT QRTZ_CRON_TRIG_TO_TRIG_FK FOREIGN KEY (
        SCHED_NAME,
        TRIGGER_NAME,
        TRIGGER_GROUP
        ) REFERENCES QRTZ_TRIGGERS(SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP)
    );

CREATE TABLE qrtz_simprop_triggers (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    TRIGGER_NAME VARCHAR2(200) NOT NULL,
    TRIGGER_GROUP VARCHAR2(200) NOT NULL,
    STR_PROP_1 VARCHAR2(512) NULL,
    STR_PROP_2 VARCHAR2(512) NULL,
    STR_PROP_3 VARCHAR2(512) NULL,
    INT_PROP_1 NUMBER(10) NULL,
    INT_PROP_2 NUMBER(10) NULL,
    LONG_PROP_1 NUMBER(13) NULL,
    LONG_PROP_2 NUMBER(13) NULL,
    DEC_PROP_1 NUMERIC(13, 4) NULL,
    DEC_PROP_2 NUMERIC(13, 4) NULL,
    BOOL_PROP_1 VARCHAR2(1) NULL,
    BOOL_PROP_2 VARCHAR2(1) NULL,
    CONSTRAINT QRTZ_SIMPROP_TRIG_PK PRIMARY KEY (
        SCHED_NAME,
        TRIGGER_NAME,
        TRIGGER_GROUP
        ),
    CONSTRAINT QRTZ_SIMPROP_TRIG_TO_TRIG_FK FOREIGN KEY (
        SCHED_NAME,
        TRIGGER_NAME,
        TRIGGER_GROUP
        ) REFERENCES QRTZ_TRIGGERS(SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP)
    );

CREATE TABLE qrtz_blob_triggers (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    TRIGGER_NAME VARCHAR2(200) NOT NULL,
    TRIGGER_GROUP VARCHAR2(200) NOT NULL,
    BLOB_DATA BLOB NULL,
    CONSTRAINT QRTZ_BLOB_TRIG_PK PRIMARY KEY (
        SCHED_NAME,
        TRIGGER_NAME,
        TRIGGER_GROUP
        ),
    CONSTRAINT QRTZ_BLOB_TRIG_TO_TRIG_FK FOREIGN KEY (
        SCHED_NAME,
        TRIGGER_NAME,
        TRIGGER_GROUP
        ) REFERENCES QRTZ_TRIGGERS(SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP)
    );

CREATE TABLE qrtz_calendars (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    CALENDAR_NAME VARCHAR2(200) NOT NULL,
    CALENDAR BLOB NOT NULL,
    CONSTRAINT QRTZ_CALENDARS_PK PRIMARY KEY (
        SCHED_NAME,
        CALENDAR_NAME
        )
    );

CREATE TABLE qrtz_paused_trigger_grps (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    TRIGGER_GROUP VARCHAR2(200) NOT NULL,
    CONSTRAINT QRTZ_PAUSED_TRIG_GRPS_PK PRIMARY KEY (
        SCHED_NAME,
        TRIGGER_GROUP
        )
    );

CREATE TABLE qrtz_fired_triggers (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    ENTRY_ID VARCHAR2(95) NOT NULL,
    TRIGGER_NAME VARCHAR2(200) NOT NULL,
    TRIGGER_GROUP VARCHAR2(200) NOT NULL,
    INSTANCE_NAME VARCHAR2(200) NOT NULL,
    FIRED_TIME NUMBER(13) NOT NULL,
    SCHED_TIME NUMBER(13) NOT NULL,
    PRIORITY NUMBER(13) NOT NULL,
    STATE VARCHAR2(16) NOT NULL,
    JOB_NAME VARCHAR2(200) NULL,
    JOB_GROUP VARCHAR2(200) NULL,
    IS_NONCONCURRENT VARCHAR2(1) NULL,
    REQUESTS_RECOVERY VARCHAR2(1) NULL,
    CONSTRAINT QRTZ_FIRED_TRIGGER_PK PRIMARY KEY (
        SCHED_NAME,
        ENTRY_ID
        )
    );

CREATE TABLE qrtz_scheduler_state (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    INSTANCE_NAME VARCHAR2(200) NOT NULL,
    LAST_CHECKIN_TIME NUMBER(13) NOT NULL,
    CHECKIN_INTERVAL NUMBER(13) NOT NULL,
    CONSTRAINT QRTZ_SCHEDULER_STATE_PK PRIMARY KEY (
        SCHED_NAME,
        INSTANCE_NAME
        )
    );

CREATE TABLE qrtz_locks (
    SCHED_NAME VARCHAR2(120) NOT NULL,
    LOCK_NAME VARCHAR2(40) NOT NULL,
    CONSTRAINT QRTZ_LOCKS_PK PRIMARY KEY (
        SCHED_NAME,
        LOCK_NAME
        )
    );

CREATE INDEX idx_qrtz_j_req_recovery ON qrtz_job_details (SCHED_NAME, REQUESTS_RECOVERY);

CREATE INDEX idx_qrtz_j_grp ON qrtz_job_details (SCHED_NAME, JOB_GROUP);

CREATE INDEX idx_qrtz_t_j ON qrtz_triggers (SCHED_NAME, JOB_NAME, JOB_GROUP);

CREATE INDEX idx_qrtz_t_jg ON qrtz_triggers (SCHED_NAME, JOB_GROUP);

CREATE INDEX idx_qrtz_t_c ON qrtz_triggers (SCHED_NAME, CALENDAR_NAME);

CREATE INDEX idx_qrtz_t_g ON qrtz_triggers (SCHED_NAME, TRIGGER_GROUP);

CREATE INDEX idx_qrtz_t_state ON qrtz_triggers (SCHED_NAME, TRIGGER_STATE);

CREATE INDEX idx_qrtz_t_n_state ON qrtz_triggers (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP, TRIGGER_STATE);

CREATE INDEX idx_qrtz_t_n_g_state ON qrtz_triggers (SCHED_NAME, TRIGGER_GROUP, TRIGGER_STATE);

CREATE INDEX idx_qrtz_t_next_fire_time ON qrtz_triggers (SCHED_NAME, NEXT_FIRE_TIME);

CREATE INDEX idx_qrtz_t_nft_st ON qrtz_triggers (SCHED_NAME, TRIGGER_STATE, NEXT_FIRE_TIME);

CREATE INDEX idx_qrtz_t_nft_misfire ON qrtz_triggers (SCHED_NAME, MISFIRE_INSTR, NEXT_FIRE_TIME);

CREATE INDEX idx_qrtz_t_nft_st_misfire ON qrtz_triggers (SCHED_NAME, MISFIRE_INSTR, NEXT_FIRE_TIME, TRIGGER_STATE);

CREATE INDEX idx_qrtz_t_nft_st_misfire_grp ON qrtz_triggers (SCHED_NAME, MISFIRE_INSTR, NEXT_FIRE_TIME, TRIGGER_GROUP, TRIGGER_STATE);

CREATE INDEX idx_qrtz_ft_trig_inst_name ON qrtz_fired_triggers (SCHED_NAME, INSTANCE_NAME);

CREATE INDEX idx_qrtz_ft_inst_job_req_rcvry ON qrtz_fired_triggers (SCHED_NAME, INSTANCE_NAME, REQUESTS_RECOVERY);

CREATE INDEX idx_qrtz_ft_j_g ON qrtz_fired_triggers (SCHED_NAME, JOB_NAME, JOB_GROUP);

CREATE INDEX idx_qrtz_ft_jg ON qrtz_fired_triggers (SCHED_NAME, JOB_GROUP);

CREATE INDEX idx_qrtz_ft_t_g ON qrtz_fired_triggers (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP);

CREATE INDEX idx_qrtz_ft_tg ON qrtz_fired_triggers (SCHED_NAME, TRIGGER_GROUP);

-- END OF Quartz

-- START OF Additional Script

create view am_vw_audit_b_a as select * from am_audit_b union all select * from am_audit_a;
create view am_vw_audit_c_b as select * from am_audit_c union all select * from am_audit_b;
create view am_vw_audit_a_c as select * from am_audit_a union all select * from am_audit_c;

create view am_vw_audit_attribute_b_a as select * from am_audit_attr_b union all select * from am_audit_attr_a;
create view am_vw_audit_attribute_c_b as select * from am_audit_attr_c union all select * from am_audit_attr_b;
create view am_vw_audit_attribute_a_c as select * from am_audit_attr_a union all select * from am_audit_attr_c;


create or replace procedure sp_truncate_am_audit(suffix in varchar2)
as
	sql_stmt varchar2(26);
begin
	sql_stmt := CONCAT('truncate table am_audit_', suffix);
	execute immediate sql_stmt;
end sp_truncate_am_audit;
/

create or replace procedure sp_truncate_am_audit_attr(suffix in varchar2)
as
	sql_stmt varchar2(32);
begin
	sql_stmt := CONCAT('truncate table am_audit_attr_', suffix);
	execute immediate sql_stmt;
end sp_truncate_am_audit_attr;
/

-- END OF Additional Script

-- Uncomment the following and input the user/role that will be used to connect to AccessMatrix for additional housekeeping privileges. 

	-- grant execute on dbo.sp_truncate_am_audit to User;
	-- grant execute on dbo.sp_truncate_am_audit_attr to User;
	
