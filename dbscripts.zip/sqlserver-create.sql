
    create table OS_CURRENTSTEP (
        id numeric(19,0) identity not null,
        action_Id int null,
        caller varchar(64) null,
        finish_Date datetime null,
        start_Date datetime null,
        due_Date datetime null,
        owner varchar(64) null,
        status varchar(1024) null,
        step_Id int null,
        entry_Id numeric(19,0) null,
        primary key (id)
    );

    create table OS_HISTORYSTEP (
        id numeric(19,0) identity not null,
        action_Id int null,
        caller varchar(1024) null,
        finish_Date datetime null,
        start_Date datetime null,
        due_Date datetime null,
        owner varchar(64) null,
        status varchar(1024) null,
        step_Id int null,
        entry_Id numeric(19,0) null,
        primary key (id)
    );

    create table OS_WFENTRY (
        id numeric(19,0) identity not null,
        version int not null,
        name varchar(128) null,
        state int null,
        primary key (id)
    );

    create table am_ancestry (
        an_descendant varchar(64) not null,
        an_ancestor varchar(64) not null,
        an_type char(1) not null,
        an_des_class varchar(32) not null,
        an_anc_class varchar(32) not null,
        an_gap int not null,
        primary key (an_descendant, an_ancestor, an_type)
    );

    create table am_attribute (
        at_uuid varchar(64) not null,
        at_name_upper varchar(64) not null,
        at_version numeric(19,0) not null,
        at_name varchar(64) null,
        at_class varchar(32) null,
        at_datatype varchar(16) null,
        at_date_value datetime null,
        at_long_value numeric(19,0) null,
        at_string_value varchar(3072) null,
        at_baseobject_value varchar(96) null,
        at_enctype char(1) null,
        at_search_value varchar(96) null,
        primary key (at_uuid, at_name_upper)
    );

    create table am_audit (
        au_server_id int not null,
        au_id numeric(19,0) not null,
        au_reported_time datetime not null,
        au_module_name varchar(12) null,
        au_category varchar(32) not null,
        au_type varchar(32) not null,
        au_result varchar(20) null,
        au_result_code varchar(16) null,
        au_ext_result_code varchar(16) null,
        au_message varchar(256) null,
        au_tx_id varchar(32) null,
        au_signature varchar(96) null,
        au_actor_class varchar(32) null,
        au_actor_uuid varchar(64) null,
        au_actor_id varchar(64) null,
        au_actor_user_store varchar(64) null,
        au_actor_ses_id varchar(64) null,
        au_actor_seg_uuid varchar(64) null,
        au_actor_ip_addr varchar(45) null,
        au_real_actor_id varchar(64) null,
        au_real_actor_user_store varchar(64) null,
        au_real_actor_ses_id varchar(64) null,
        au_real_actor_seg_uuid varchar(64) null,
        au_client_id varchar(45) null,
        au_client_type int null,
        au_target_class varchar(32) null,
        au_target_uuid varchar(64) null,
        au_target_id varchar(64) null,
        au_target_user_store varchar(64) null,
        au_target_seg_uuid varchar(64) null,
        au_custom_desc varchar(256) null,
        au_attr1_char16 varchar(16) null,
        au_attr2_char16 varchar(32) null,
        au_attr3_char32 varchar(32) null,
        au_attr4_char32 varchar(32) null,
        au_attr5_char64 varchar(64) null,
        au_attr6_char64 varchar(64) null,
        au_attr7_char64 varchar(64) null,
        au_attr8_char128 varchar(128) null,
        au_flag1 tinyint null,
        au_flag2 tinyint null,
        au_flag3 tinyint null,
        au_flag4 tinyint null,
        au_attr1_num numeric(19,0) null,
        au_attr2_num numeric(19,0) null,
        au_attr3_num numeric(19,0) null,
        au_attr4_num numeric(19,0) null,
        au_time1 datetime null,
        au_time2 datetime null,
        au_time3 datetime null,
        au_time4 datetime null,
        primary key (au_server_id, au_id)
    );

    create table am_audit_a (
        au_server_id int not null,
        au_id numeric(19,0) not null,
        au_reported_time datetime not null,
        au_module_name varchar(12) null,
        au_category varchar(32) not null,
        au_type varchar(32) not null,
        au_result varchar(20) null,
        au_result_code varchar(16) null,
        au_ext_result_code varchar(16) null,
        au_message varchar(256) null,
        au_tx_id varchar(32) null,
        au_signature varchar(96) null,
        au_actor_class varchar(32) null,
        au_actor_uuid varchar(64) null,
        au_actor_id varchar(64) null,
        au_actor_user_store varchar(64) null,
        au_actor_ses_id varchar(64) null,
        au_actor_seg_uuid varchar(64) null,
        au_actor_ip_addr varchar(45) null,
        au_real_actor_id varchar(64) null,
        au_real_actor_user_store varchar(64) null,
        au_real_actor_ses_id varchar(64) null,
        au_real_actor_seg_uuid varchar(64) null,
        au_client_id varchar(45) null,
        au_client_type int null,
        au_target_class varchar(32) null,
        au_target_uuid varchar(64) null,
        au_target_id varchar(64) null,
        au_target_user_store varchar(64) null,
        au_target_seg_uuid varchar(64) null,
        au_custom_desc varchar(256) null,
        au_attr1_char16 varchar(16) null,
        au_attr2_char16 varchar(32) null,
        au_attr3_char32 varchar(32) null,
        au_attr4_char32 varchar(32) null,
        au_attr5_char64 varchar(64) null,
        au_attr6_char64 varchar(64) null,
        au_attr7_char64 varchar(64) null,
        au_attr8_char128 varchar(128) null,
        au_flag1 tinyint null,
        au_flag2 tinyint null,
        au_flag3 tinyint null,
        au_flag4 tinyint null,
        au_attr1_num numeric(19,0) null,
        au_attr2_num numeric(19,0) null,
        au_attr3_num numeric(19,0) null,
        au_attr4_num numeric(19,0) null,
        au_time1 datetime null,
        au_time2 datetime null,
        au_time3 datetime null,
        au_time4 datetime null,
        primary key (au_server_id, au_id)
    );

    create table am_audit_attr (
        aa_server_id int not null,
        aa_id numeric(19,0) not null,
        aa_name varchar(64) not null,
        aa_part int not null,
        aa_name_upper varchar(64) not null,
        aa_datatype varchar(16) not null,
        aa_value varchar(3072) null,
        primary key (aa_server_id, aa_id, aa_name, aa_part)
    );

    create table am_audit_attr_a (
        aa_server_id int not null,
        aa_id numeric(19,0) not null,
        aa_name varchar(64) not null,
        aa_part int not null,
        aa_name_upper varchar(64) not null,
        aa_datatype varchar(16) not null,
        aa_value varchar(3072) null,
        primary key (aa_server_id, aa_id, aa_name, aa_part)
    );

    create table am_audit_attr_b (
        aa_server_id int not null,
        aa_id numeric(19,0) not null,
        aa_name varchar(64) not null,
        aa_part int not null,
        aa_name_upper varchar(64) not null,
        aa_datatype varchar(16) not null,
        aa_value varchar(3072) null,
        primary key (aa_server_id, aa_id, aa_name, aa_part)
    );

    create table am_audit_attr_c (
        aa_server_id int not null,
        aa_id numeric(19,0) not null,
        aa_name varchar(64) not null,
        aa_part int not null,
        aa_name_upper varchar(64) not null,
        aa_datatype varchar(16) not null,
        aa_value varchar(3072) null,
        primary key (aa_server_id, aa_id, aa_name, aa_part)
    );

    create table am_audit_b (
        au_server_id int not null,
        au_id numeric(19,0) not null,
        au_reported_time datetime not null,
        au_module_name varchar(12) null,
        au_category varchar(32) not null,
        au_type varchar(32) not null,
        au_result varchar(20) null,
        au_result_code varchar(16) null,
        au_ext_result_code varchar(16) null,
        au_message varchar(256) null,
        au_tx_id varchar(32) null,
        au_signature varchar(96) null,
        au_actor_class varchar(32) null,
        au_actor_uuid varchar(64) null,
        au_actor_id varchar(64) null,
        au_actor_user_store varchar(64) null,
        au_actor_ses_id varchar(64) null,
        au_actor_seg_uuid varchar(64) null,
        au_actor_ip_addr varchar(45) null,
        au_real_actor_id varchar(64) null,
        au_real_actor_user_store varchar(64) null,
        au_real_actor_ses_id varchar(64) null,
        au_real_actor_seg_uuid varchar(64) null,
        au_client_id varchar(45) null,
        au_client_type int null,
        au_target_class varchar(32) null,
        au_target_uuid varchar(64) null,
        au_target_id varchar(64) null,
        au_target_user_store varchar(64) null,
        au_target_seg_uuid varchar(64) null,
        au_custom_desc varchar(256) null,
        au_attr1_char16 varchar(16) null,
        au_attr2_char16 varchar(32) null,
        au_attr3_char32 varchar(32) null,
        au_attr4_char32 varchar(32) null,
        au_attr5_char64 varchar(64) null,
        au_attr6_char64 varchar(64) null,
        au_attr7_char64 varchar(64) null,
        au_attr8_char128 varchar(128) null,
        au_flag1 tinyint null,
        au_flag2 tinyint null,
        au_flag3 tinyint null,
        au_flag4 tinyint null,
        au_attr1_num numeric(19,0) null,
        au_attr2_num numeric(19,0) null,
        au_attr3_num numeric(19,0) null,
        au_attr4_num numeric(19,0) null,
        au_time1 datetime null,
        au_time2 datetime null,
        au_time3 datetime null,
        au_time4 datetime null,
        primary key (au_server_id, au_id)
    );

    create table am_audit_c (
        au_server_id int not null,
        au_id numeric(19,0) not null,
        au_reported_time datetime not null,
        au_module_name varchar(12) null,
        au_category varchar(32) not null,
        au_type varchar(32) not null,
        au_result varchar(20) null,
        au_result_code varchar(16) null,
        au_ext_result_code varchar(16) null,
        au_message varchar(256) null,
        au_tx_id varchar(32) null,
        au_signature varchar(96) null,
        au_actor_class varchar(32) null,
        au_actor_uuid varchar(64) null,
        au_actor_id varchar(64) null,
        au_actor_user_store varchar(64) null,
        au_actor_ses_id varchar(64) null,
        au_actor_seg_uuid varchar(64) null,
        au_actor_ip_addr varchar(45) null,
        au_real_actor_id varchar(64) null,
        au_real_actor_user_store varchar(64) null,
        au_real_actor_ses_id varchar(64) null,
        au_real_actor_seg_uuid varchar(64) null,
        au_client_id varchar(45) null,
        au_client_type int null,
        au_target_class varchar(32) null,
        au_target_uuid varchar(64) null,
        au_target_id varchar(64) null,
        au_target_user_store varchar(64) null,
        au_target_seg_uuid varchar(64) null,
        au_custom_desc varchar(256) null,
        au_attr1_char16 varchar(16) null,
        au_attr2_char16 varchar(32) null,
        au_attr3_char32 varchar(32) null,
        au_attr4_char32 varchar(32) null,
        au_attr5_char64 varchar(64) null,
        au_attr6_char64 varchar(64) null,
        au_attr7_char64 varchar(64) null,
        au_attr8_char128 varchar(128) null,
        au_flag1 tinyint null,
        au_flag2 tinyint null,
        au_flag3 tinyint null,
        au_flag4 tinyint null,
        au_attr1_num numeric(19,0) null,
        au_attr2_num numeric(19,0) null,
        au_attr3_num numeric(19,0) null,
        au_attr4_num numeric(19,0) null,
        au_time1 datetime null,
        au_time2 datetime null,
        au_time3 datetime null,
        au_time4 datetime null,
        primary key (au_server_id, au_id)
    );

    create table am_biometric (
        bm_usr_uuid varchar(64) not null,
        bm_vendor int not null,
        bm_type int not null,
        bm_label varchar(8) not null,
        bm_version numeric(19,0) not null,
        bm_refer_tplt image not null,
        bm_status int null,
        bm_partition int null,
        bm_last_verified_time datetime null,
        bm_creation_time datetime null,
        bm_modified_time datetime null,
        bm_sec_hash varchar(128) null,
        primary key (bm_usr_uuid, bm_vendor, bm_type, bm_label)
    );

    create table am_change_entry (
        ce_ev_server_id_int int not null,
        ce_ev_number numeric(19,0) not null,
        ce_sequence numeric(19,0) not null,
        ce_action varchar(32) not null,
        ce_name varchar(64) null,
        ce_value varchar(3072) null,
        primary key (ce_ev_server_id_int, ce_ev_number, ce_sequence)
    );

    create table am_contextualauthnhistory (
        ctx_uuid varchar(64) not null,
        ctx_date datetime null,
        ctx_user_uuid varchar(64) null,
        ctx_user_id varchar(64) null,
        ctx_authn_res varchar(1024) null,
        ctx_ip varchar(64) null,
        ctx_country varchar(64) null,
        ctx_countryisocode varchar(2) null,
        ctx_subdivision varchar(64) null,
        ctx_subdivisionisocode varchar(3) null,
        ctx_city varchar(64) null,
        ctx_latitude varchar(64) null,
        ctx_longitude varchar(64) null,
        ctx_geo_timezone varchar(64) null,
        ctx_module varchar(64) null,
        ctx_is_rooted varchar(8) null,
        ctx_authn_res_sts char(1) null,
        primary key (ctx_uuid)
    );

    create table am_deleted_object (
        do_uuid varchar(64) not null,
        do_object_class varchar(32) null,
        do_version numeric(19,0) null,
        do_id varchar(64) null,
        do_id_upper varchar(64) null,
        do_id_int int null,
        do_name varchar(64) null,
        do_name_upper varchar(64) null,
        do_dn varchar(256) null,
        do_dn_upper varchar(256) null,
        do_description varchar(256) null,
        do_discriminator1 varchar(64) null,
        do_discriminator2 varchar(64) null,
        do_parent_uuid varchar(64) null,
        do_parent_class varchar(32) null,
        do_handler_class varchar(96) null,
        do_status varchar(16) null,
        do_creator varchar(64) null,
        do_created_time datetime null,
        do_modifier varchar(64) null,
        do_modified_time datetime null,
        do_admin_modifier varchar(64) null,
        do_admin_modified_time datetime null,
        do_reserved1 varchar(64) null,
        primary key (do_uuid)
    );

    create table am_esso_entitlement (
        si_useruuid varchar(64) not null,
        si_appid varchar(64) not null,
        si_pid int not null,
        si_entitlement_prn varchar(64) not null,
        si_userid varchar(64) null,
        si_app_userid varchar(64) null,
        si_share_prn varchar(64) null,
        si_share_res varchar(64) null,
        si_pwd_modified_time varchar(64) null,
        si_created_time datetime null,
        primary key (si_useruuid, si_appid, si_pid, si_entitlement_prn)
    );

    create table am_event (
        ev_server_id_int int not null,
        ev_id numeric(19,0) not null,
        ev_time datetime not null,
        ev_tx_id varchar(32) null,
        ev_category varchar(32) not null,
        ev_type varchar(32) not null,
        ev_target_class varchar(32) null,
        ev_target_uuid varchar(64) null,
        ev_target_version numeric(19,0) null,
        primary key (ev_server_id_int, ev_id)
    );

    create table am_idmapping (
        im_user_uuid varchar(64) not null,
        im_ext_app_uuid varchar(64) not null,
        im_ext_id varchar(64) not null,
        im_partition int null,
        im_ext_id_upper varchar(64) not null,
        im_unique_id_app varchar(8) not null,
        im_ext_id_type varchar(16) not null,
        im_other_attr1 varchar(2048) null,
        im_other_attr2 varchar(2048) null,
        im_profile_name varchar(16) not null,
        im_created_time datetime not null,
        primary key (im_user_uuid, im_ext_app_uuid, im_ext_id)
    );

    create table am_impersonation (
        imp_impersonated_uuid varchar(64) not null,
        imp_impersonator_uuid varchar(64) not null,
        imp_impersonator_oc varchar(32) not null,
        imp_sequence int not null,
        imp_start_time datetime null,
        imp_end_time datetime null,
        imp_last_modified_time datetime null,
        imp_last_modifier_uuid varchar(64) null,
        primary key (imp_impersonated_uuid, imp_impersonator_uuid, imp_impersonator_oc, imp_sequence)
    );

    create table am_impersonation_obj (
        impobj_impersonated_uuid varchar(64) not null,
        impobj_impersonator_uuid varchar(64) not null,
        impobj_impersonator_oc varchar(32) not null,
        imp_sequence int not null,
        impobj_obj_uuid varchar(64) not null,
        impobj_obj_oc varchar(32) not null,
        impobj_other_attrs varchar(2048) null,
        primary key (impobj_impersonated_uuid, impobj_impersonator_uuid, impobj_impersonator_oc, imp_sequence, impobj_obj_uuid, impobj_obj_oc)
    );

    create table am_oauthtoken (
        ot_iid varchar(22) not null,
        ot_user_uuid varchar(64) null,
        ot_type varchar(3) null,
        ot_client_uuid varchar(64) null,
        ot_expiry_time numeric(19,0) null,
        ot_created_time numeric(19,0) null,
        ot_grant_iid varchar(22) null,
        primary key (ot_iid)
    );

    create table am_object (
        ob_uuid varchar(64) not null,
        ob_object_class varchar(32) not null,
        ob_version numeric(19,0) not null,
        ob_id varchar(64) not null,
        ob_id_upper varchar(64) not null,
        ob_id_int int null,
        ob_name varchar(64) null,
        ob_name_upper varchar(64) null,
        ob_dn varchar(250) null,
        ob_dn_upper varchar(250) null,
        ob_description varchar(256) null,
        ob_discriminator1 varchar(64) null,
        ob_discriminator2 varchar(64) null,
        ob_parent_uuid varchar(64) null,
        ob_parent_class varchar(32) null,
        ob_handler_class varchar(96) null,
        ob_status varchar(16) null,
        ob_creator varchar(64) null,
        ob_created_time datetime null,
        ob_modifier varchar(64) null,
        ob_modified_time datetime null,
        ob_admin_modifier varchar(64) null,
        ob_admin_modified_time datetime null,
        ob_lock_flag tinyint null,
        ob_lock_by varchar(64) null,
        ob_reserved1 varchar(64) null,
        primary key (ob_uuid)
    );

    create table am_pinmailer (
        pm_uuid varchar(64) not null,
        pm_version numeric(19,0) not null,
        pm_id varchar(64) not null unique,
        pm_entry_uid varchar(32) null,
        pm_template_id varchar(64) null,
        pm_module_id varchar(64) null,
        pm_content_type varchar(32) null,
        pm_content_action varchar(32) null,
        pm_status varchar(32) null,
        pm_content_uuid varchar(64) null,
        pm_content_summary varchar(256) null,
        pm_template_uuid varchar(64) null,
        pm_channel_uuid varchar(64) null,
        pm_delivery_summary varchar(256) null,
        pm_maker varchar(64) null,
        pm_made_time datetime null,
        pm_checker varchar(64) null,
        pm_checked_time datetime null,
        pm_creator varchar(64) null,
        pm_created_time datetime null,
        pm_modifier varchar(64) null,
        pm_modified_time datetime null,
        pm_ended tinyint null,
        pm_attr1_char16 varchar(16) null,
        pm_attr2_char16 varchar(16) null,
        pm_attr3_char32 varchar(32) null,
        pm_attr4_char32 varchar(32) null,
        pm_attr5_char64 varchar(64) null,
        pm_attr6_char64 varchar(64) null,
        pm_attr7_char128 varchar(128) null,
        pm_attr8_char256 varchar(256) null,
        pm_flag1 tinyint null,
        pm_flag2 tinyint null,
        pm_number1 numeric(19,0) null,
        pm_number2 numeric(19,0) null,
        pm_time1 datetime null,
        pm_time2 datetime null,
        primary key (pm_uuid)
    );

    create table am_pinmailer_attr (
        pa_uuid varchar(64) not null,
        pa_name varchar(64) not null,
        pa_part int not null,
        pa_name_upper varchar(64) not null,
        pa_datatype varchar(16) not null,
        pa_enctype char(1) not null,
        pa_value varchar(3072) null,
        primary key (pa_uuid, pa_name, pa_part)
    );

    create table am_relation (
        re_uuid varchar(64) not null,
        re_object_class varchar(32) not null,
        re_version numeric(19,0) not null,
        re_name varchar(32) not null,
        re_id varchar(64) null,
        re_obj1_uuid varchar(64) not null,
        re_obj2_uuid varchar(64) not null,
        re_obj3_uuid varchar(64) null,
        re_obj1_class varchar(32) null,
        re_obj2_class varchar(32) null,
        re_obj3_class varchar(32) null,
        re_parameters varchar(1024) null,
        re_description varchar(256) null,
        re_parent_uuid varchar(64) null,
        re_parent_class varchar(32) null,
        re_creator varchar(64) null,
        re_created_time datetime null,
        re_modifier varchar(64) null,
        re_modified_time datetime null,
        re_admin_modifier varchar(64) null,
        re_admin_modified_time datetime null,
        re_lock_flag tinyint null,
        re_lock_by varchar(64) null,
        primary key (re_uuid)
    );

    create table am_relation2 (
        r2_obj1_uuid varchar(64) not null,
        r2_name varchar(32) not null,
        r2_obj2_uuid varchar(64) not null,
        r2_obj1_class varchar(32) null,
        r2_obj2_class varchar(32) null,
        r2_created_time datetime null,
        primary key (r2_obj1_uuid, r2_name, r2_obj2_uuid)
    );

    create table am_relation_device_token (
        rdt_device_uuid varchar(64) not null,
        rdt_token_uuid varchar(64) not null,
        rdt_token_instance varchar(64) not null,
        rdt_created_time numeric(19,0) null,
        primary key (rdt_device_uuid, rdt_token_uuid, rdt_token_instance)
    );

    create table am_relation_device_user (
        rdu_device_uuid varchar(64) not null,
        rdu_user_uuid varchar(64) not null,
        rdu_created_time numeric(19,0) null,
        primary key (rdu_device_uuid, rdu_user_uuid)
    );

    create table am_tokenauthstate (
        tst_token_uuid varchar(64) not null,
        tst_func_id varchar(32) not null,
        tst_auth_mode varchar(8) not null,
        tst_version numeric(19,0) not null,
        tst_partition int null,
        tst_status varchar(20) null,
        tst_success_cnt int null,
        tst_fail_cnt int null,
        tst_last_stat_chg_date datetime null,
        tst_last_succ_date datetime null,
        tst_last_fail_date datetime null,
        tst_sec_hash varchar(128) null,
        tst_sec_data varchar(2048) null,
        tst_other_attrs varchar(1024) null,
        tst_last_modified_date datetime null,
        primary key (tst_token_uuid, tst_func_id, tst_auth_mode)
    );

    create table am_user_device (
        de_uuid varchar(16) not null,
        de_status varchar(16) null,
        de_type varchar(16) null,
        de_id varchar(64) null,
        de_agent varchar(64) null,
        de_desc varchar(64) null,
        de_tag varchar(256) null,
        de_custom_attr1 varchar(64) null,
        de_custom_attr2 varchar(64) null,
        de_custom_attr3 varchar(64) null,
        de_custom_attr4 varchar(512) null,
        de_custom_attr5 varchar(512) null,
        de_rooted tinyint null,
        de_created_time numeric(19,0) null,
        de_admin_modifier varchar(64) null,
        de_admin_modified_time numeric(19,0) null,
        de_last_status_change numeric(19,0) null,
        de_last_used_time numeric(19,0) null,
        primary key (de_uuid)
    );

    create table am_user_key (
        ky_uuid varchar(16) not null,
        ky_user_uuid varchar(64) null,
        ky_key_id varchar(64) null,
        ky_status varchar(16) null,
        ky_cryptoapp_uuid varchar(64) null,
        ky_key_provider_uuid varchar(64) null,
        ky_key_algo varchar(64) null,
        ky_private_key varchar(1800) null,
        ky_public_key varchar(1024) null,
        ky_key_usage varchar(64) null,
        ky_created_time numeric(19,0) null,
        ky_modified_time numeric(19,0) null,
        ky_last_status_change_time numeric(19,0) null,
        primary key (ky_uuid)
    );

    create table am_userauthstate (
        ust_user_uuid varchar(64) not null,
        ust_type varchar(3) not null,
        ust_auth_uuid varchar(64) not null,
        ust_version numeric(19,0) not null,
        ust_partition int null,
        ust_status varchar(20) null,
        ust_control_flag varchar(3) null,
        ust_start_date datetime null,
        ust_end_date datetime null,
        ust_success_cnt int null,
        ust_fail_cnt int null,
        ust_last_login_date datetime null,
        ust_last_logout_date datetime null,
        ust_last_pwd_chg_date datetime null,
        ust_last_stat_chg_date datetime null,
        ust_sec_hash varchar(128) null,
        ust_other_attrs varchar(2048) null,
        ust_last_modified_date datetime null,
        primary key (ust_user_uuid, ust_type, ust_auth_uuid)
    );

    create table am_usersession (
        usn_uuid varchar(64) not null,
        usn_version numeric(19,0) not null,
        usn_count int null,
        usn_earliest_expy numeric(19,0) null,
        usn_latest_expy numeric(19,0) null,
        usn_last_update numeric(19,0) null,
        usn_sec_hash varchar(128) null,
        usn_sessions varchar(3072) null,
        primary key (usn_uuid)
    );

    create table am_vars (
        va_name varchar(64) not null,
        va_version numeric(19,0) not null,
        va_value varchar(256) null,
        primary key (va_name)
    );

    create table am_workflow (
        wo_uuid varchar(64) not null,
        wo_version numeric(19,0) not null,
        wo_id varchar(64) not null unique,
        wo_entry_uid varchar(64) null,
        wo_template_id varchar(128) null,
        wo_name varchar(64) null,
        wo_name_upper varchar(64) null,
        wo_saveable_type varchar(32) null,
        wo_saveable_action varchar(32) null,
        wo_status varchar(32) null,
        wo_content varchar(256) null,
        wo_target varchar(64) null,
        wo_target_class varchar(32) null,
        wo_maker varchar(64) null,
        wo_made_time datetime null,
        wo_checker varchar(64) null,
        wo_checked_time datetime null,
        wo_creator varchar(64) null,
        wo_created_time datetime null,
        wo_modifier varchar(64) null,
        wo_modified_time datetime null,
        wo_attr1_char16 varchar(16) null,
        wo_attr2_char16 varchar(16) null,
        wo_attr3_char32 varchar(32) null,
        wo_attr4_char32 varchar(32) null,
        wo_attr5_char64 varchar(64) null,
        wo_attr6_char64 varchar(64) null,
        wo_attr7_char128 varchar(128) null,
        wo_attr8_char256 varchar(256) null,
        wo_flag1 tinyint null,
        wo_flag2 tinyint null,
        wo_number1 numeric(19,0) null,
        wo_number2 numeric(19,0) null,
        wo_time1 datetime null,
        wo_time2 datetime null,
        primary key (wo_uuid)
    );
    
    create table am_rp_token (
    	rpt_token_uuid varchar(64) not null,
        rpt_token_hash varchar(64) not null unique,
        rpt_token varchar(3072) not null,
        rpt_user_uuid varchar(64) not null,
        rpt_lookup_module_uuid varchar(64) not null,
        rpt_type varchar(8) not null,
        rpt_at_expiry_time numeric(19,0),
        rpt_token_expiry_time numeric(19,0) not null,
        rpt_session_iid varchar(22),
        primary key (rpt_token_uuid)
    );

    alter table OS_CURRENTSTEP 
        add constraint FK8710A5CADD562C9A 
        foreign key (entry_Id) 
        references OS_WFENTRY;

    alter table OS_HISTORYSTEP 
        add constraint FK7835C765DD562C9A 
        foreign key (entry_Id) 
        references OS_WFENTRY;

    create index idx_at_name_bovalue on am_attribute (at_name, at_baseobject_value);

    create index idx_at_name_lvalue on am_attribute (at_name, at_long_value);

    create index idx_at_bovalue on am_attribute (at_baseobject_value);

    create index idx_au_taget_id on am_audit (au_target_id);

    create index idx_au_actor_id on am_audit (au_actor_id);

    create index idx_au_target_uuid on am_audit (au_target_uuid);

    create index idx_au_actor_uuid on am_audit (au_actor_uuid);

    create index idx_au_result_code on am_audit (au_result_code);

    create index idx_au_reported_time on am_audit (au_reported_time);

    create index idx_au_actor_id_a on am_audit_a (au_actor_id);

    create index idx_au_reported_time_a on am_audit_a (au_reported_time);

    create index idx_au_actor_uuid_a on am_audit_a (au_actor_uuid);

    create index idx_au_taget_id_a on am_audit_a (au_target_id);

    create index idx_au_target_uuid_a on am_audit_a (au_target_uuid);

    create index idx_au_result_code_a on am_audit_a (au_result_code);

    create index idx_au_actor_id_b on am_audit_b (au_actor_id);

    create index idx_au_reported_time_b on am_audit_b (au_reported_time);

    create index idx_au_actor_uuid_b on am_audit_b (au_actor_uuid);

    create index idx_au_taget_id_b on am_audit_b (au_target_id);

    create index idx_au_target_uuid_b on am_audit_b (au_target_uuid);

    create index idx_au_result_code_b on am_audit_b (au_result_code);

    create index idx_au_actor_id_c on am_audit_c (au_actor_id);

    create index idx_au_actor_uuid_c on am_audit_c (au_actor_uuid);

    create index idx_au_reported_time_c on am_audit_c (au_reported_time);

    create index idx_au_taget_id_c on am_audit_c (au_target_id);

    create index idx_au_target_uuid_c on am_audit_c (au_target_uuid);

    create index idx_au_result_code_c on am_audit_c (au_result_code);

    create index idx_ot_expiryTime on am_oauthtoken (ot_expiry_time);
	
    create index idx_ot_grant_iid on am_oauthtoken(ot_grant_iid);
	
    create index idx_ot_client_uuid on am_oauthtoken(ot_client_uuid);

    create index idx_ob_idu on am_object (ob_id_upper);

    create index idx_ob_disc1 on am_object (ob_discriminator1);

    create index idx_ob_disc2 on am_object (ob_discriminator2);

    create index idx_ob_idi on am_object (ob_id_int);

    create index idx_ob_id on am_object (ob_id);

    create index idx_ob_dn on am_object (ob_dn);

    create index idx_ob_dnu on am_object (ob_dn_upper);

    create index idx_pm_maker on am_pinmailer (pm_maker);

    create index idx_pm_status on am_pinmailer (pm_status);

    create index idx_pm_content on am_pinmailer (pm_content_uuid);

    create index idx_re_uuid1_uuid2_uuid3 on am_relation (re_obj1_uuid, re_obj2_uuid, re_obj3_uuid);

    create index idx_wo_target on am_workflow (wo_target);

    create index idx_wo_type on am_workflow (wo_saveable_type);

    create index idx_wo_status on am_workflow (wo_status);

    create index idx_wo_template_id on am_workflow (wo_template_id);

    create index idx_wo_entry_uid on am_workflow (wo_entry_uid);

    create index idx_wo_type2 on am_workflow (wo_saveable_action);

    create index idx_at_uuid_name on am_attribute(at_uuid,at_name);

    create index idx_at_nameu_lvalue on am_attribute(at_name_upper,at_long_value);

    create index idx_at_nameu_bovalue on am_attribute(at_name_upper,at_baseobject_value);

    create index idx_at_name_searchvalue on am_attribute(at_name,at_search_value);

    create index idx_ob_oclass_id on am_object(ob_object_class,ob_id);

    create index idx_ob_oclass_idu on am_object(ob_object_class,ob_id_upper);

    create index idx_ob_oclass_idi on am_object(ob_object_class,ob_id_int);

    create unique index idx_ob_idu_oclass_parentuuid on am_object(ob_id_upper,ob_object_class,ob_parent_uuid);

    create index idx_ob_oclass_disc12 on am_object(ob_object_class,ob_discriminator1,ob_discriminator2);

    create index idx_ob_lock_uuid on am_object(ob_lock_by,ob_lock_flag,ob_uuid);

    create index idx_re_oclass_uuid1 on am_relation(re_object_class,re_obj1_uuid);

    create index idx_re_oclass_uuid2 on am_relation(re_object_class,re_obj2_uuid);

    create index idx_re_uuid1_name on am_relation(re_obj1_uuid,re_name);

    create index idx_au_cat_type_time on am_audit(au_category,au_type,au_reported_time);

    create index idx_au_cat_type_time_a on am_audit_a(au_category,au_type,au_reported_time);

    create index idx_au_cat_type_time_b on am_audit_b(au_category,au_type,au_reported_time);

    create index idx_au_cat_type_time_c on am_audit_c(au_category,au_type,au_reported_time);

    create index idx_aa_name_id_sid on am_audit_attr(aa_name,aa_id,aa_server_id);

    create index idx_aa_nameu_id_sid on am_audit_attr(aa_name_upper,aa_id,aa_server_id);

    create index idx_aa_name_id_sid_a on am_audit_attr_a(aa_name,aa_id,aa_server_id);

    create index idx_aa_nameu_id_sid_a on am_audit_attr_a(aa_name_upper,aa_id,aa_server_id);

    create index idx_aa_name_id_sid_b on am_audit_attr_b(aa_name,aa_id,aa_server_id);

    create index idx_aa_nameu_id_sid_b on am_audit_attr_b(aa_name_upper,aa_id,aa_server_id);

    create index idx_aa_name_id_sid_c on am_audit_attr_c(aa_name,aa_id,aa_server_id);

    create index idx_aa_nameu_id_sid_c on am_audit_attr_c(aa_name_upper,aa_id,aa_server_id);

    create index idx_wo_stype_sact_stat on am_workflow(wo_saveable_type,wo_saveable_action,wo_status);

    create index idx_wo_stat_stype_sact on am_workflow(wo_status,wo_saveable_type,wo_saveable_action);

    create index idx_wo_target_tclass on am_workflow(wo_target,wo_target_class);

    create index idx_r2_uuid2_name_uuid1 on am_relation2(r2_obj2_uuid,r2_name,r2_obj1_uuid);

    create index idx_an_anc_des_type on am_ancestry(an_ancestor,an_descendant,an_type);

    create index idx_pm_end_modtime on am_pinmailer(pm_ended,pm_modified_time);

    create index idx_pm_entryuid_modtime on am_pinmailer(pm_entry_uid,pm_modified_time);

    create index idx_pa_name_uuid on am_pinmailer_attr(pa_name, pa_uuid);

    create index idx_pa_nameu_uuid on am_pinmailer_attr(pa_name_upper, pa_uuid);

    create index idx_ust_type_auth_user on am_userauthstate(ust_type,ust_auth_uuid,ust_user_uuid);

    create index idx_tst_status_date_uuid on am_tokenauthstate(tst_status, tst_last_modified_date, tst_token_uuid);

    create index idx_usn_latest_expy on am_usersession(usn_latest_expy);

    create index idx_bm_uuid_vendor_label_type on am_biometric(bm_usr_uuid,bm_vendor,bm_label,bm_type);

    create index idx_imp_impersonator on am_impersonation(imp_impersonator_uuid,imp_impersonator_oc,imp_sequence,imp_impersonated_uuid);

    create index idx_esso_si_appuid on am_esso_entitlement(si_app_userid, si_appid);

    create index idx_ctx_useruuid_res_sts on am_contextualauthnhistory(ctx_user_uuid, ctx_authn_res_sts);

    create index idx_ctx_date_user_uuid on am_contextualauthnhistory(ctx_date, ctx_user_uuid);

    create unique index idx_im_app_id_unique on am_idmapping(im_ext_app_uuid,im_ext_id,im_unique_id_app);

    create unique index idx_im_user_app_profile on am_idmapping(im_user_uuid, im_ext_app_uuid, im_profile_name);

    create index idx_im_app_id on am_idmapping(im_ext_app_uuid,im_ext_id);
    
    create index idx_im_app_profile on am_idmapping(im_ext_app_uuid,im_profile_name);

    create index idx_im_app_idu on am_idmapping(im_ext_app_uuid,im_ext_id_upper);

    create index idx_im_user_app_idu on am_idmapping(im_user_uuid, im_ext_app_uuid,im_ext_id_upper);

    create index idx_ot_usruuid_exp on am_oauthtoken(ot_user_uuid,ot_expiry_time);

    create index idx_ot_usruuid_typ_exp on am_oauthtoken(ot_user_uuid,ot_type,ot_expiry_time);

    create index idx_ky_user_uuid on am_user_key(ky_user_uuid);

    create unique index idx_ky_user_uuid_key_id on am_user_key(ky_user_uuid,ky_key_id);

    create index idx_ky_cryptoapp_user_uuid on am_user_key(ky_cryptoapp_uuid, ky_user_uuid);

    create unique index idx_de_type_id on am_user_device(de_type,de_id);

    create index idx_rdu_user_uuid on am_relation_device_user(rdu_user_uuid);

    create index idx_rdt_token_uuid_instance on am_relation_device_token(rdt_token_uuid, rdt_token_instance);
    
    create index idx_token_expiryTime on am_rp_token (rpt_token_expiry_time);
    
    create index idx_rpt_lookupmoduleuuid_useruuid_type_exp on am_rp_token(rpt_user_uuid,rpt_lookup_module_uuid,rpt_type);

    create index idx_rpt_sessioniid_type_exp on am_rp_token(rpt_session_iid,rpt_type);
    insert into am_vars (va_name, va_version, va_value) values ('SchemaVersion', 1, '1137');

-- START OF Quartz

CREATE TABLE QRTZ_CALENDARS (
  SCHED_NAME VARCHAR (120)  NOT NULL ,
  CALENDAR_NAME VARCHAR (200)  NOT NULL ,
  CALENDAR IMAGE NOT NULL
);

CREATE TABLE QRTZ_CRON_TRIGGERS (
  SCHED_NAME VARCHAR (120)  NOT NULL ,
  TRIGGER_NAME VARCHAR (200)  NOT NULL ,
  TRIGGER_GROUP VARCHAR (200)  NOT NULL ,
  CRON_EXPRESSION VARCHAR (120)  NOT NULL ,
  TIME_ZONE_ID VARCHAR (80) 
);

CREATE TABLE QRTZ_FIRED_TRIGGERS (
  SCHED_NAME VARCHAR (120)  NOT NULL ,
  ENTRY_ID VARCHAR (95)  NOT NULL ,
  TRIGGER_NAME VARCHAR (200)  NOT NULL ,
  TRIGGER_GROUP VARCHAR (200)  NOT NULL ,
  INSTANCE_NAME VARCHAR (200)  NOT NULL ,
  FIRED_TIME BIGINT NOT NULL ,
  SCHED_TIME BIGINT NOT NULL ,
  PRIORITY INTEGER NOT NULL ,
  STATE VARCHAR (16)  NOT NULL,
  JOB_NAME VARCHAR (200)  NULL ,
  JOB_GROUP VARCHAR (200)  NULL ,
  IS_NONCONCURRENT VARCHAR (1)  NULL ,
  REQUESTS_RECOVERY VARCHAR (1)  NULL 
);

CREATE TABLE QRTZ_PAUSED_TRIGGER_GRPS (
  SCHED_NAME VARCHAR (120)  NOT NULL ,
  TRIGGER_GROUP VARCHAR (200)  NOT NULL 
);

CREATE TABLE QRTZ_SCHEDULER_STATE (
  SCHED_NAME VARCHAR (120)  NOT NULL ,
  INSTANCE_NAME VARCHAR (200)  NOT NULL ,
  LAST_CHECKIN_TIME BIGINT NOT NULL ,
  CHECKIN_INTERVAL BIGINT NOT NULL
);

CREATE TABLE QRTZ_LOCKS (
  SCHED_NAME VARCHAR (120)  NOT NULL ,
  LOCK_NAME VARCHAR (40)  NOT NULL 
);

CREATE TABLE QRTZ_JOB_DETAILS (
  SCHED_NAME VARCHAR (120)  NOT NULL ,
  JOB_NAME VARCHAR (200)  NOT NULL ,
  JOB_GROUP VARCHAR (200)  NOT NULL ,
  DESCRIPTION VARCHAR (250) NULL ,
  JOB_CLASS_NAME VARCHAR (250)  NOT NULL ,
  IS_DURABLE VARCHAR (1)  NOT NULL ,
  IS_NONCONCURRENT VARCHAR (1)  NOT NULL ,
  IS_UPDATE_DATA VARCHAR (1)  NOT NULL ,
  REQUESTS_RECOVERY VARCHAR (1)  NOT NULL ,
  JOB_DATA IMAGE NULL
);

CREATE TABLE QRTZ_SIMPLE_TRIGGERS (
  SCHED_NAME VARCHAR (120)  NOT NULL ,
  TRIGGER_NAME VARCHAR (200)  NOT NULL ,
  TRIGGER_GROUP VARCHAR (200)  NOT NULL ,
  REPEAT_COUNT BIGINT NOT NULL ,
  REPEAT_INTERVAL BIGINT NOT NULL ,
  TIMES_TRIGGERED BIGINT NOT NULL
);

CREATE TABLE QRTZ_SIMPROP_TRIGGERS (
  SCHED_NAME VARCHAR (120)  NOT NULL ,
  TRIGGER_NAME VARCHAR (200)  NOT NULL ,
  TRIGGER_GROUP VARCHAR (200)  NOT NULL ,
  STR_PROP_1 VARCHAR (512) NULL,
  STR_PROP_2 VARCHAR (512) NULL,
  STR_PROP_3 VARCHAR (512) NULL,
  INT_PROP_1 INT NULL,
  INT_PROP_2 INT NULL,
  LONG_PROP_1 BIGINT NULL,
  LONG_PROP_2 BIGINT NULL,
  DEC_PROP_1 NUMERIC (13,4) NULL,
  DEC_PROP_2 NUMERIC (13,4) NULL,
  BOOL_PROP_1 VARCHAR (1) NULL,
  BOOL_PROP_2 VARCHAR (1) NULL,
);

CREATE TABLE QRTZ_BLOB_TRIGGERS (
  SCHED_NAME VARCHAR (120)  NOT NULL ,
  TRIGGER_NAME VARCHAR (200)  NOT NULL ,
  TRIGGER_GROUP VARCHAR (200)  NOT NULL ,
  BLOB_DATA IMAGE NULL
);

CREATE TABLE QRTZ_TRIGGERS (
  SCHED_NAME VARCHAR (120)  NOT NULL ,
  TRIGGER_NAME VARCHAR (200)  NOT NULL ,
  TRIGGER_GROUP VARCHAR (200)  NOT NULL ,
  JOB_NAME VARCHAR (200)  NOT NULL ,
  JOB_GROUP VARCHAR (200)  NOT NULL ,
  DESCRIPTION VARCHAR (250) NULL ,
  NEXT_FIRE_TIME BIGINT NULL ,
  PREV_FIRE_TIME BIGINT NULL ,
  PRIORITY INTEGER NULL ,
  TRIGGER_STATE VARCHAR (16)  NOT NULL ,
  TRIGGER_TYPE VARCHAR (8)  NOT NULL ,
  START_TIME BIGINT NOT NULL ,
  END_TIME BIGINT NULL ,
  CALENDAR_NAME VARCHAR (200)  NULL ,
  MISFIRE_INSTR SMALLINT NULL ,
  JOB_DATA IMAGE NULL
);

ALTER TABLE QRTZ_CALENDARS WITH NOCHECK ADD
  CONSTRAINT PK_QRTZ_CALENDARS PRIMARY KEY  CLUSTERED
  (
    SCHED_NAME,
    CALENDAR_NAME
  ) ;

ALTER TABLE QRTZ_CRON_TRIGGERS WITH NOCHECK ADD
  CONSTRAINT PK_QRTZ_CRON_TRIGGERS PRIMARY KEY  CLUSTERED
  (
    SCHED_NAME,
    TRIGGER_NAME,
    TRIGGER_GROUP
  ) ;

ALTER TABLE QRTZ_FIRED_TRIGGERS WITH NOCHECK ADD
  CONSTRAINT PK_QRTZ_FIRED_TRIGGERS PRIMARY KEY  CLUSTERED
  (
    SCHED_NAME,
    ENTRY_ID
  ) ;

ALTER TABLE QRTZ_PAUSED_TRIGGER_GRPS WITH NOCHECK ADD
  CONSTRAINT PK_QRTZ_PAUSED_TRIGGER_GRPS PRIMARY KEY  CLUSTERED
  (
    SCHED_NAME,
    TRIGGER_GROUP
  ) ;

ALTER TABLE QRTZ_SCHEDULER_STATE WITH NOCHECK ADD
  CONSTRAINT PK_QRTZ_SCHEDULER_STATE PRIMARY KEY  CLUSTERED
  (
    SCHED_NAME,
    INSTANCE_NAME
  ) ;

ALTER TABLE QRTZ_LOCKS WITH NOCHECK ADD
  CONSTRAINT PK_QRTZ_LOCKS PRIMARY KEY  CLUSTERED
  (
    SCHED_NAME,
    LOCK_NAME
  ) ;

ALTER TABLE QRTZ_JOB_DETAILS WITH NOCHECK ADD
  CONSTRAINT PK_QRTZ_JOB_DETAILS PRIMARY KEY  CLUSTERED
  (
    SCHED_NAME,
    JOB_NAME,
    JOB_GROUP
  ) ;

ALTER TABLE QRTZ_SIMPLE_TRIGGERS WITH NOCHECK ADD
  CONSTRAINT PK_QRTZ_SIMPLE_TRIGGERS PRIMARY KEY  CLUSTERED
  (
    SCHED_NAME,
    TRIGGER_NAME,
    TRIGGER_GROUP
  ) ;

ALTER TABLE QRTZ_SIMPROP_TRIGGERS WITH NOCHECK ADD
  CONSTRAINT PK_QRTZ_SIMPROP_TRIGGERS PRIMARY KEY  CLUSTERED
  (
    SCHED_NAME,
    TRIGGER_NAME,
    TRIGGER_GROUP
  ) ;

ALTER TABLE QRTZ_TRIGGERS WITH NOCHECK ADD
  CONSTRAINT PK_QRTZ_TRIGGERS PRIMARY KEY  CLUSTERED
  (
    SCHED_NAME,
    TRIGGER_NAME,
    TRIGGER_GROUP
  ) ;

ALTER TABLE QRTZ_CRON_TRIGGERS ADD
  CONSTRAINT FK_QRTZ_CRON_TRIGGERS_QRTZ_TRIGGERS FOREIGN KEY
  (
    SCHED_NAME,
    TRIGGER_NAME,
    TRIGGER_GROUP
  ) REFERENCES QRTZ_TRIGGERS (
    SCHED_NAME,
    TRIGGER_NAME,
    TRIGGER_GROUP
  ) ON DELETE CASCADE;

ALTER TABLE QRTZ_SIMPLE_TRIGGERS ADD
  CONSTRAINT FK_QRTZ_SIMPLE_TRIGGERS_QRTZ_TRIGGERS FOREIGN KEY
  (
    SCHED_NAME,
    TRIGGER_NAME,
    TRIGGER_GROUP
  ) REFERENCES QRTZ_TRIGGERS (
    SCHED_NAME,
    TRIGGER_NAME,
    TRIGGER_GROUP
  ) ON DELETE CASCADE;

ALTER TABLE QRTZ_SIMPROP_TRIGGERS ADD
  CONSTRAINT FK_QRTZ_SIMPROP_TRIGGERS_QRTZ_TRIGGERS FOREIGN KEY
  (
    SCHED_NAME,
    TRIGGER_NAME,
    TRIGGER_GROUP
  ) REFERENCES QRTZ_TRIGGERS (
    SCHED_NAME,
    TRIGGER_NAME,
    TRIGGER_GROUP
  ) ON DELETE CASCADE;

ALTER TABLE QRTZ_TRIGGERS ADD
  CONSTRAINT FK_QRTZ_TRIGGERS_QRTZ_JOB_DETAILS FOREIGN KEY
  (
    SCHED_NAME,
    JOB_NAME,
    JOB_GROUP
  ) REFERENCES QRTZ_JOB_DETAILS (
    SCHED_NAME,
    JOB_NAME,
    JOB_GROUP
  );


-- END OF Quartz

-- START OF Additional Script

-- If you run this script from MSSQL Management Studio, please
--   1. Move the Additional Script to a new script before run this script.
--   2. Uncomment the following GO command before  run the new script.

-- GO
create view am_vw_audit_b_a as select * from am_audit_b union all select * from am_audit_a;
-- GO
create view am_vw_audit_c_b as select * from am_audit_c union all select * from am_audit_b;
-- GO
create view am_vw_audit_a_c as select * from am_audit_a union all select * from am_audit_c;

-- GO
create view am_vw_audit_attribute_b_a as select * from am_audit_attr_b union all select * from am_audit_attr_a;
-- GO
create view am_vw_audit_attribute_c_b as select * from am_audit_attr_c union all select * from am_audit_attr_b;
-- GO
create view am_vw_audit_attribute_a_c as select * from am_audit_attr_a union all select * from am_audit_attr_c;

-- END OF Additional Script

-- Uncomment the following and input the user/role that will be used to connect to AccessMatrix for additional housekeeping privileges. 

	-- grant alter on dbo.am_audit_a to User;
	-- grant alter on dbo.am_audit_b to User;
	-- grant alter on dbo.am_audit_c to User;
	-- grant alter on dbo.am_audit_attr_a to User;
	-- grant alter on dbo.am_audit_attr_b to User;
	-- grant alter on dbo.am_audit_attr_c to User;
