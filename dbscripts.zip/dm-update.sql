-- IMPORTANT: During database initialization, [Case-sensitive] must be set to
-- "Insensitive".

-- SchemaVersion1117
-- START OF AccessMatrix Server Schema Update 5.6.8 (1112) to 5.7.3 (1117)

    create table am_rp_token (
        rpt_token_uuid varchar(64) not null,
    	rpt_token_hash varchar(64) not null unique,
        rpt_token varchar(3072) not null,
        rpt_user_uuid varchar(64) not null,
        rpt_lookup_module_uuid varchar(64) not null,
        rpt_type varchar(8) not null,
        rpt_at_expiry_time bigint,
        rpt_token_expiry_time bigint not null,
        rpt_session_iid varchar(22),
        primary key (rpt_token_uuid)
    );
    
    create index idx_token_expiryTime on am_rp_token (rpt_token_expiry_time);

    create index idx_rpt_lookupmoduleuuid_useruuid_type_exp on am_rp_token(rpt_user_uuid,rpt_lookup_module_uuid,rpt_type);

    create index idx_rpt_sessioniid_type_exp on am_rp_token(rpt_session_iid,rpt_type);
    
    update am_vars set va_value='1117', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.6.8 (1112) to 5.7.3 (1117)
-- EndOfSchemaVersion1117
 
    
-- SchemaVersion1122
-- START OF AccessMatrix Server Schema Update 5.7.3 (1117) to 5.7.4 (1122)

 	create index idx_im_app_profile on am_idmapping(im_ext_app_uuid,im_profile_name);
    
    update am_vars set va_value='1122', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.7.3 (1117) to 5.7.4 (1122)
-- EndOfSchemaVersion1122   
       
-- SchemaVersion1127
-- START OF AccessMatrix Server Schema Update 5.7.4 (1122) to 5.7.5 (1127)
    create index idx_ot_client_uuid on am_oauthtoken(ot_client_uuid);
    
	update am_attribute set at_long_value = at_long_value/60 where at_name ='RefreshTokenValidityPeriod'; 

	update am_attribute set at_long_value = at_long_value/60, at_name='RT_ExpiryInMins', at_name_upper='RT_EXPIRYINMINS', at_datatype='LONG' where at_name ='RT_ExpiryInSecs' ;
	
	
	update am_vars set va_value='1127', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.7.4 (1122) to 5.7.5 (1127)
-- EndOfSchemaVersion1127

-- SchemaVersion1132
-- START OF AccessMatrix Server Schema Update 5.7.5 (1127) to 5.7.6 (1132)
	
	update am_attribute set at_datatype = 'MULTISTRING' where at_name ='responseAuthnContextMappings' and at_datatype = 'STRING';
	
	update am_vars set va_value='1132', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.7.5 (1127) to 5.7.6 (1132)	
-- EndOfSchemaVersion1132

-- SchemaVersion1137
-- START OF AccessMatrix Server Schema Update 5.7.6 (1132) to 6.0.0 (1137)

   alter table am_tokenauthstate
     add tst_last_succ_date datetime,
     add tst_last_fail_date datetime;

   update am_vars set va_value='1137', va_version = va_version +1 where va_name='SchemaVersion';

-- END OF AccessMatrix Server Schema Update 5.7.6 (1132) to 6.0.0 (1137)
-- EndOfSchemaVersion1137
